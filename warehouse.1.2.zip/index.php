<?php
session_start();
include_once 'Include/Main.php';
include_once 'Global.php';

// Ajax route برای اضافه‌کردن تأمین‌کننده
if (($_GET['Page'] ?? null) === 'ajaxAddSupplier') {
    $Suppliers->ajaxAddSupplier();
    exit;
}

// Handle alerts
$Alert = $_SESSION['alert'] ?? null;
unset($_SESSION['alert']);

// Session validation
if (!empty($_SESSION['UserKaIdPNL'])) {

    if (empty($_SESSION['UserInfoPNL']) || !is_array($_SESSION['UserInfoPNL'])) {
        include "./Include/Operator/Logout.php";
        exit;
    }

    $Role = json_decode($_SESSION['UserInfoPNL']['role'], true) ?? $_SESSION['UserInfoPNL']['role'];
    $page = filter_input(INPUT_GET, 'Page', FILTER_SANITIZE_STRING) ?? 'dashboard';

    if (isset($_GET['Logout']) && $_GET['Logout'] == 1) {
        include "./Include/Operator/Logout.php";
        exit;
    }

    $allowedPages = [
        'dashboard' => ['مدیر', 'انباردار', 'آشپزخانه', 'بار', 'کارپرداز', 'صندوقدار', 'کاربر'],
        'editProfile' => ['مدیر', 'انباردار', 'کاربر'],
        'showUsers' => ['مدیر'],
        'showItems' => ['مدیر', 'انباردار'],
        'showMasterItems' => ['مدیر', 'انباردار'],
        'editItem' => ['مدیر', 'انباردار'],
        'showCategories' => ['مدیر'],
        'editCategory' => ['مدیر'],
        'showSuppliers' => ['مدیر'],
        'editSupplier' => ['مدیر'],
        'showUnits' => ['مدیر'],
        'editUnit' => ['مدیر'],
        'showStorageLocations' => ['مدیر'],
        'editStorageLocation' => ['مدیر'],
        'showCustomers' => ['مدیر'],
        'editCustomer' => ['مدیر'],
        'showInventory' => ['مدیر', 'انباردار'],
        'showRequests' => ['مدیر', 'انباردار'],
        'editInventory' => ['مدیر', 'انباردار'],
        'showStockTransactions' => ['مدیر', 'انباردار'],
        'editStockTransaction' => ['مدیر', 'انباردار'],
        'showLogs' => ['مدیر'],
        'showInventoryReport' => ['مدیر'],
        'showOrderReport' => ['مدیر'],
        'showOrders' => ['مدیر'],
        'showTransactions' => ['مدیر'],
        'transferRequests' => ['مدیر', 'انباردار', 'بار', 'آشپزخانه'],
        'editTransferRequest' => ['مدیر', 'انباردار'],
        'showPurchases' => ['مدیر', 'انباردار'],
        'editPurchaseRequest' => ['مدیر', 'انباردار'],
        'showInvoices' => ['مدیر', 'کارپرداز', 'انباردار'],
        'showInvoiceItems' => ['مدیر', 'کارپرداز', 'انباردار'],
        'editInvoiceItem' => ['مدیر', 'کارپرداز', 'انباردار'],
        'editInvoice' => ['مدیر', 'کارپرداز'],
        'addInvoice' => ['مدیر', 'کارپرداز'],
        'confirmReceived' => ['مدیر', 'انباردار'],
        'ajaxAddSupplier' => ['مدیر', 'انباردار'],
    ];

    if (!isset($allowedPages[$page]) || !in_array($Role, $allowedPages[$page])) {
        include "./Include/View/header.php";
        include "./Include/View/Base/403.php";
        include "./Include/View/footer.php";
        exit;
    }

    $pageMap = [
        'dashboard' => 'dashboard',
        'editProfile' => 'Profile',
        'showUsers' => 'User',
        'showItems' => 'Items',
        'showMasterItems' => 'MasterItems',
        'editItem' => 'Items',
        'showCategories' => 'Categories',
        'editCategory' => 'Categories',
        'showSuppliers' => 'Suppliers',
        'editSupplier' => 'Suppliers',
        'showUnits' => 'Units',
        'editUnit' => 'Units',
        'showStorageLocations' => 'StorageLocations',
        'editStorageLocation' => 'StorageLocations',
        'showCustomers' => 'Customers',
        'editCustomer' => 'Customers',
        'showInventory' => 'Inventory',
        'editInventory' => 'Inventory',
        'showStockTransactions' => 'StockTransactions',
        'editStockTransaction' => 'StockTransactions',
        'showLogs' => 'Logs',
        'showInventoryReport' => 'Reports',
        'showOrderReport' => 'Reports',
        'showOrders' => 'Reports',
        'showRequests' => 'TransferRequests',
        'editTransferRequest' => 'TransferRequests',
        'showPurchases' => 'PurchaseRequests',
        'editPurchaseRequest' => 'PurchaseRequests',
        'showInvoices' => 'Invoices',
        'showInvoiceItems' => 'InvoiceItems',
        'editInvoiceItem' => 'manageInvoiceItems',
        'editInvoice' => 'Invoices',
        'addInvoice' => 'Invoices',
        'confirmReceived' => 'ConfirmReceived',
    ];

    if ($page === 'dashboard') {
        include "./Include/View/header.php";
        switch ($Role) {
            case 'مدیر':
                include "./Include/View/dashboard.php";
                break;
            case 'کارپرداز':
                include "./Include/View/dashboard_procurement.php";
                break;
            case 'انباردار':
                include "./Include/View/dashboard_warehouse.php";
                break;
            case 'صندوقدار':
                include "./Include/View/dashboard_cashier.php";
                break;
            case 'بار':
            case 'آشپزخانه':
                include "./Include/View/dashboard_kitchen_bar.php";
                break;
            default:
                echo "دسترسی تعریف نشده است.";
                break;
        }
        include "./Include/View/sidenav.php";
        include "./Include/View/footer.php";
        exit;
    }

    if (isset($pageMap[$page]) && file_exists("./Include/Operator/{$pageMap[$page]}.php")) {
        include "./Include/Operator/{$pageMap[$page]}.php";
    }

    if (file_exists("./Include/View/{$page}.php")) {
        include "./Include/View/header.php";
        include "./Include/View/{$page}.php";
        include "./Include/View/sidenav.php";
        include "./Include/View/footer.php";
    } else {
        include "./Include/View/header.php";
        include "./Include/View/Base/404.php";
        include "./Include/View/footer.php";
    }
} else {
    $p = filter_input(INPUT_GET, 'P', FILTER_SANITIZE_STRING);
    if ($p === "ForgotPass") {
        include "./Include/Operator/forgotPass.php";
        include "./Include/View/Base/forgotPass.php";
    } elseif (isset($_GET['RESET'])) {
        include "./Include/Operator/forgotPass.php";
        include "./Include/View/Base/newPass.php";
    } else {
        include "./Include/Operator/Login.php";
        include "./Include/View/Base/Login.php";
    }
}
