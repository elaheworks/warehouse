<?php
// $dsn = 'mysql:host=localhost;dbname=vynavkji_logs;charset=utf8mb4';
// $username = 'vynavkji_logger';
// $password = '38eS-dRaoWe&';
$dsn = 'mysql:host=localhost;dbname=inventory;charset=utf8mb4';
$username = 'root';
$password = '';
