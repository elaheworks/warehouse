<?php
// $dsn = 'mysql:host=localhost;dbname=vynavkji_warehouse;charset=utf8mb4';
// $username = 'vynavkji_manager';
// $password = '1o[+HMb$q)!9';
$dsn = 'mysql:host=localhost;dbname=kaghazi;charset=utf8mb4';
$username = 'root';
$password = '';
