<?php
require 'Include/PHPMailer/PHPMailer.php';
require 'Include/PHPMailer/SMTP.php';
require 'Include/PHPMailer/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

function sendEmail($toEmail, $subject, $body, &$error = null) {
    $mail = new PHPMailer();

    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host = 'shahkardrama.ir';
        $mail->Port = 465; 
        $mail->SMTPAuth = true;
        $mail->Username = 'admin@shahkardrama.ir';
        $mail->Password = 'oL1-fM8-vX0-lP4_';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS; 
        $mail->Timeout = 30;

        // Recipients
        $mail->setFrom('admin@shahkardrama.ir', 'Shahkar Panel');
        $mail->addAddress($toEmail);

        // Content
        $mail->Subject = $subject;
        $mail->isHTML(true);
        $mail->Body = $body;

        // Send the email
        if (!$mail->send()) {
            $error = $mail->ErrorInfo;
            return false;
        }
        return true;
    } catch (Exception $e) {
        $error = $mail->ErrorInfo;
        return false;
    }
}
