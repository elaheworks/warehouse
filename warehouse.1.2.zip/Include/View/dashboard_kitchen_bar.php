<?php include_once "./Include/View/header.php"; ?>

<div class="max-w-5xl mx-auto p-6 space-y-10">

    <div class="space-y-4">
        <h2 class="text-2xl font-bold text-primary flex items-center gap-2">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-primary" fill="none" viewBox="0 0 24 24"
                stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M3 7h18M3 12h18M3 17h18" />
            </svg>
            ثبت درخواست انتقال
        </h2>

        <form method="post" class="bg-base-100 p-6 rounded-xl shadow-md grid grid-cols-1 gap-4">
            <input type="hidden" name="transferForm" value="addRequest">
            <input type="hidden" name="from_location" value="انبار">

            <select name="to_location" required class="select select-primary w-full">
                <option disabled selected>مقصد را انتخاب کنید</option>
                <option value="بار">بار</option>
                <option value="آشپزخانه">آشپزخانه</option>
                <option value="مرجوعی">مرجوعی</option>
            </select>

            <div class="flex gap-2">
                <input type="text" id="selectedItemName" readonly class="input input-bordered w-full bg-base-200"
                    placeholder="کالایی انتخاب نشده">
                <input type="hidden" name="item_id" id="selectedItemId" required>
                <button type="button" class="btn btn-outline btn-primary" onclick="openItemModal()">انتخاب</button>
            </div>

            <label class="input input-bordered flex items-center gap-2 w-full">
                <input name="quantity" type="number" min="1" required class="grow" placeholder="مقدار">
                <span id="unitLabel" class="text-sm text-gray-500"></span>
            </label>

            <textarea name="note" rows="2" placeholder="یادداشت"
                class="textarea textarea-primary w-full"></textarea>

            <button class="btn btn-success w-full">ثبت درخواست</button>
        </form>
    </div>

    <!-- نمایش درخواست‌ها -->
    <div class="space-y-4">
        <h2 class="text-xl font-semibold text-primary">درخواست‌های من</h2>

        <?php if (!empty($myRequests)): ?>
            <div class="grid gap-4">
                <?php foreach ($myRequests as $req): ?>
                    <div class="card bg-base-100 shadow-md">
                        <div class="card-body py-4 px-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                            <div>
                                <h3 class="font-bold"><?= $req['item_name'] ?> (<?= $req['quantity'] . ' ' . $req['unit_name'] ?>)</h3>
                                <p class="text-sm text-gray-500">مقصد: <?= $req['to_location'] ?> | <?= jdate('Y/m/d H:i', strtotime($req['requested_at'])) ?></p>
                            </div>
                            <div>
                                <?php
                                $statusLabels = [
                                    0 => ['در انتظار', 'badge-warning'],
                                    1 => ['تأیید شده', 'badge-info'],
                                    2 => ['تکمیل شده', 'badge-success'],
                                    3 => ['رد شده', 'badge-error'],
                                ];
                                [$label, $class] = $statusLabels[$req['status']] ?? ['نامشخص', 'badge-ghost'];
                                ?>
                                <div class="badge <?= $class ?>"><?= $label ?></div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="alert alert-info">درخواستی ثبت نکرده‌اید.</div>
        <?php endif; ?>
    </div>
</div>

<!-- Modal کالا -->
<input type="checkbox" id="itemModal" class="modal-toggle" />
<div class="modal modal-bottom sm:modal-middle">
    <div class="modal-box max-w-3xl max-h-[70vh] overflow-auto">
        <h3 class="font-bold text-lg mb-4">انتخاب کالا</h3>
        <input type="text" id="modalSearch" placeholder="جستجو..." class="input input-bordered mb-4 w-full" />
        <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 max-h-[50vh] overflow-y-auto">
            <?php foreach ($itemsList as $item): ?>
                <div class="card cursor-pointer border border-base-300 hover:border-primary transition"
                    onclick="selectItem(<?= $item['id'] ?>, '<?= $item['product'] ?>', '<?= $item['unit_name'] ?>')">
                    <div class="card-body p-2 text-center text-sm">
                        <?= htmlspecialchars($item['product']) ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <div class="modal-action">
            <label for="itemModal" class="btn btn-outline">بستن</label>
        </div>
    </div>
</div>

<script>
    function openItemModal() {
        document.getElementById("itemModal").checked = true;
        document.getElementById("modalSearch").value = '';
        filterModalItems('');
    }

    function selectItem(id, name, unit) {
        document.getElementById("selectedItemId").value = id;
        document.getElementById("selectedItemName").value = name;
        document.getElementById("unitLabel").textContent = unit;
        document.getElementById("itemModal").checked = false;
    }

    function filterModalItems(term) {
        document.querySelectorAll('.modal .card').forEach(card => {
            const name = card.textContent.trim().toLowerCase();
            card.style.display = name.includes(term.toLowerCase()) ? '' : 'none';
        });
    }

    document.getElementById("modalSearch").addEventListener("input", e => {
        filterModalItems(e.target.value);
    });
</script>
