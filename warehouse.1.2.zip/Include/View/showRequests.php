<?php include_once "./Include/View/header.php"; ?>

<div class="w-full max-w-7xl mx-auto p-6 bg-base-100">

    <h2 class="text-3xl font-extrabold mb-8 text-primary flex items-center gap-2">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
            <path stroke-linecap="round" stroke-linejoin="round" d="M3 7h18M3 12h18M3 17h18" />
        </svg>
        درخواست‌های انتقال
    </h2>

    <form method="post" action="" id="transferRequestForm" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
        <input type="hidden" name="transferForm" value="addRequest">
        <?php
        $preselectedItemId = isset($_GET['selectedItem']) ? (int)$_GET['selectedItem'] : null;
        $preselectedItemName = '';
        $preselectedItemUnit = '';

        if ($preselectedItemId) {
            foreach ($itemsList as $item) {
                if ($item['id'] == $preselectedItemId) {
                    $preselectedItemName = $item['product'];
                    $preselectedItemUnit = $item['unit_name'];
                    break;
                }
            }
        }
        $locationsTo = ['آشپزخانه', 'بار', 'مرجوعی']; ?>
        <select disabled class="select select-bordered select-primary w-full">
            <option value="انبار" selected>انبار</option>
        </select>

        <select name="to_location" required class="select select-bordered select-primary w-full">
            <option value="" disabled selected>انتخاب مقصد</option>
            <?php foreach ($locationsTo as $loc): ?>
                <option value="<?php echo htmlspecialchars($loc); ?>"><?php echo htmlspecialchars($loc); ?></option>
            <?php endforeach; ?>
        </select>

        <input type="hidden" name="item_id" id="selectedItemId" required value="<?= $preselectedItemId ?? ''; ?>">

        <div class="join col-span-1 md:col-span-2 lg:col-span-1 flex gap-2">
            <input type="text" id="selectedItemName" placeholder="کالایی انتخاب نشده" readonly required
                class="input input-bordered cursor-not-allowed bg-base-200 w-full" value="<?= htmlspecialchars($preselectedItemName); ?>" />
            <button type="button" id="openModalBtn" class="btn btn-outline btn-primary flex-shrink-0 flex items-center justify-center gap-2">
                انتخاب کالا
            </button>
        </div>

        <label class="input flex items-center gap-2 col-span-1 md:col-span-2 lg:col-span-1 w-full">
            <input name="quantity" id="quantityInput" type="number" min="1" placeholder="مقدار" required
                class="input input-bordered input-primary w-full" />
            <span id="unitLabel" class="label whitespace-nowrap"><?= htmlspecialchars($preselectedItemUnit); ?></span>
        </label>

        <div class="flex gap-4 col-span-1 md:col-span-2 lg:col-span-4">
            <textarea name="note" placeholder="یادداشت" class="flex-1 textarea textarea-primary w-full"></textarea>
        </div>

        <div class="col-span-1 md:col-span-2 lg:col-span-4 flex gap-4 items-center">
            <button type="submit" class="btn btn-primary flex-1 w-full">ثبت درخواست</button>
        </div>
    </form>


    <div class="divider my-8"></div>

    <?php if (!empty($paginatedRequests)): ?>
        <div class="overflow-x-auto rounded-lg shadow-lg mb-8">
            <table class="table table-zebra w-full">
                <thead>
                    <tr class="bg-secondary text-secondary-content">
                        <th>#</th>
                        <th>مبدأ</th>
                        <th>مقصد</th>
                        <th>کالا</th>
                        <th>مقدار</th>
                        <th>وضعیت</th>
                        <th>تاریخ درخواست</th>
                        <th class="text-center">عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($paginatedRequests as $i => $req): ?>
                        <?php
                        $statuses = [
                            0 => ['label' => 'در انتظار', 'class' => 'badge badge-warning'],
                            1 => ['label' => 'تأیید شده', 'class' => 'badge badge-info'],
                            2 => ['label' => 'تکمیل شده', 'class' => 'badge badge-success'],
                            3 => ['label' => 'رد شده', 'class' => 'badge badge-error'],
                        ];
                        $status = $req['status'];
                        ?>
                        <tr
                            class="cursor-pointer hover:bg-base-200 transition"
                            data-id="<?= $req['id']; ?>"
                            data-from="<?= htmlspecialchars($req['from_location']); ?>"
                            data-to="<?= htmlspecialchars($req['to_location']); ?>"
                            data-item="<?= htmlspecialchars($req['item_name']); ?>"
                            data-quantity="<?= $req['quantity']; ?>"
                            data-unit="<?= $req['unit_name']; ?>"
                            data-status="<?= $statuses[$status]['label']; ?>"
                            data-requested-by="<?= htmlspecialchars($req['requested_by_name']); ?>"
                            data-requested-at="<?= jdate('Y/m/d H:i', strtotime($req['requested_at'])); ?>"
                            data-approved-by="<?= $req['approved_by_name'] ?? '—'; ?>"
                            data-approved-at="<?= $req['approved_at'] ? jdate('Y/m/d H:i', strtotime($req['approved_at'])) : '—'; ?>"
                            data-completed-by="<?= $req['completed_by_name'] ?? '—'; ?>"
                            data-completed-at="<?= $req['completed_at'] ? jdate('Y/m/d H:i', strtotime($req['completed_at'])) : '—'; ?>"
                            data-note="<?= htmlspecialchars($req['note'] ?? ''); ?>"
                            onclick="showDetailModal(this)">
                            <td class="font-semibold"><?php echo $offset + $i + 1; ?></td>
                            <td><?php echo htmlspecialchars($req['from_location']); ?></td>
                            <td><?php echo htmlspecialchars($req['to_location']); ?></td>
                            <td><?php echo htmlspecialchars($req['item_name']); ?></td>
                            <td><?php echo htmlspecialchars($req['quantity']) . " " . $req['unit_name']; ?></td>
                            <td>
                                <span class="<?php echo $statuses[$status]['class'] ?? 'badge'; ?>">
                                    <?php echo $statuses[$status]['label'] ?? 'نامشخص'; ?>
                                </span>
                            </td>
                            <td><?php echo jdate('Y/m/d H:i', strtotime($req['requested_at'])); ?></td>
                            <td class="space-x-1 whitespace-nowrap text-center">
                                <?php if ($status == 0): ?>
                                    <form method="post" class="inline" onsubmit="return confirm('آیا مطمئنید می‌خواهید این درخواست را تأیید کنید؟');">
                                        <input type="hidden" name="requestid" value="<?php echo $req['id']; ?>">
                                        <button name="transferForm" value="approveRequest" class="btn btn-xs btn-success gap-1 flex items-center justify-center">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7" />
                                            </svg>
                                            تأیید
                                        </button>
                                    </form>
                                    <form method="post" class="inline" onsubmit="return confirm('آیا مطمئنید می‌خواهید این درخواست را رد کنید؟');">
                                        <input type="hidden" name="requestid" value="<?php echo $req['id']; ?>">
                                        <button name="transferForm" value="rejectRequest" class="btn btn-xs btn-error gap-1 flex items-center justify-center">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
                                            </svg>
                                            رد
                                        </button>
                                    </form>
                                <?php endif; ?>

                                <form method="post" class="inline" onsubmit="return confirm('آیا مطمئنید می‌خواهید این درخواست را حذف کنید؟');">
                                    <input type="hidden" name="requestid" value="<?php echo $req['id']; ?>">
                                    <button name="transferForm" value="deleteRequest" class="btn btn-xs btn-outline btn-error gap-1 flex items-center justify-center">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                            <path stroke-linecap="round" stroke-linejoin="round" d="M19 7L5 7M10 11v6M14 11v6M5 7l1 12a2 2 0 002 2h8a2 2 0 002-2l1-12" />
                                        </svg>
                                        حذف
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <?php if ($totalPages > 1): ?>
            <div class="mt-6 flex justify-center">
                <div class="join">
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <a href="?Page=showRequests&P=<?php echo $i; ?>" class="join-item btn btn-sm <?php echo ($i == $P) ? 'btn-primary' : 'btn-outline'; ?>">
                            <?php echo $i; ?>
                        </a>
                    <?php endfor; ?>
                </div>
            </div>
        <?php endif; ?>

    <?php else: ?>
        <div class="alert alert-info mt-5">هیچ درخواستی ثبت نشده است.</div>
    <?php endif; ?>


    <!-- Modal -->
    <input type="checkbox" id="itemModal" class="modal-toggle" />
    <div class="modal modal-bottom sm:modal-middle">
        <div class="modal-box max-w-5xl max-h-[70vh] overflow-auto">
            <h3 class="font-bold text-lg mb-4">انتخاب کالا</h3>
            <input type="text" id="modalSearch" placeholder="جستجوی کالا..." class="input input-bordered mb-4 w-full" />
            <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 max-h-[50vh] overflow-y-auto">
                <?php foreach ($itemsList as $item): ?>
                    <div tabindex="0" role="button" class="card cursor-pointer border border-base-300 hover:border-primary transition"
                        data-id="<?php echo $item['id']; ?>"
                        data-name="<?php echo htmlspecialchars($item['product']); ?>"
                        data-unit="<?php echo htmlspecialchars($item['unit_name']); ?>">
                        <div class="card-body p-3 text-center">
                            <p class="truncate font-medium text-base-content"><?php echo htmlspecialchars($item['product']); ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>

            </div>
            <div class="modal-action">
                <label for="itemModal" class="btn btn-outline">بستن</label>
            </div>
        </div>
    </div>

</div>
<input type="checkbox" id="detailModal" class="modal-toggle" />
<div class="modal modal-bottom sm:modal-middle">
    <div class="modal-box w-full max-w-2xl">
        <h3 class="font-bold text-lg mb-4">جزئیات درخواست انتقال</h3>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
            <div><strong>مبدأ:</strong> <span id="modalFrom"></span></div>
            <div><strong>مقصد:</strong> <span id="modalTo"></span></div>
            <div><strong>کالا:</strong> <span id="modalItem"></span></div>
            <div><strong>مقدار:</strong> <span id="modalQty"></span></div>
            <div><strong>واحد:</strong> <span id="modalUnit"></span></div>
            <div><strong>وضعیت:</strong> <span id="modalStatus"></span></div>
            <div><strong>توسط:</strong> <span id="modalRequestedBy"></span></div>
            <div><strong>تاریخ درخواست:</strong> <span id="modalRequestedAt"></span></div>
            <div><strong>تأیید کننده:</strong> <span id="modalApprovedBy"></span></div>
            <div><strong>تأیید در:</strong> <span id="modalApprovedAt"></span></div>
            <div><strong>تکمیل توسط:</strong> <span id="modalCompletedBy"></span></div>
            <div><strong>تکمیل در:</strong> <span id="modalCompletedAt"></span></div>
        </div>

        <div class="mt-4">
            <strong>یادداشت:</strong>
            <p id="modalNote" class="bg-base-200 p-2 rounded mt-1 text-sm whitespace-pre-line"></p>
        </div>

        <div class="modal-action">
            <label for="detailModal" class="btn">بستن</label>
        </div>
    </div>
</div>

<script>
    // باز کردن مدال انتخاب کالا
    document.getElementById('openModalBtn').addEventListener('click', () => {
        document.getElementById('itemModal').checked = true;
        document.getElementById('modalSearch').value = '';
        filterModalItems('');
    });

    // انتخاب کالا از مدال
    document.querySelectorAll('.modal .card').forEach(card => {
        card.addEventListener('click', () => {
            const id = card.getAttribute('data-id');
            const name = card.getAttribute('data-name');
            const unit = card.getAttribute('data-unit');

            document.getElementById('selectedItemId').value = id;
            document.getElementById('selectedItemName').value = name;
            document.getElementById('unitLabel').textContent = unit || ''; // نمایش واحد
            document.getElementById('itemModal').checked = false;
        });
    });


    // جستجو داخل مدال
    document.getElementById('modalSearch').addEventListener('input', (e) => {
        filterModalItems(e.target.value.toLowerCase());
    });

    function filterModalItems(searchTerm) {
        document.querySelectorAll('.modal .card').forEach(card => {
            const name = card.getAttribute('data-name').toLowerCase();
            card.style.display = name.includes(searchTerm) ? '' : 'none';
        });
    }
</script>
<script>
    function showDetailModal(row) {
        document.getElementById('modalFrom').textContent = row.dataset.from;
        document.getElementById('modalTo').textContent = row.dataset.to;
        document.getElementById('modalItem').textContent = row.dataset.item;
        document.getElementById('modalQty').textContent = row.dataset.quantity;
        document.getElementById('modalUnit').textContent = row.dataset.unit;
        document.getElementById('modalStatus').textContent = row.dataset.status;
        document.getElementById('modalRequestedBy').textContent = row.dataset.requestedBy;
        document.getElementById('modalRequestedAt').textContent = row.dataset.requestedAt;
        document.getElementById('modalApprovedBy').textContent = row.dataset.approvedBy;
        document.getElementById('modalApprovedAt').textContent = row.dataset.approvedAt;
        document.getElementById('modalCompletedBy').textContent = row.dataset.completedBy;
        document.getElementById('modalCompletedAt').textContent = row.dataset.completedAt;
        document.getElementById('modalNote').textContent = row.dataset.note || '—';

        document.getElementById('detailModal').checked = true;
    }
</script>