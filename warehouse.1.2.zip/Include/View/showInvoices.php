<?php include_once "./Include/View/header.php"; ?>

<div class="w-full max-w-7xl mx-auto p-6 bg-base-100">
    <h2 class="text-3xl font-extrabold mb-6 text-primary flex items-center gap-2">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
            <path stroke-linecap="round" stroke-linejoin="round" d="M9 17v-2h6v2H9zm0-4V9h6v4H9zm0-6V3h6v4H9z" />
        </svg>
        مدیریت فاکتورها
    </h2>

    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success mb-4"> <?= $_SESSION['success'];
                                                unset($_SESSION['success']); ?> </div>
    <?php endif; ?>

    <form method="post" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6 bg-base-200 p-4 rounded-xl shadow">
        <input type="hidden" name="createInvoice" value="1">

        <select name="supplier_id" id="supplierSelect" class="select select-bordered w-full" required>
            <option value="">انتخاب تأمین‌کننده</option>
            <?php foreach ($suppliersList as $s): ?>
                <option value="<?= $s['id']; ?>"><?= htmlspecialchars($s['name']); ?></option>
            <?php endforeach; ?>
        </select>

        <input type="text" name="invoice_number" placeholder="شماره فاکتور" required class="input input-bordered w-full" title="شماره فاکتور یکتا وارد کنید">
        <input type="text" id="invoiceDatePicker" name="date" placeholder="تاریخ فاکتور" required class="input input-bordered w-full" title="تاریخ فاکتور را انتخاب کنید">

        <input type="text" name="note" placeholder="یادداشت" class="input input-bordered w-full">

        <!-- تخفیف -->
        <div class="flex gap-2 items-center">
            <input type="number" step="0.01" name="discount_value" placeholder="تخفیف" class="input input-bordered w-full" title="در صورت نیاز تخفیف وارد کنید">
            <select name="discount_type" class="select select-bordered w-24">
                <option value="amount">ریال</option>
                <option value="percent">٪</option>
            </select>
        </div>

        <!-- مالیات -->
        <div class="flex gap-2 items-center">
            <input type="number" step="0.01" name="tax_value" placeholder="مالیات" class="input input-bordered w-full" title="در صورت نیاز مالیات وارد کنید">
            <select name="tax_type" class="select select-bordered w-24">
                <option value="amount">ریال</option>
                <option value="percent">٪</option>
            </select>
        </div>

        <!-- حمل‌ونقل -->
        <input type="number" step="0.01" name="shipping_cost" placeholder="هزینه حمل‌ونقل (ریال)" class="input input-bordered w-full">

        <!-- اشانتیون -->
        <input type="text" name="gift" placeholder="اشانتیون (اختیاری)" class="input input-bordered w-full">
        <button type="submit" class="btn btn-primary btn-outline sm:col-span-2 lg:col-span-4 w-full">ثبت فاکتور</button>
    </form>

    <input type="text" id="searchInvoice" placeholder="جستجو در فاکتورها..." class="input input-bordered w-full mb-4">

    <?php if (!empty($invoicesList)): ?>
        <div class="overflow-x-auto rounded-xl shadow">
            <table class="table table-zebra w-full">
                <thead class="bg-secondary text-secondary-content text-center">
                    <tr>
                        <th>#</th>
                        <th>شماره فاکتور</th>
                        <th>تأمین‌کننده</th>
                        <th>مجموع</th>
                        <th>وضعیت</th>
                        <th>تاریخ ثبت</th>
                        <th>تاریخ فاکتور</th>
                        <th>عملیات</th>
                    </tr>
                </thead>
                <tbody class="text-center">
                    <?php foreach ($invoicesList as $i => $inv): ?>
                        <?php
                        $statusClass = [0 => 'badge-warning', 1 => 'badge-info', 2 => 'badge-success', 3 => 'badge-error'];
                        $statusText = [0 => 'پیش‌نویس', 1 => 'تأیید شده', 2 => 'تکمیل شده', 3 => 'لغو شده'];
                        $isOld = (strtotime('now') - strtotime($inv['purchased_at'])) > (7 * 24 * 60 * 60);
                        ?>
                        <tr class="<?= ($inv['status'] == 0 && $isOld) ? 'bg-warning/30' : '' ?>">
                            <td><?= $i + 1 ?></td>
                            <td><?= htmlspecialchars($inv['invoice_number']) ?></td>
                            <td><?= htmlspecialchars($inv['supplier_name']) ?></td>
                            <td><?= number_format($inv['total_price']) ?> ریال</td>
                            <td><span class="badge <?= $statusClass[$inv['status']] ?? 'badge-neutral' ?>"> <?= $statusText[$inv['status']] ?? 'نامشخص' ?> </span></td>
                            <td><?= jdate('Y/m/d H:i', strtotime($inv['reg_date'])) ?></td>
                            <td><?= jdate('Y/m/d H:i', strtotime($inv['purchased_at'])) ?></td>
                            <td class="flex flex-wrap justify-center gap-1">
                                <a href="?Page=showInvoiceItems&invoice_id=<?= $inv['id']; ?>" value="1" class="btn btn-xs btn-outline btn-primary">مدیریت آیتم‌ها</a>


                                <?php if ($inv['status'] == 0): ?>
                                    <form method="post" title="تأیید فاکتور">
                                        <input type="hidden" name="invoice_id" value="<?= $inv['id']; ?>">
                                        <input type="hidden" name="supplier_id" value="<?= $inv['supplier_id']; ?>">
                                        <button name="approveInvoice" value="1" class="btn btn-xs btn-outline btn-success">تأیید</button>
                                    </form>
                                    <form method="post" onsubmit="return confirm('لغو این فاکتور؟');" title="لغو فاکتور">
                                        <input type="hidden" name="invoice_id" value="<?= $inv['id']; ?>">
                                        <button name="cancelInvoice" value="1" class="btn btn-xs btn-outline btn-error">لغو</button>
                                    </form>
                                <?php endif; ?>

                                <form method="post" onsubmit="return confirm('حذف این فاکتور؟ توجه: آیتم‌ها نیز حذف می‌شوند.');" title="حذف فاکتور">
                                    <input type="hidden" name="invoice_id" value="<?= $inv['id']; ?>">
                                    <button name="deleteInvoice" value="1" class="btn btn-xs btn-outline btn-error">حذف</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <div class="text-sm text-gray-500 mt-2">تعداد فاکتورهای ثبت شده: <?= count($invoicesList); ?> عدد</div>
        </div>
    <?php else: ?>
        <div class="alert alert-info mt-6">هنوز فاکتوری ثبت نشده است.</div>
    <?php endif; ?>
</div>

<script>
    $(function() {
        new TomSelect("#supplierSelect", {
            create: false,
            sortField: {
                field: "text",
                direction: "asc"
            },
        });

        $("#searchInvoice").on("keyup", function() {
            let value = $(this).val().toLowerCase();
            $("table tbody tr").filter(function() {
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
            });
        });
    });

    $(document).ready(function() {
        $("#invoiceDatePicker").persianDatepicker({
            format: 'YYYY/MM/DD',
            initialValueType: 'gregorian',
            autoClose: true,
            toolbox: {
                calendarSwitch: {
                    enabled: false
                }
            }
        });
    });
</script>