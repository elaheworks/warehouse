<?php include_once "./Include/View/header.php"; ?>

<div class="w-full max-w-xl mx-auto p-6 bg-base-100 shadow-lg rounded-lg">
    <div class="flex justify-between items-center mb-6">
        <h2 class="text-xl font-bold text-primary">ویرایش واحد</h2>
        <a href="?Page=showUnits" class="btn btn-outline btn-sm">بازگشت</a>
    </div>

    <?php if ($Unit): ?>
        <form method="post" action="">
            <input type="hidden" name="unitForm" value="editUnit">
            <input type="hidden" name="unit" value="<?= $Unit['id']; ?>">

            <div class="space-y-4">
                <!-- نام واحد -->
                <div>
                    <label class="label">نام واحد</label>
                    <input type="text" name="name" class="input input-bordered w-full"
                           value="<?= htmlspecialchars($Unit['name']); ?>" required>
                </div>

                <!-- توضیحات -->
                <div>
                    <label class="label">توضیحات</label>
                    <textarea name="description" class="textarea textarea-bordered w-full" rows="3"
                              placeholder="توضیحات"><?= htmlspecialchars($Unit['description']); ?></textarea>
                </div>

                <!-- وضعیت -->
                <div>
                    <label class="label">وضعیت</label>
                    <select name="status" class="select select-bordered w-full" required>
                        <option value="0" <?= $Unit['status'] == 0 ? 'selected' : ''; ?>>فعال</option>
                        <option value="1" <?= $Unit['status'] == 1 ? 'selected' : ''; ?>>غیرفعال</option>
                    </select>
                </div>
            </div>

            <div class="flex justify-end mt-6 space-x-2">
                <button type="submit" class="btn btn-success">ذخیره تغییرات</button>
                <a href="?Page=showUnits" class="btn">لغو</a>
            </div>
        </form>
    <?php else: ?>
        <div class="alert alert-error">واحد مورد نظر یافت نشد.</div>
        <a href="?Page=showUnits" class="btn btn-primary mt-4">بازگشت به لیست</a>
    <?php endif; ?>
</div>
