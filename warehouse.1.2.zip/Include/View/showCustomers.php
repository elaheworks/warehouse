<?php include_once "./Include/View/header.php"; ?>
<div class="w-full mx-auto p-6 bg-base-100 shadow-lg rounded-lg">
    <div class="flex justify-between items-center mb-4">
        <div></div>
        <button class="btn btn-primary" onclick="add_customer_modal.showModal()">
            <i class="fa-solid fa-plus"></i> افزودن مشتری
        </button>
    </div>

    <!-- Minimal Filter Section -->
    <details class="collapse collapse-arrow bg-base-200 mb-4">
        <summary class="collapse-title text-md font-medium">فیلترها</summary>
        <div class="collapse-content">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                    <label class="label">نام</label>
                    <input type="text" class="column-filter input input-bordered input-sm w-full" data-column="name" placeholder="فیلتر نام">
                </div>
                <div>
                    <label class="label">شماره تلفن</label>
                    <input type="text" class="column-filter input input-bordered input-sm w-full" data-column="phone" placeholder="فیلتر شماره تلفن">
                </div>
                <div>
                    <label class="label">وضعیت</label>
                    <select class="column-filter select select-bordered select-sm w-full" data-column="status">
                        <option value="">همه</option>
                        <option value="0">فعال</option>
                        <option value="1">غیرفعال</option>
                    </select>
                </div>
            </div>
        </div>
    </details>

    <div class="overflow-auto h-screen">
        <table class="table w-full">
            <!-- Table Head -->
            <thead>
                <tr>
                    <th>#</th>
                    <th>نام</th>
                    <th>شماره تلفن</th>
                    <th>آدرس</th>
                    <th>وضعیت</th>
                    <th></th>
                </tr>
            </thead>
            <!-- Table Body -->
            <?php if (!empty($paginatedCustomers)): ?>
                <tbody id="customers-table-body">
                    <?php foreach ($paginatedCustomers as $customer): ?>
                        <tr class="hover" data-status="<?php echo $customer['status']; ?>">
                            <th><?php echo $customer['id']; ?></th>
                            <td><?php echo $customer['name']; ?></td>
                            <td><?php echo $customer['phone']; ?></td>
                            <td><?php echo $customer['address'] ?: '-'; ?></td>
                            <td>
                                <?php if ($customer['status'] == 0): ?>
                                    <span class="badge badge-success">فعال</span>
                                <?php else: ?>
                                    <span class="badge badge-error">غیرفعال</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end">
                                <button class="btn btn-outline btn-secondary btn-xs" onclick="detail_modal_<?php echo $customer['id']; ?>.showModal()">
                                    <i class="fa-solid fa-info-circle"></i>
                                </button>
                                <a href="?Page=editCustomer&customer=<?php echo $customer['id']; ?>" class="btn btn-outline btn-primary btn-xs">
                                    <i class="fa-solid fa-edit"></i>
                                </a>
                                <button class="btn btn-outline btn-error btn-xs" onclick="delete_modal_<?php echo $customer['id']; ?>.showModal()">
                                    <i class="fa-solid fa-trash"></i>
                                </button>
                            </td>
                        </tr>

                        <!-- Detail Modal -->
                        <dialog id="detail_modal_<?php echo $customer['id']; ?>" class="modal">
                            <div class="modal-box">
                                <h3 class="text-lg font-bold">جزئیات مشتری</h3>
                                <div class="py-4">
                                    <p><strong>شناسه:</strong> <?php echo $customer['id']; ?></p>
                                    <p><strong>نام:</strong> <?php echo $customer['name']; ?></p>
                                    <p><strong>شماره تلفن:</strong> <?php echo $customer['phone']; ?></p>
                                    <p><strong>آدرس:</strong> <?php echo $customer['address'] ?: '-'; ?></p>
                                    <p><strong>شناسه تلگرام:</strong> <?php echo $customer['telegram_id'] ?: '-'; ?></p>
                                    <p><strong>تاریخ ثبت:</strong> <?php echo $customer['reg_date']; ?></p>
                                    <p><strong>وضعیت:</strong> <?php if($customer['status'] == 0) {echo "فعال";} else {echo "غیرفعال";} ?></p>
                                </div>
                                <div class="modal-action">
                                    <form method="dialog">
                                        <button class="btn">بستن</button>
                                    </form>
                                </div>
                            </div>
                        </dialog>

                        <!-- Delete Confirmation Modal -->
                        <dialog id="delete_modal_<?php echo $customer['id']; ?>" class="modal">
                            <div class="modal-box">
                                <h3 class="text-lg font-bold">تأیید حذف</h3>
                                <p class="py-4">آیا مطمئن هستید که می‌خواهید مشتری "<?php echo $customer['name']; ?>" را حذف کنید؟</p>
                                <div class="modal-action">
                                    <form method="post" action="">
                                        <input type="hidden" name="customerid" value="<?php echo $customer['id']; ?>">
                                        <button class="btn btn-error" name="customerForm" value="deleteCustomer">حذف</button>
                                        <button class="btn">لغو</button>
                                    </form>
                                </div>
                            </div>
                        </dialog>
                    <?php endforeach; ?>
                </tbody>
            <?php else: ?>
                <tbody>
                    <tr>
                        <td colspan="6" class="text-center">مشتری یافت نشد</td>
                    </tr>
                </tbody>
            <?php endif; ?>
        </table>
    </div>

    <!-- Pagination -->
    <?php if ($totalPages > 1): ?>
        <div class="flex justify-center mt-4">
            <div class="join">
                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                    <a href="?Page=showCustomers&P=<?php echo $i; ?>" class="join-item btn <?php echo $P == $i ? 'btn-active' : ''; ?>"><?php echo $i; ?></a>
                <?php endfor; ?>
            </div>
        </div>
    <?php endif; ?>
</div>

<!-- Add Customer Modal -->
<dialog id="add_customer_modal" class="modal">
    <div class="modal-box">
        <h3 class="text-lg font-bold">افزودن مشتری جدید</h3>
        <form method="POST" action="">
            <div class="py-4 space-y-4">
                <div>
                    <label class="label">نام</label>
                    <input type="text" name="name" class="input input-bordered w-full" placeholder="نام کامل" required>
                </div>
                <div>
                    <label class="label">شماره تلفن</label>
                    <input type="text" name="phone" class="input input-bordered w-full" placeholder="شماره تلفن" required>
                </div>
                <div>
                    <label class="label">آدرس</label>
                    <textarea name="address" class="textarea textarea-bordered w-full" placeholder="آدرس"></textarea>
                </div>
                <div>
                    <label class="label">شناسه تلگرام</label>
                    <input type="text" name="telegram_id" class="input input-bordered w-full" placeholder="شناسه تلگرام">
                </div>
                <div>
                    <label class="label">وضعیت</label>
                    <select name="status" class="select select-bordered w-full" required>
                        <option value="0">فعال</option>
                        <option value="1">غیرفعال</option>
                    </select>
                </div>
            </div>
            <div class="modal-action">
                <button type="submit" name="customerForm" value="addCustomer" class="btn btn-primary">ذخیره</button>
                <button type="button" class="btn" onclick="add_customer_modal.close()">لغو</button>
            </div>
        </form>
    </div>
</dialog>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const tableBody = document.getElementById('customers-table-body');
    if (!tableBody) return; // Exit if table body is not found
    const rows = Array.from(tableBody.getElementsByTagName('tr'));
    const filters = document.querySelectorAll('.column-filter');
    const filterValues = {};

    filters.forEach(filter => {
        filter.addEventListener('input', function() {
            filterValues[this.getAttribute('data-column')] = this.value.toLowerCase().trim();

            rows.forEach(row => {
                const cells = row.getElementsByTagName('td');
                let shouldShow = true;

                if (filterValues.name && cells[0].textContent.toLowerCase().trim().indexOf(filterValues.name) === -1) {
                    shouldShow = false;
                }
                if (filterValues.phone && cells[1].textContent.toLowerCase().trim().indexOf(filterValues.phone) === -1) {
                    shouldShow = false;
                }
                if (filterValues.status && row.getAttribute('data-status') !== filterValues.status) {
                    shouldShow = false;
                }

                row.style.display = shouldShow ? '' : 'none';
            });
        });
    });
});
</script>