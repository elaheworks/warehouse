<?php include "./Include/View/header.php"; ?>
<div class="card bg-base-100 shadow-xl">
    <div class="card-body">
        <h2 class="card-title">ویرایش کاربر</h2>
        <form method="post" action="" enctype="multipart/form-data">
            <div class="form-control">
                <label class="label">
                    <span class="label-text">نام کاربر</span>
                </label>
                <input type="text" name="name" value="<?php echo htmlspecialchars($User['name']); ?>" class="input input-bordered" required>
            </div>
            <div class="form-control">
                <label class="label">
                    <span class="label-text">نام کاربری</span>
                </label>
                <input type="text" name="username" value="<?php echo htmlspecialchars($User['username']); ?>" class="input input-bordered" required>
            </div>
            <div class="form-control">
                <label class="label">
                    <span class="label-text">رمز عبور</span>
                </label>

                <input type="password" name="password" class="input input-bordered" placeholder="رمز عبور جدید (اختیاری)">
            </div>
            <div class="form-control">
                <label class="label">
                    <span class="label-text">تلگرام</span>
                </label>
                <input type="text" name="telegram" value="<?php echo htmlspecialchars($User['tel_id']); ?>" class="input input-bordered" required>
            </div>
            <div class="form-control">
                <label class="label">
                    <span class="label-text ">ایمیل</span>
                </label>
                <input type="email" name="email" value="<?php echo htmlspecialchars($User['email']); ?>" class="input input-bordered" required>
            </div>
            <div class="form-control">
                <label class="label">
                    <span class="label-text">شماره تلفن</span>
                </label>
                <input type="text" name="phone" value="<?php echo htmlspecialchars($User['phone']); ?>" class="input input-bordered" required>
            </div>
            <div class="form-control">
                <label class="label">
                    <span class="label-text ">نقش کاربر</span>
                </label>
                <select name="role" class="select select-bordered" required>
                    <option value="مدیر" <?php echo $User['role'] === 'مدیر' ? 'selected' : ''; ?>>مدیر</option>
                    <option value="کاربر" <?php echo $User['role'] === 'کاربر' ? 'selected' : ''; ?>>کاربر عادی</option>
                    <option value="انباردار" <?php echo $User['role'] === 'انباردار' ? 'selected' : ''; ?>>انباردار</option>
                </select>
            </div>
            <div class="form-control">
                <label class="label">
                    <span class="label-text">وضعیت کاربر</span>
                </label>
                <select name="status" class="select select-bordered" required>
                    <option value="0" <?php echo $User['status'] == 0 ? 'selected' : ''; ?>>فعال</option>
                    <option value="1" <?php echo $User['status'] == 1 ? 'selected' : ''; ?>>غیرفعال</option>
                </select>
            </div>
            <div class="form-control">
                <label class="label">
                    <span class="label-text">تصویر کاربر</span>
                </label>
                <?php if (!empty($User['picture'])): ?>
                    <div class="mb-2">
                        <img src="<?php echo htmlspecialchars($User['picture']); ?>" alt="User Picture" style="max-width:100px;max-height:100px;">
                    </div>
                <?php endif; ?>
                <input type="file" name="picture" accept="image/*" class="file-input file-input-bordered">
            </div>
            <div class="form-control mt-6">
                <button type="submit" name="userForm" value="updateUser" class="btn btn-primary">ذخیره تغییرات</button>
            </div>
            <input type="hidden" name="userid" value="<?php echo $userid; ?>">
        </form>
    </div>
    
</div>