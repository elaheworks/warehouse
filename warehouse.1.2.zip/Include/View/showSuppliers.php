<?php include_once "./Include/View/header.php"; ?>

<div class="w-full mx-auto p-6 bg-base-100 shadow-lg rounded-lg">
    <div class="flex justify-between items-center mb-4">
        <div></div>
        <button class="btn btn-primary" onclick="add_supplier_modal.showModal()">
            <i class="fa-solid fa-plus"></i> افزودن تأمین‌کننده
        </button>
    </div>

    <details class="collapse collapse-arrow bg-base-200 mb-4">
        <summary class="collapse-title text-md font-medium">فیلترها</summary>
        <div class="collapse-content">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="label">نام تأمین‌کننده</label>
                    <input type="text" class="column-filter input input-bordered input-sm w-full" data-column="name" placeholder="فیلتر نام">
                </div>
                <div>
                    <label class="label">وضعیت</label>
                    <select class="column-filter select select-bordered select-sm w-full" data-column="status">
                        <option value="">همه</option>
                        <option value="1">فعال</option>
                        <option value="0">غیرفعال</option>
                    </select>
                </div>
            </div>
        </div>
    </details>

    <div class="overflow-auto h-screen">
        <table class="table w-full">
            <thead>
                <tr>
                    <th>#</th>
                    <th>نام تأمین‌کننده</th>
                    <th>تلفن ویزیتور</th>
                    <th>تلفن شرکت</th>
                    <th>تلفن مدیر پخش</th>
                    <th>وضعیت</th>
                    <th>تاریخ ثبت</th>
                    <th>آخرین ویرایش</th>
                    <th></th>
                </tr>
            </thead>
            <?php if (!empty($paginatedSuppliers)): ?>
                <tbody id="suppliers-table-body">
                    <?php foreach ($paginatedSuppliers as $index => $supplier): ?>
                        <tr class="hover" data-status="<?php echo $supplier['status']; ?>">
                            <th><?php echo $offset + $index + 1; ?></th>
                            <td><?php echo htmlspecialchars($supplier['name']); ?></td>
                            <td><?php echo htmlspecialchars($supplier['visitor_phone']); ?></td>
                            <td><?php echo htmlspecialchars($supplier['company_phone']); ?></td>
                            <td><?php echo htmlspecialchars($supplier['manager_phone']); ?></td>
                            <td>
                                <?php if ($supplier['status'] == 1): ?>
                                    <span class="badge badge-success">فعال</span>
                                <?php else: ?>
                                    <span class="badge badge-error">غیرفعال</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo $supplier['reg_date']; ?></td>
                            <td><?php echo $supplier['last_edit'] ?: '-'; ?></td>
                            <td class="text-end space-x-1">
                                <button class="btn btn-outline btn-secondary btn-xs" onclick="detail_modal_<?php echo $supplier['id']; ?>.showModal()">
                                    <i class="fa-solid fa-info-circle"></i>
                                </button>
                                <a href="?Page=editSupplier&id=<?php echo $supplier['id']; ?>" class="btn btn-outline btn-primary btn-xs">
                                    <i class="fa-solid fa-edit"></i>
                                </a>
                                <button class="btn btn-outline btn-error btn-xs" onclick="delete_modal_<?php echo $supplier['id']; ?>.showModal()">
                                    <i class="fa-solid fa-trash"></i>
                                </button>
                            </td>
                        </tr>

                        <!-- Detail Modal -->
                        <dialog id="detail_modal_<?php echo $supplier['id']; ?>" class="modal">
                            <div class="modal-box max-w-lg">
                                <h3 class="text-lg font-bold mb-2">جزئیات تأمین‌کننده</h3>
                                <div class="space-y-1 text-sm">
                                    <p><strong>نام:</strong> <?php echo htmlspecialchars($supplier['name']); ?></p>
                                    <p><strong>تلفن ویزیتور:</strong> <?php echo htmlspecialchars($supplier['visitor_phone']); ?></p>
                                    <p><strong>تلفن شرکت:</strong> <?php echo htmlspecialchars($supplier['company_phone']); ?></p>
                                    <p><strong>تلفن مدیر پخش:</strong> <?php echo htmlspecialchars($supplier['manager_phone']); ?></p>
                                    <p><strong>آدرس:</strong> <?php echo htmlspecialchars($supplier['address']); ?></p>
                                    <p><strong>توضیحات:</strong> <?php echo htmlspecialchars($supplier['description']); ?></p>
                                    <p><strong>شماره حساب/شبا/کارت:</strong> <?php echo htmlspecialchars($supplier['account_number']); ?></p>
                                    <p><strong>وضعیت:</strong> <?php echo $supplier['status'] == 1 ? 'فعال' : 'غیرفعال'; ?></p>
                                    <p><strong>تاریخ ثبت:</strong> <?php echo $supplier['reg_date']; ?></p>
                                    <p><strong>آخرین ویرایش:</strong> <?php echo $supplier['last_edit'] ?: '-'; ?></p>
                                </div>
                                <div class="modal-action">
                                    <form method="dialog">
                                        <button class="btn">بستن</button>
                                    </form>
                                </div>
                            </div>
                        </dialog>

                        <!-- Delete Modal -->
                        <dialog id="delete_modal_<?php echo $supplier['id']; ?>" class="modal">
                            <div class="modal-box">
                                <h3 class="text-lg font-bold">حذف تأمین‌کننده</h3>
                                <p class="py-4">آیا از حذف "<?php echo htmlspecialchars($supplier['name']); ?>" مطمئن هستید؟</p>
                                <div class="modal-action">
                                    <form method="post">
                                        <input type="hidden" name="supplier_id" value="<?php echo $supplier['id']; ?>">
                                        <button type="submit" name="supplierForm" value="deleteSupplier" class="btn btn-error">حذف</button>
                                        <button type="button" class="btn" onclick="this.closest('dialog').close()">لغو</button>
                                    </form>
                                </div>
                            </div>
                        </dialog>
                    <?php endforeach; ?>
                </tbody>
            <?php else: ?>
                <tbody><tr><td colspan="9" class="text-center">تأمین‌کننده‌ای برای نمایش وجود ندارد.</td></tr></tbody>
            <?php endif; ?>
        </table>
    </div>

    <!-- Add Supplier Modal -->
    <dialog id="add_supplier_modal" class="modal">
        <div class="modal-box max-w-xl">
            <h3 class="font-bold text-lg mb-4">افزودن تأمین‌کننده جدید</h3>
            <form method="POST">
                <input type="hidden" name="supplierForm" value="addSupplier">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="label">نام تأمین‌کننده</label>
                        <input type="text" name="name" class="input input-bordered w-full" required>
                    </div>
                    <div>
                        <label class="label">تلفن ویزیتور</label>
                        <input type="text" name="visitor_phone" class="input input-bordered w-full">
                    </div>
                    <div>
                        <label class="label">تلفن شرکت</label>
                        <input type="text" name="company_phone" class="input input-bordered w-full">
                    </div>
                    <div>
                        <label class="label">تلفن مدیر پخش</label>
                        <input type="text" name="manager_phone" class="input input-bordered w-full">
                    </div>
                    <div class="md:col-span-2">
                        <label class="label">آدرس</label>
                        <input type="text" name="address" class="input input-bordered w-full">
                    </div>
                    <div class="md:col-span-2">
                        <label class="label">توضیحات</label>
                        <textarea name="description" class="textarea textarea-bordered w-full"></textarea>
                    </div>
                    <div class="md:col-span-2">
                        <label class="label">شماره حساب/شبا/کارت</label>
                        <input type="text" name="account_number" class="input input-bordered w-full">
                    </div>
                    <div class="md:col-span-2">
                        <label class="label">وضعیت</label>
                        <select name="status" class="select select-bordered w-full">
                            <option value="1">فعال</option>
                            <option value="0">غیرفعال</option>
                        </select>
                    </div>
                </div>
                <div class="modal-action mt-4">
                    <button type="submit" class="btn btn-success">ثبت</button>
                    <button type="button" class="btn" onclick="add_supplier_modal.close()">لغو</button>
                </div>
            </form>
        </div>
    </dialog>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const filters = document.querySelectorAll('.column-filter');
    const rows = document.querySelectorAll('#suppliers-table-body tr');

    filters.forEach(filter => {
        filter.addEventListener('input', () => {
            const filterName = document.querySelector('[data-column="name"]').value.trim().toLowerCase();
            const filterStatus = document.querySelector('[data-column="status"]').value;

            rows.forEach(row => {
                const name = row.cells[1].textContent.trim().toLowerCase();
                const status = row.getAttribute('data-status');
                let show = true;

                if (filterName && !name.includes(filterName)) show = false;
                if (filterStatus && filterStatus !== status) show = false;

                row.style.display = show ? '' : 'none';
            });
        });
    });
});
</script>
