<?php include_once "./Include/View/header.php"; ?>

<div class="max-w-6xl mx-auto p-6">
    <h2 class="text-3xl font-bold text-primary mb-6">مدیریت تراکنش‌ها</h2>

    <!-- فرم -->
    <form method="post" class="grid grid-cols-1 md:grid-cols-2 gap-4 bg-base-100 p-6 rounded-xl shadow mb-10">
        <input type="hidden" name="transactionForm" value="addTransaction" />

        <input name="payment_method" class="input input-bordered input-primary w-full" placeholder="روش پرداخت" required />
        <select class="select select-primary w-full" name="account" id="">
            <option value="" selected disabled>انتخاب یک حساب</option>
            <?php foreach ($avtiveAccs as $ACC): ?>
                <option value="<?php echo $ACC['id']; ?>"><?php echo $ACC['name']; ?></option>
            <?php endforeach; ?>
            
        </select>
        <input name="tracking_code" class="input input-bordered input-primary w-full" placeholder="کد پیگیری" />
        <input name="rec_date" class="input input-bordered input-primary w-full" placeholder="تاریخ دریافت (YYYY-MM-DD)" / required>

        <select class="lg:col-span-2 select select-primary w-full" name="rec_id" id="">
            <option value="" selected disabled>انتخاب یک کاربر</option>
            <?php foreach ($avtiveUsers as $AUser): ?>
                <option value="<?php echo $AUser['id']; ?>"><?php echo $AUser['name'] . ' (' . $AUser['role'] . ')'; ?></option>
            <?php endforeach; ?>
        </select>


        <button class="btn btn-success btn-block col-span-1 md:col-span-2">ثبت تراکنش</button>
    </form>

    <!-- جدول -->
   <div class="overflow-x-auto rounded-xl shadow mb-10">
    <!-- 🔍 فیلتر جستجو -->
    <div class="flex justify-end p-4">
        <input id="searchInput" type="text" placeholder="جستجو..." class="input input-bordered w-full max-w-xs" />
    </div>

    <!-- جدول -->
    <table id="transactionsTable" class="table table-zebra w-full text-center text-sm">
        <thead class="bg-primary text-primary-content cursor-pointer">
            <tr>
                <th onclick="sortTable(0)">#</th>
                <th onclick="sortTable(1)">روش پرداخت</th>
                <th onclick="sortTable(2)">حساب</th>
                <th onclick="sortTable(3)">کد پیگیری</th>
                <th onclick="sortTable(4)">تاریخ ثبت</th>
                <th onclick="sortTable(5)">تاریخ دریافت</th>
                <th onclick="sortTable(6)">ثبت‌کننده</th>
                <th onclick="sortTable(7)">گیرنده</th>
                <th onclick="sortTable(8)">وضعیت</th>
                <th>عملیات</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($transactionsList != -1): foreach ($transactionsList as $i => $t): ?>
                <tr>
                    <td><?= $i + 1 ?></td>
                    <td><?= htmlspecialchars($t['payment_method']) ?></td>
                    <td><?= htmlspecialchars($t['account_name']) ?></td>
                    <td><?= htmlspecialchars($t['tracking_code']) ?></td>
                    <td><?= $t['reg_date'] ?></td>
                    <td><?= $t['rec_date'] ?? '-' ?></td>
                    <td><?= $t['reg_name'] ?> (<?= $t['reg_role'] ?>)</td>
                    <td><?= $t['rec_name'] ?? '-' ?> (<?= $t['reg_role'] ?>)</td>
                    
                    <td>
                        <span class="badge <?= $t['status'] == 1 ? 'badge-success' : 'badge-error' ?>">
                            <?= $t['status'] == 1 ? 'فعال' : 'غیرفعال' ?>
                        </span>
                    </td>
                    <td>
                        <form method="post" onsubmit="return confirm('آیا مطمئن هستید؟');">
                            <input type="hidden" name="transactionid" value="<?= $t['id'] ?>">
                            <button name="transactionForm" value="deleteTransaction"
                                class="btn btn-xs btn-outline btn-error">حذف</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; endif; ?>
        </tbody>
    </table>
</div>
</div>
<!-- اسکریپت جستجو و مرتب‌سازی -->
<script>
    const searchInput = document.getElementById("searchInput");
    searchInput.addEventListener("keyup", function () {
        const term = this.value.toLowerCase();
        const rows = document.querySelectorAll("#transactionsTable tbody tr");

        rows.forEach(row => {
            const text = row.textContent.toLowerCase();
            row.style.display = text.includes(term) ? "" : "none";
        });
    });

    let sortDir = true;
    function sortTable(colIndex) {
        const table = document.getElementById("transactionsTable");
        const tbody = table.tBodies[0];
        const rows = Array.from(tbody.querySelectorAll("tr"));

        rows.sort((a, b) => {
            const A = a.cells[colIndex].textContent.trim();
            const B = b.cells[colIndex].textContent.trim();

            return sortDir
                ? A.localeCompare(B, 'fa', { numeric: true })
                : B.localeCompare(A, 'fa', { numeric: true });
        });

        rows.forEach(row => tbody.appendChild(row));
        sortDir = !sortDir;
    }
</script>

