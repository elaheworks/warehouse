<?php include_once "./Include/View/header.php"; ?>
<div class="w-full mx-auto p-6 bg-base-100 shadow-lg rounded-lg">
    <div class="flex justify-between items-center mb-4">
        <div></div>
        <button class="btn btn-primary" onclick="add_item_modal.showModal()">
            <i class="fa-solid fa-plus"></i> افزودن آیتم
        </button>
    </div>

    <!-- فیلتر -->
    <details class="collapse collapse-arrow bg-base-200 mb-4">
        <summary class="collapse-title text-md font-medium">فیلترها</summary>
        <div class="collapse-content">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                    <label class="label">نام محصول</label>
                    <input type="text" class="column-filter input input-bordered input-sm w-full" data-column="product" placeholder="فیلتر نام محصول">
                </div>
                <div>
                    <label class="label">تأمین‌کننده</label>
                    <input type="text" class="column-filter input input-bordered input-sm w-full" data-column="supplier" placeholder="فیلتر تأمین‌کننده">
                </div>
                <div>
                    <label class="label">وضعیت</label>
                    <select class="column-filter select select-bordered select-sm w-full" data-column="status">
                        <option value="">همه</option>
                        <option value="0">فعال</option>
                        <option value="1">غیرفعال</option>
                    </select>
                </div>
            </div>
        </div>
    </details>

    <div class="overflow-auto h-screen">
        <table class="table w-full">
            <thead>
                <tr>
                    <th>#</th>
                    <th>نام محصول</th>
                    <th>تأمین‌کننده</th>
                    <th>قیمت واحد</th>
                    <th>مقدار</th>
                    <th>وضعیت</th>
                    <th></th>
                </tr>
            </thead>
            <?php if (!empty($paginatedItems)):
                $count = $offset; ?>
                <tbody id="items-table-body">
                    <?php foreach ($paginatedItems as $item): $count++; ?>
                        <tr class="hover" data-status="<?php echo $item['status']; ?>">
                            <th><?php echo $count; ?></th>
                            <td><?php echo htmlspecialchars($item['product']); ?></td>
                            <td><?php echo htmlspecialchars($item['supplier_name']); ?></td>
                            <td><?php echo number_format($item['unit_price']); ?></td>
                            <td><?php echo $item['quantity']; ?></td>
                            <td>
                                <?php if ($item['status'] == 0): ?>
                                    <span class="badge badge-success">فعال</span>
                                <?php else: ?>
                                    <span class="badge badge-error">غیرفعال</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end space-x-1">
                                <button class="btn btn-outline btn-secondary btn-xs" onclick="detail_modal_<?php echo $item['id']; ?>.showModal()">
                                    <i class="fa-solid fa-info-circle"></i>
                                </button>
                                <a href="?Page=editItem&item=<?php echo $item['id']; ?>" class="btn btn-outline btn-primary btn-xs">
                                    <i class="fa-solid fa-edit"></i>
                                </a>
                                <button class="btn btn-outline btn-error btn-xs" onclick="delete_modal_<?php echo $item['id']; ?>.showModal()">
                                    <i class="fa-solid fa-trash"></i>
                                </button>
                            </td>
                        </tr>

                        <!-- Detail Modal -->
                        <dialog id="detail_modal_<?php echo $item['id']; ?>" class="modal">
                            <div class="modal-box">
                                <h3 class="text-lg font-bold">جزئیات آیتم</h3>
                                <div class="py-4 space-y-1 text-sm">
                                    <p><strong>شناسه:</strong> <?php echo $item['id']; ?></p>
                                    <p><strong>نام محصول:</strong> <?php echo htmlspecialchars($item['product']); ?></p>
                                    <p><strong>برند:</strong> <?php echo htmlspecialchars($item['brand']); ?></p>
                                    <p><strong>تأمین‌کننده:</strong> <?php echo htmlspecialchars($item['supplier_name']); ?></p>
                                    <p><strong>دسته‌بندی:</strong> <?php echo htmlspecialchars($item['category_name']); ?></p>
                                    <p><strong>قیمت واحد:</strong> <?php echo number_format($item['unit_price']); ?></p>
                                    <p><strong>مقدار:</strong> <?php echo $item['quantity']; ?></p>
                                    <p><strong>سطح هشدار:</strong> <?php echo $item['par_level']; ?></p>
                                    <p><strong>واحد:</strong> <?php echo htmlspecialchars($item['unit_name']); ?></p>
                                    <p><strong>محل نگهداری:</strong> <?php echo htmlspecialchars($item['storage_location']); ?></p>
                                    <p><strong>ثبت‌کننده:</strong> <?php echo htmlspecialchars($item['reg_name']); ?></p>
                                    <p><strong>تاریخ ثبت:</strong> <?php echo $item['reg_date']; ?></p>
                                    <p><strong>ویرایش‌کننده:</strong> <?php echo htmlspecialchars($item['rec_name']); ?></p>
                                    <p><strong>تاریخ ویرایش:</strong> <?php echo $item['rec_date']; ?></p>
                                    <p><strong>آخرین لاگ:</strong> <?php echo htmlspecialchars($item['lastlog_name']); ?></p>
                                    <p><strong>آخرین ویرایش:</strong> <?php echo $item['last_edit']; ?></p>
                                    <p><strong>وضعیت:</strong> <?php echo $item['status'] == 0 ? 'فعال' : 'غیرفعال'; ?></p>
                                </div>
                                <div class="modal-action">
                                    <form method="dialog">
                                        <button class="btn">بستن</button>
                                    </form>
                                </div>
                            </div>
                        </dialog>

                        <!-- Delete Modal -->
                        <dialog id="delete_modal_<?php echo $item['id']; ?>" class="modal">
                            <div class="modal-box">
                                <h3 class="text-lg font-bold">تأیید حذف</h3>
                                <p class="py-4">آیا مطمئنید که می‌خواهید "<?php echo htmlspecialchars($item['product']); ?>" را حذف کنید؟</p>
                                <div class="modal-action">
                                    <form method="post" action="">
                                        <input type="hidden" name="itemid" value="<?php echo $item['id']; ?>">
                                        <button name="itemForm" value="deleteItem" class="btn btn-error">حذف</button>
                                        <button type="button" class="btn" onclick="delete_modal_<?php echo $item['id']; ?>.close()">لغو</button>
                                    </form>
                                </div>
                            </div>
                        </dialog>
                    <?php endforeach; ?>
                </tbody>
            <?php else: ?>
                <tbody>
                    <tr>
                        <td colspan="7" class="text-center">آیتمی یافت نشد.</td>
                    </tr>
                </tbody>
            <?php endif; ?>
        </table>
    </div>

    <!-- Pagination -->
    <?php if ($totalPages > 1): ?>
        <div class="flex justify-center mt-4">
            <div class="join">
                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                    <a href="?Page=showItems&P=<?php echo $i; ?>" class="join-item btn <?php echo $P == $i ? 'btn-active' : ''; ?>"><?php echo $i; ?></a>
                <?php endfor; ?>
            </div>
        </div>
    <?php endif; ?>

    <!-- Add Item Modal -->
    <dialog id="add_item_modal" class="modal">
        <div class="modal-box max-w-xl">
            <h3 class="font-bold text-lg mb-4">افزودن آیتم جدید</h3>
            <form method="post" action="">
                <input type="hidden" name="itemForm" value="addItem">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">

                    <!-- نام محصول -->
                    <div>
                        <label class="label">نام محصول</label>
                        <input type="text" name="product" class="input input-bordered w-full" placeholder="نام محصول" required>
                    </div>

                    <div>
                        <label class="label">برند</label>
                        <input type="text" name="brand" class="input input-bordered w-full" placeholder="برند">
                    </div>

                    <!-- تأمین‌کننده -->
                    <div>
                        <label class="label">تأمین‌کننده</label>
                        <select id="add_supplier_select" name="supplier_id" class="select select-bordered w-full" required>
                            <?php foreach ($suppliersList as $s): ?>
                                <option value="<?= $s['id']; ?>"><?= htmlspecialchars($s['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- دسته‌بندی -->
                    <div>
                        <label class="label">دسته‌بندی</label>
                        <select name="category_id" class="select select-bordered w-full" required>
                            <?php foreach ($categoriesList as $c): ?>
                                <option value="<?= $c['id']; ?>"><?= htmlspecialchars($c['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label class="label">کالای مادر</label>
                        <select name="master_item_id" id="master_item_id" class="select select-bordered w-full" required>
                            <option disabled selected>انتخاب کالای مادر</option>
                            <?php foreach ($masterItemsList as $m): ?>
                                <option value="<?= $m['id']; ?>"><?= htmlspecialchars($m['product_name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label class="label">واحد</label>
                        <select name="unit_id" class="select select-bordered w-full" required>
                            <?php foreach ($unitsList as $u): ?>
                                <option value="<?= $u['id']; ?>"><?= htmlspecialchars($u['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- قیمت واحد -->
                    <div>
                        <label class="label">قیمت واحد (ریال)</label>
                        <input type="number" name="unit_price" class="input input-bordered w-full" placeholder="قیمت واحد" min="1" required>
                    </div>

                    <!-- مقدار -->
                    <div>
                        <label class="label">مقدار</label>
                        <input type="number" name="quantity" class="input input-bordered w-full" placeholder="مقدار" min="0" required>
                    </div>



                    <!-- هشدار لول -->
                    <div>
                        <label class="label">سطح هشدار</label>
                        <input type="number" name="par_level" class="input input-bordered w-full" placeholder="هشدار لول" min="0">
                    </div>


                    <!-- محل ذخیره -->
                    <div>
                        <label class="label">محل نگهداری</label>
                        <input type="text" name="storage_location" class="input input-bordered w-full" placeholder="محل نگهداری">
                    </div>

                    <!-- وضعیت -->
                    <div class="md:col-span-2">
                        <label class="label">وضعیت</label>
                        <select name="status" class="select select-bordered w-full">
                            <option value="0">فعال</option>
                            <option value="1">غیرفعال</option>
                        </select>
                    </div>
                </div>

                <div class="modal-action mt-4">
                    <button type="submit" class="btn btn-success">ثبت</button>
                    <button type="button" class="btn" onclick="add_item_modal.close()">لغو</button>
                </div>
            </form>
        </div>
    </dialog>


</div>
<script>
    $(function() {
        // TomSelect برای تأمین‌کننده مدال افزودن آیتم
        new TomSelect("#add_supplier_select", {
            create: false,
            sortField: {
                field: "text",
                direction: "asc"
            }
        });
    });
</script>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        const filters = document.querySelectorAll('.column-filter');
        const rows = document.querySelectorAll('#items-table-body tr');

        filters.forEach(filter => {
            filter.addEventListener('input', () => {
                const filterProduct = document.querySelector('[data-column="product"]').value.trim().toLowerCase();
                const filterSupplier = document.querySelector('[data-column="supplier"]').value.trim().toLowerCase();
                const filterStatus = document.querySelector('[data-column="status"]').value;

                rows.forEach(row => {
                    const product = row.cells[1].textContent.trim().toLowerCase();
                    const supplier = row.cells[2].textContent.trim().toLowerCase();
                    const status = row.getAttribute('data-status');

                    let show = true;
                    if (filterProduct && !product.includes(filterProduct)) show = false;
                    if (filterSupplier && !supplier.includes(filterSupplier)) show = false;
                    if (filterStatus && filterStatus !== status) show = false;

                    row.style.display = show ? '' : 'none';
                });
            });
        });
    });
</script>
<script>
    document.addEventListener('DOMContentLoaded', () => {
        new TomSelect('#master_item_id', {
            maxItems: 1,
            searchField: ['text'],
            create: false,
            placeholder: "جستجو و انتخاب کالای مادر",
        });
    });
</script>