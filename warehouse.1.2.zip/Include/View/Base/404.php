<?php include_once "./Include/View/header.php"; ?>
<section>
    <div class="min-h-screen flex items-center justify-center">
        <div class="card shadow-xl rounded-lg text-center overflow-hidden w-full md:w-3/5">
            <div class="card-body">
                <h3>خیلی اشتباه اومدی!</h3>
                <a href="<?php echo $_SESSION['WebsiteUrl']; ?>" class="btn btn-primary w-full mt-3">برگردیم</a>
            </div>
        </div>
    </div>
</section>