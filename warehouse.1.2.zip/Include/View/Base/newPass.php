<?php
// Check if the theme cookie is set, and set default to 'nord' if not
$theme = isset($_COOKIE['theme']) ? $_COOKIE['theme'] : 'nord';
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
  <title>شهر کاغذی | تغییر رمز عبور</title>
  <!-- DaisyUI and Tailwind CSS -->
  <link href="assets/css/daisy.css" rel="stylesheet" type="text/css" />
  <script src="assets/js/daisy.js"></script>
  <!-- Font Awesome Icons -->
  <link href="assets/fontawesome/css/all.css" rel="stylesheet">
  <!-- Custom Styles -->
  <link href="assets/css/my.css" rel="stylesheet" type="text/css" />
  <style>
    html {
      --theme: <?php echo htmlspecialchars($theme, ENT_QUOTES, 'UTF-8'); ?>;
    }
  </style>
</head>

<body class="bg-base-200" data-theme="<?php echo $theme; ?>">
  <div class="container mx-auto p-4">
    <main class="main-content mt-0">
      <section>
        <div class="min-h-screen flex items-center justify-center">
          <div class="card shadow-xl rounded-lg overflow-hidden w-full md:w-3/5">
            <div class="grid grid-cols-1">
              <!-- Form Section -->
              <div class="card-body p-8 bg-base-100">
                <h3 class="card-title text-2xl font-bold text-primary">تغییر رمز عبور</h3>
                <p class="text-base-content">لطفاً رمز عبور جدید خود را وارد کنید.</p>
                <?php echo $Alert; ?>

                <form id="resetForm" action="" method="post" class="mt-6">
                  <div class="form-control">
                    <label class="label text-base-content">رمز عبور جدید</label>
                    <input type="password" id="password" class="input input-bordered w-full" name="password" placeholder="رمز عبور جدید را وارد کنید" required>
                  </div>
                  <div class="form-control mt-6">
                    <label class="label text-base-content">تأیید رمز عبور</label>
                    <input type="password" id="confirm_password" class="input input-bordered w-full" name="confirm_password" placeholder="رمز عبور جدید را تأیید کنید" required>
                  </div>
                  <div class="form-control mt-6">
                    <button type="submit" id="submitBtn" name="ForgotPasswordForm" value="NEW" class="btn btn-primary w-full">تغییر رمز عبور</button>
                  </div>
                </form>
                <div class="mt-4 text-center">
                  <a href="<?php echo $_SESSION['WebsiteUrl']; ?>" class="link text-sm">بازگشت به صفحه ورود</a>
                </div>

              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  </div>

  <script>
  document.addEventListener('DOMContentLoaded', function() {
    const passwordInput = document.getElementById('password');
    const confirmPasswordInput = document.getElementById('confirm_password');
    const submitBtn = document.getElementById('submitBtn');
    
    // Function to validate if passwords match
    function validatePasswords() {
      if (passwordInput.value !== confirmPasswordInput.value) {
        confirmPasswordInput.setCustomValidity('رمز عبور ها مطابقت ندارند.');
      } else {
        confirmPasswordInput.setCustomValidity('');
      }
    }

    // Attach event listeners to validate passwords in real-time
    passwordInput.addEventListener('input', validatePasswords);
    confirmPasswordInput.addEventListener('input', validatePasswords);

    // Optionally, disable the submit button if passwords do not match
    function toggleSubmitButton() {
      if (passwordInput.value && confirmPasswordInput.value && passwordInput.value === confirmPasswordInput.value) {
        submitBtn.disabled = false;
      } else {
        submitBtn.disabled = true;
      }
    }

    // Attach event listeners to toggle submit button
    passwordInput.addEventListener('input', toggleSubmitButton);
    confirmPasswordInput.addEventListener('input', toggleSubmitButton);

    // Initial check to disable button if passwords do not match
    toggleSubmitButton();
  });
</script>

</body>

</html>
