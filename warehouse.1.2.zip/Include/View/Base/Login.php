<?php
// Check if the theme cookie is set, and set default to 'nord' if not
$theme = isset($_COOKIE['theme']) ? $_COOKIE['theme'] : 'nord';
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
  <title>شهر کاغذی | ورود به پنل کاربری</title>
  <!-- DaisyUI and Tailwind CSS -->
  <link href="assets/css/daisy.css" rel="stylesheet" type="text/css" />
  <script src="assets/js/daisy.js"></script>
  <!-- Font Awesome Icons -->
  <link href="assets/fontawesome/css/all.css" rel="stylesheet">
  <!-- Custom Styles -->
  <link href="assets/css/my.css" rel="stylesheet" type="text/css" />
  <style>
    html {
      --theme: <?php echo htmlspecialchars($theme, ENT_QUOTES, 'UTF-8'); ?>;
    }
  </style>
</head>

<body class="bg-base-200" data-theme="<?php echo $theme; ?>">
  <div class="container mx-auto p-4">
    <main class="main-content mt-0">
      <section>
        <div class="min-h-screen flex items-center justify-center">
          <div class="card shadow-xl rounded-lg overflow-hidden w-full md:w-3/5">
            <?php echo $Alert; ?>
            <div class="grid grid-cols-1">
              
              <!-- Form Section -->
              <div class="card-body p-8 bg-base-100">
                <h3 class="card-title text-2xl font-bold text-primary">خوش اومدی</h3>
                <p class="text-base-content">میشه اطلاعاتت رو وارد کنی؟</p>
                <form action="" method="post" class="mt-6">
                  <div class="form-control">
                    <label class="label text-base-content">نام کاربریت</label>
                    <input type="text" class="input input-bordered w-full" name="username" placeholder="نام کاربری">
                  </div>

                  <div class="form-control mt-4">
                    <label class="label text-base-content">رمزت</label>
                    <input type="password" class="input input-bordered w-full" name="password" placeholder="رمز عبور">
                  </div>

                  <!-- Remember Me Checkbox -->
                  <div class="form-control mt-4">
                    <label class="cursor-pointer label">
                      <span class="label-text">من رو یادت بمونه</span>
                      <input type="checkbox" name="remember_me" class="checkbox checkbox-primary">
                    </label>
                  </div>

                  <div class="form-control mt-6">
                    <button type="submit" name="LoginForm" value="Login" class="btn btn-primary w-full">ورود</button>
                  </div>
                </form>
                <div class="mt-4 text-center">
                  <a href="?P=ForgotPass" class="link text-sm">رمزت رو یادت رفته؟</a>
                </div>
                
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  </div>
</body>

</html>