<?php include_once "./Include/View/header.php"; ?>

<div class="w-full mx-auto p-6 bg-base-100 shadow-lg rounded-lg">
    <div class="flex justify-between items-center mb-4">
        <!-- <input type="text" data-target="users-table-body" class="table-filter input input-bordered w-full max-w-md" placeholder="جستجو در کاربران..."> -->
       <div></div>
        <button class="btn btn-primary" onclick="add_user_modal.showModal()">
            <i class="fa-solid fa-plus"></i> افزودن کاربر
        </button>
    </div>

    <!-- Minimal Filter Section -->
    <details class="collapse collapse-arrow bg-base-200 mb-4">
        <summary class="collapse-title text-md font-medium">فیلترها</summary>
        <div class="collapse-content">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                    <label class="label">نام</label>
                    <input type="text" class="column-filter input input-bordered input-sm w-full" data-column="name" placeholder="فیلتر نام">
                </div>
                <div>
                    <label class="label">نقش</label>
                    <select class="column-filter select select-bordered select-sm w-full" data-column="role">
                        <option value="">همه</option>
                        <option value="مدیر">مدیر</option>
                        <option value="کاربر">کاربر</option>
                        <option value="انباردار">انباردار</option>
                    </select>
                </div>
                <div>
                    <label class="label">وضعیت</label>
                    <select class="column-filter select select-bordered select-sm w-full" data-column="status">
                        <option value="">همه</option>
                        <option value="0">فعال</option>
                        <option value="1">غیرفعال</option>
                    </select>
                </div>
            </div>
        </div>
    </details>

    <div class="overflow-auto h-screen">
        <table class="table w-full">
            <!-- Table Head -->
            <thead>
                <tr>
                    <th>#</th>
                    <th>نام</th>
                    <th>تلگرام</th>
                    <th>شماره تلفن</th>
                    <th>نقش</th>
                    <th>وضعیت</th>
                    <th></th>
                </tr>
            </thead>
            <!-- Table Body -->
            <?php if ($allUsers != -1): ?>
                <tbody id="users-table-body">
                    <?php foreach ($allUsers as $user): ?>
                        <tr class="hover" data-status="<?php echo $user['status']; ?>">
                            <th class="flex items-center space-x-3"><img src="<?php echo $user['pic']; ?>" alt="عکس کاربر" class="w-12 h-12 rounded-full me-2"></th>
                            <td><?php echo $user['name']; ?></td>
                            <td><?php echo $user['tel_id']; ?></td>
                            <td><?php echo $user['phone']; ?></td>
                            <td><?php echo $user['role']; ?></td>
                            <td>
                                <?php if ($user['status'] == 0): ?>
                                    <span class="badge badge-success">فعال</span>
                                <?php else: ?>
                                    <span class="badge badge-error">غیرفعال</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end">
                                <button class="btn btn-outline btn-secondary btn-xs" onclick="detail_modal_<?php echo $user['id']; ?>.showModal()">
                                    <i class="fa-solid fa-info-circle"></i>
                                </button>
                                <a href="?Page=editUser&user=<?php echo $user['id']; ?>" class="btn btn-outline btn-primary btn-xs">
                                    <i class="fa-solid fa-edit"></i>
                                </a>
                                <button class="btn btn-outline btn-error btn-xs" onclick="delete_modal_<?php echo $user['id']; ?>.showModal()">
                                    <i class="fa-solid fa-trash"></i>
                                </button>
                            </td>
                        </tr>

                        <!-- Detail Modal -->
                        <dialog id="detail_modal_<?php echo $user['id']; ?>" class="modal">
                            <div class="modal-box">
                                <h3 class="text-lg font-bold">جزئیات کاربر</h3>
                                <div class="py-4">
                                    <p><strong>نام:</strong> <?php echo $user['name']; ?></p>
                                    <p><strong>نام کاربری:</strong> <?php echo $user['username']; ?></p>
                                    <p><strong>ایمیل:</strong> <?php echo $user['email']; ?></p>
                                    <p><strong>تلگرام:</strong> <?php echo $user['tel_id']; ?></p>
                                    <p><strong>شماره تلفن:</strong> <?php echo $user['phone']; ?></p>
                                    <p><strong>نقش:</strong> <?php echo $user['role']; ?></p>
                                    <p><strong>تاریخ ثبت:</strong> <?php echo $user['reg_date']; ?></p>
                                    <p><strong>وضعیت:</strong> <?php if($user['status'] == 0) {echo "فعال";} else {echo "غیر فعال";} ?></p>
                                </div>
                                <div class="modal-action">
                                    <form method="dialog">
                                        <button class="btn">بستن</button>
                                    </form>
                                </div>
                            </div>
                        </dialog>

                        <!-- Delete Confirmation Modal -->
                        <dialog id="delete_modal_<?php echo $user['id']; ?>" class="modal">
                            <div class="modal-box">
                                <h3 class="text-lg font-bold">تأیید حذف</h3>
                                <p class="py-4">آیا مطمئن هستید که می‌خواهید کاربر "<?php echo $user['name']; ?>" را حذف کنید؟</p>
                                <div class="modal-action">
                                    <form method="post" action="">
                                        <input type="hidden" name="userid" value="<?php echo $user['id']; ?>">
                                        <button class="btn btn-error" name="userForm" value="deleteUser">حذف</button>
                                        <button class="btn">لغو</button>
                                    </form>
                                </div>
                            </div>
                        </dialog>
                    <?php endforeach; ?>
                </tbody>
            <?php else: ?>
                <tbody>
                    <tr>
                        <td colspan="7" class="text-center">کاربری یافت نشد</td>
                    </tr>
                </tbody>
            <?php endif; ?>
        </table>
    </div>
</div>

<!-- Add User Modal -->
<dialog id="add_user_modal" class="modal">
    <div class="modal-box">
        <h3 class="text-lg font-bold">افزودن کاربر جدید</h3>
        <form method="POST" action="">
            <div class="py-4 space-y-4">
                <div>
                    <label class="label">نام</label>
                    <input type="text" name="name" class="input input-bordered w-full" placeholder="نام کامل" required>
                </div>
                <div>
                    <label class="label">نام کاربری</label>
                    <input type="text" name="username" class="input input-bordered w-full" placeholder="نام کاربری" required>
                </div>
                <div>
                    <label class="label">رمز عبور</label>
                    <input type="password" name="password" class="input input-bordered w-full" placeholder="رمز عبور" required>
                </div>
                <div>
                    <label class="label">تلگرام</label>
                    <input type="text" name="telegram" class="input input-bordered w-full" placeholder="تلگرام" required>
                </div>
                <div>
                    <label class="label">ایمیل</label>
                    <input type="email" name="email" class="input input-bordered w-full" placeholder="ایمیل" required>
                </div>
                <div>
                    <label class="label">شماره تلفن</label>
                    <input type="text" name="phone" class="input input-bordered w-full" placeholder="شماره تلفن" required>
                </div>
                <div>
                    <label class="label">نقش</label>
                    <select name="role" class="select select-bordered w-full" required>
                        <option value="" disabled selected>انتخاب نقش</option>
                        <option value="مدیر">مدیر</option>
                        <option value="کاربر">کاربر</option>
                        <option value="انباردار">انباردار</option>
                    </select>
                </div>
                <div>
                    <label class="label">وضعیت</label>
                    <select name="status" class="select select-bordered w-full" required>
                        <option value="0">فعال</option>
                        <option value="1">غیرفعال</option>
                    </select>
                </div>
            </div>
            <div class="modal-action">
                <button type="submit" name="userForm" value="addUser" class="btn btn-primary">ذخیره</button>
                <button type="button" class="btn" onclick="add_user_modal.close()">لغو</button>
            </div>
        </form>
    </div>
</dialog>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const tableBody = document.getElementById('users-table-body');
    const rows = Array.from(tableBody.getElementsByTagName('tr'));
    const filters = document.querySelectorAll('.column-filter');
    const filterValues = {};

    filters.forEach(filter => {
        filter.addEventListener('input', function() {
            filterValues[this.getAttribute('data-column')] = this.value.toLowerCase().trim();

            rows.forEach(row => {
                const cells = row.getElementsByTagName('td');
                let shouldShow = true;

                if (filterValues.name && cells[0].textContent.toLowerCase().trim().indexOf(filterValues.name) === -1) {
                    shouldShow = false;
                }
                if (filterValues.role && cells[3].textContent.toLowerCase().trim() !== filterValues.role) {
                    shouldShow = false;
                }
                if (filterValues.status && row.getAttribute('data-status') === filterValues.status) {
                    shouldShow = false;
                }

                row.style.display = shouldShow ? '' : 'none';
            });
        });
    });
});
</script>