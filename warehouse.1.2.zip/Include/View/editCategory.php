<?php include_once "./Include/View/header.php"; ?>

<div class="w-full max-w-xl mx-auto p-6 bg-base-100 shadow-lg rounded-lg">
    <div class="flex justify-between items-center mb-6">
        <h2 class="text-xl font-bold text-primary">ویرایش دسته‌بندی</h2>
        <a href="?Page=showCategories" class="btn btn-outline btn-sm">بازگشت</a>
    </div>

    <?php if ($Category): ?>
        <form method="post" action="">
            <input type="hidden" name="categoryForm" value="editCategory">
            <input type="hidden" name="category_id" value="<?= $Category['id']; ?>">

            <div class="space-y-4">
                <!-- نام دسته‌بندی -->
                <div>
                    <label class="label">نام دسته‌بندی</label>
                    <input type="text" name="name" class="input input-bordered w-full"
                           value="<?= htmlspecialchars($Category['name']); ?>" required>
                </div>

                <!-- توضیحات -->
                <div>
                    <label class="label">توضیحات</label>
                    <textarea name="description" rows="3" class="textarea textarea-bordered w-full"
                              placeholder="توضیحات"><?= htmlspecialchars($Category['description']); ?></textarea>
                </div>

                <!-- وضعیت -->
                <div>
                    <label class="label">وضعیت</label>
                    <select name="status" class="select select-bordered w-full" required>
                        <option value="0" <?= $Category['status'] == 0 ? 'selected' : ''; ?>>فعال</option>
                        <option value="1" <?= $Category['status'] == 1 ? 'selected' : ''; ?>>غیرفعال</option>
                    </select>
                </div>
            </div>

            <div class="flex justify-end mt-6 space-x-2">
                <button type="submit" class="btn btn-success">ذخیره تغییرات</button>
                <a href="?Page=showCategories" class="btn">لغو</a>
            </div>
        </form>
    <?php else: ?>
        <div class="alert alert-error">دسته‌بندی مورد نظر یافت نشد.</div>
        <a href="?Page=showCategories" class="btn btn-primary mt-4">بازگشت به لیست</a>
    <?php endif; ?>
</div>
