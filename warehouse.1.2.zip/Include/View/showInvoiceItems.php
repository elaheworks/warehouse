<?php include_once "./Include/View/header.php"; ?>

<div class="mx-auto p-4 space-y-4">
    <h2 class="text-2xl font-bold flex items-center gap-2 text-primary">
        مدیریت آیتم‌های فاکتور: <?= htmlspecialchars($invoiceInfo['invoice_number']); ?>
    </h2>
    <p>تأمین‌کننده: <strong><?= htmlspecialchars($invoiceInfo['supplier_name']); ?></strong></p>

    <!-- فرم افزودن آیتم -->
    <form method="post" class="bg-base-200 p-6 rounded-xl shadow-lg w-full mx-auto grid grid-cols-1 md:grid-cols-6 gap-6">

        <input type="hidden" name="invoice_id" value="<?= $invoiceInfo['id']; ?>">
        <input type="hidden" id="selectedItemId" name="item_id" required>
        <input type="hidden" id="unitId" name="unit_id" value="">

        <!-- انتخاب کالا -->
        <div class="md:col-span-6">
            <label class="label font-semibold">انتخاب کالا</label>
            <div class="flex gap-3">
                <input type="text" id="selectedItemName" placeholder="لطفاً کالا را انتخاب کنید" readonly required
                    class="input input-bordered w-full bg-base-100 cursor-not-allowed focus:outline-none" />
                <button type="button" id="openModalBtn" class="btn btn-primary whitespace-nowrap">
                    انتخاب کالا
                </button>
            </div>
        </div>
        <button type="button" id="suggestBtn" class="btn btn-info md:col-span-6">
            استفاده از مقادیر پیشنهادی آخرین خرید
        </button>


        <!-- مقدار خرید -->
        <div class="md:col-span-3">
            <label for="quantity" class="label font-semibold">مقدار خریداری شده (<span id="buyUnitLabel" class="text-primary">-</span>)</label>
            <input type="number" id="quantity" name="quantity" min="0.01" step="0.01" placeholder="مثلاً 20" required
                class="input input-bordered w-full" />
        </div>

        <!-- قیمت واحد -->
        <div class="md:col-span-3">
            <label for="unit_price" class="label font-semibold">قیمت واحد (ریال)</label>
            <input type="number" id="unit_price" name="unit_price" min="0" step="0.01" placeholder="مثلاً 10000" required
                class="input input-bordered w-full" />
        </div>

        <!-- قیمت برای چه مقدار -->
        <div class="md:col-span-3">
            <label for="price_for_quantity" class="label font-semibold">قیمت برای چه مقدار (<span id="buyUnitLabel2" class="text-primary">-</span>)</label>
            <input type="number" id="price_for_quantity" name="price_for_quantity" min="0.01" step="0.01"
                placeholder="مثلاً هر 950 میلی‌لیتر" class="input input-bordered w-full" />
        </div>

        <!-- تاریخ انقضا -->
        <div class="md:col-span-3">
            <label for="expiration_date" class="label font-semibold">تاریخ انقضا (شمسی)</label>
            <input type="text" id="expirationDateInput" name="expiration_date" placeholder="مثلاً 1402/12/10" required
                class="input input-bordered w-full" dir="ltr" />
        </div>

        <!-- تبدیل واحد خرید به انبار -->
        <div class="md:col-span-6">
            <label class="label font-semibold mb-2">تبدیل واحد خرید به انبار (اختیاری)</label>
            <div class="md:flex gap-4">
                <div class="md:flex-1">
                    <label class="label text-sm text-gray-500">مقدار خریداری شده</label>
                    <input type="number" name="conversion_buy_qty" min="0.01" step="0.01" placeholder="مثلاً 20" class="input input-bordered w-full" />
                </div>
                <div class="md:flex-1">
                    <label class="label text-sm text-gray-500">مقدار معادل در انبار</label>
                    <input type="number" name="conversion_store_qty" min="0.01" step="0.01" placeholder="مثلاً 1000" class="input input-bordered w-full" />
                </div>
                <div class="md:flex-1">
                    <label for="store_unit" class="label text-sm text-gray-500">واحد ذخیره در انبار</label>

                    <select name="store_unit_id" id="unitSelect" class="select select-bordered w-full" required>
                        <?php foreach ($unitsList as $u): ?>
                            <option value="<?= $u['id']; ?>"><?= htmlspecialchars($u['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <p class="text-xs text-gray-400 mt-1">مثال: هر 20 <span id="buyUnitLabel3">واحد</span> برابر با 1000 <span id="buyUnitLabel4"></p>
        </div>


        <!-- تخفیف -->
        <div class="md:col-span-2">
            <label class="label font-semibold">تخفیف</label>
            <div class="flex gap-2">
                <select name="discount_type" class="select select-bordered w-1/3">
                    <option value="amount">ریال</option>
                    <option value="percent">٪ درصد</option>
                </select>
                <input type="number" name="discount_value" step="0.01" placeholder="مقدار تخفیف"
                    class="input input-bordered w-2/3" />
            </div>
        </div>

        <!-- مالیات -->
        <div class="md:col-span-2">
            <label class="label font-semibold">مالیات</label>
            <div class="flex gap-2">
                <select name="tax_type" class="select select-bordered w-1/3">
                    <option value="amount">ریال</option>
                    <option value="percent">٪ درصد</option>
                </select>
                <input type="number" name="tax_value" step="0.01" placeholder="مقدار مالیات"
                    class="input input-bordered w-2/3" />
            </div>
        </div>

        <!-- اشانتیون -->
        <div class="md:col-span-2 flex items-center gap-3">
            <input type="checkbox" name="is_gift" id="is_gift" class="toggle toggle-primary" />
            <label for="is_gift" class="font-semibold cursor-pointer select-none">اشانتیون</label>
        </div>

        <!-- یادداشت -->
        <div class="md:col-span-6">
            <label class="label font-semibold">یادداشت (اختیاری)</label>
            <textarea name="note" rows="3" placeholder="در صورت نیاز ..." class="textarea textarea-bordered w-full"></textarea>
        </div>

        <!-- دکمه ارسال -->
        <button type="submit" name="addItem" value="1" class="btn btn-primary md:col-span-6">
            افزودن به فاکتور
        </button>
    </form>

    <?php if (!empty($invoiceItems)): ?>
        <div class="overflow-x-auto rounded-xl shadow mt-6">
            <table class="table w-full text-center">
                <thead class="bg-secondary text-secondary-content">
                    <tr>
                        <th>#</th>
                        <th>نام کالا</th>
                        <th>مقدار خرید (<span class="text-xs">خرید</span>)</th>
                        <th>مقدار ذخیره (<span class="text-xs">انبار</span>)</th>
                        <th>قیمت واحد (ریال)</th>
                        <th>قیمت برای مقدار</th>
                        <th>تاریخ انقضا</th>
                        <th>تخفیف</th>
                        <th>مالیات</th>
                        <th>اشانتیون</th>
                        <th>قیمت کل (ریال)</th>
                        <th>عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($invoiceItems as $i => $item):
                        $item_total = $item['quantity'] * $item['unit_price'];

                        if (!empty($item['price_for_quantity']) && $item['quantity'] > 0) {
                            $item_total = ($item['unit_price'] / $item['price_for_quantity']) * $item['quantity'];
                        }

                        if ($item['discount_type'] === 'percent') {
                            $item_total -= ($item_total * $item['discount_value'] / 100);
                        } elseif ($item['discount_type'] === 'amount') {
                            $item_total -= $item['discount_value'];
                        }

                        if ($item['tax_type'] === 'percent') {
                            $item_total += ($item_total * $item['tax_value'] / 100);
                        } elseif ($item['tax_type'] === 'amount') {
                            $item_total += $item['tax_value'];
                        }

                        if ($item['is_gift']) {
                            $item_total = 0;
                        }

                        $buyUnit = htmlspecialchars($item['unit_name']);
                        $storeUnit = htmlspecialchars($item['store_unit_name']);
                        if (!empty($item['conversion_buy_qty']) && !empty($item['conversion_store_qty']) && $item['conversion_buy_qty'] > 0) {
                            $convertedQty = ($item['quantity'] / $item['conversion_buy_qty']) * $item['conversion_store_qty'];
                            $conversionText = number_format($convertedQty, 2) . ' ' . $storeUnit;
                        } else {
                            $conversionText = '-';
                        }


                    ?>
                        <tr class="<?= $i % 2 === 0 ? 'bg-base-200' : '' ?>">
                            <td><?= $i + 1 ?></td>
                            <td class="font-semibold"><?= htmlspecialchars($item['item_name']) ?></td>
                            <td><?= htmlspecialchars(number_format($item['quantity']) . ' ' . $buyUnit) ?></td>
                            <td><?= $conversionText ?></td>
                            <td><?= number_format($item['unit_price']) ?></td>
                            <td><?= !empty($item['price_for_quantity']) ? number_format($item['price_for_quantity']) : '-' ?></td>
                            <td><?= htmlspecialchars($item['expiration_date']) ?></td>
                            <td>
                                <?php if ($item['discount_value']):
                                    echo $item['discount_type'] === 'percent'
                                        ? htmlspecialchars($item['discount_value']) . '%'
                                        : number_format($item['discount_value']) . ' ریال';
                                else:
                                    echo '-';
                                endif; ?>
                            </td>
                            <td>
                                <?php if ($item['tax_value']):
                                    echo $item['tax_type'] === 'percent'
                                        ? htmlspecialchars($item['tax_value']) . '%'
                                        : number_format($item['tax_value']) . ' ریال';
                                else:
                                    echo '-';
                                endif; ?>
                            </td>
                            <td><?= $item['is_gift'] ? '✅' : '-' ?></td>
                            <td class="font-bold text-green-600"><?= number_format(max($item_total, 0)) ?></td>
                            <td class="flex gap-2 mt-5">
                                <a href="?Page=editInvoiceItem&Item=<?= $item['id'] ?>" class="btn btn-xs btn-warning">ویرایش</a>
                                <form method="post" class="inline">
                                    <input type="hidden" name="delete_item_id" value="<?= $item['id'] ?>">
                                    <button type="submit" name="deleteItem" class="btn btn-xs btn-error" onclick="return confirm('حذف این آیتم از فاکتور؟')">حذف</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot class="bg-base-300 font-bold">
                    <tr>
                        <td colspan="10" class="text-left">💰 مجموع کل فاکتور:</td>
                        <td colspan="2" class="text-green-700"><?= number_format($invoiceTotal) ?> ریال</td>
                    </tr>
                </tfoot>
            </table>
        </div>
    <?php else: ?>
        <div class="alert alert-info mt-6">هیچ آیتمی برای این فاکتور ثبت نشده است.</div>
    <?php endif; ?>

    <!-- مدال انتخاب کالا -->
    <input type="checkbox" id="itemModal" class="modal-toggle" />
    <div class="modal">
        <div class="modal-box max-w-3xl">
            <h3 class="font-bold text-lg mb-4">انتخاب کالا</h3>
            <div class="flex items-center gap-2 mb-2">
                <input type="checkbox" id="filterSupplierItems" class="toggle toggle-primary" checked />
                <label for="filterSupplierItems">نمایش فقط کالاهای تأمین‌کننده</label>
            </div>
            <input type="text" id="modalSearch" placeholder="جستجو..." class="input input-bordered w-full mb-4">

            <div id="modalItemsContainer" class="grid grid-cols-2 md:grid-cols-3 gap-3 max-h-[50vh] overflow-y-auto">
                <?php foreach ($itemsList as $item): ?>
                    <div class="card border cursor-pointer p-2" data-id="<?= $item['id'] ?>" data-name="<?= htmlspecialchars($item['product']) ?>" data-unitid="<?= htmlspecialchars($item['unit_id']) ?>" data-unit="<?= htmlspecialchars($item['unit_name']) ?>" data-supplierid="<?= $item['supplier_id'] ?>">
                        <div class="font-bold"><?= htmlspecialchars($item['product']) ?></div>
                        <div class="text-sm text-gray-500">تأمین‌کننده: <?= htmlspecialchars($item['supplier_name']) ?></div>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="modal-action">
                <label for="itemModal" class="btn">بستن</label>
            </div>
        </div>
    </div>
</div>
<div id="toastContainer" class="toast toast-top toast-end z-50"></div>


<script>
    document.addEventListener('DOMContentLoaded', () => {
        const modalToggle = document.getElementById('itemModal');
        const openModalBtn = document.getElementById('openModalBtn');
        const modalSearch = document.getElementById('modalSearch');
        const filterSupplierToggle = document.getElementById('filterSupplierItems');
        const container = document.getElementById('modalItemsContainer');
        const cards = Array.from(container.querySelectorAll('.card[data-id]'));
        const supplierId = "<?= $invoiceInfo['supplier_id']; ?>";

        openModalBtn.addEventListener('click', () => {
            modalToggle.checked = true;
            filterAndRenderCards();
        });
        modalSearch.addEventListener('input', filterAndRenderCards);
        filterSupplierToggle.addEventListener('change', filterAndRenderCards);

        function filterAndRenderCards() {
            const searchTerm = modalSearch.value.trim().toLowerCase();
            const filterSupplier = filterSupplierToggle.checked;

            cards.forEach(card => {
                const name = card.dataset.name.toLowerCase();
                const cardSupplierId = card.dataset.supplierid;
                let visible = true;

                if (searchTerm && !name.includes(searchTerm)) visible = false;
                if (filterSupplier && cardSupplierId !== supplierId) visible = false;

                card.style.display = visible ? '' : 'none';
            });
        }

        cards.forEach(card => {
            card.addEventListener('click', () => {
                document.getElementById('selectedItemId').value = card.dataset.id;
                document.getElementById('selectedItemName').value = card.dataset.name;
                document.getElementById('unitId').value = card.dataset.unitid;
                document.getElementById('buyUnitLabel').textContent = card.dataset.unit;
                document.getElementById('buyUnitLabel2').textContent = card.dataset.unit;
                document.getElementById('buyUnitLabel3').textContent = card.dataset.unit;
                modalToggle.checked = false;
            });
        });

        $("#expirationDateInput").pDatepicker({
            format: 'YYYY/MM/DD',
            altField: '[name="expiration_date"]',
            altFormat: 'YYYY-MM-DD',
            observer: true,
            initialValue: false,
            autoClose: true
        });
    });
</script>
<script>
    document.addEventListener('DOMContentLoaded', () => {
        const editButtons = document.querySelectorAll('.editItemBtn');
        const modalToggle = document.getElementById('editItemModal');

        editButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                document.getElementById('edit_item_id').value = btn.dataset.id;
                document.getElementById('edit_item_name').value = btn.dataset.itemname;
                document.getElementById('edit_quantity').value = btn.dataset.quantity;
                document.getElementById('edit_unit_price').value = btn.dataset.unitprice;
                document.getElementById('edit_price_for_quantity').value = btn.dataset.priceforquantity || '';
                document.getElementById('edit_expiration_shamsi').value = btn.dataset.expirationshamsi;
                document.getElementById('edit_expiration').value = btn.dataset.expiration;
                document.getElementById('edit_discount_type').value = btn.dataset.discounttype || 'amount';
                document.getElementById('edit_discount_value').value = btn.dataset.discountvalue || '';
                document.getElementById('edit_tax_type').value = btn.dataset.taxtype || 'amount';
                document.getElementById('edit_tax_value').value = btn.dataset.taxvalue || '';
                document.getElementById('edit_note').value = btn.dataset.note || '';
                document.getElementById('edit_is_gift').checked = btn.dataset.isgift == '1';

                document.getElementById('edit_buy_unit_label').textContent = btn.dataset.buyunit || '-';
                document.getElementById('edit_buy_unit_label_2').textContent = btn.dataset.buyunit || '-';
                document.getElementById('edit_converted_qty_display').value = btn.dataset.convertedqtydisplay || '-';

                modalToggle.checked = true;
            });
        });

        $("#edit_expiration_shamsi").pDatepicker({
            format: 'YYYY/MM/DD',
            altField: '#edit_expiration',
            altFormat: 'YYYY-MM-DD',
            observer: true,
            initialValue: false,
            autoClose: true
        });
    });
</script>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        const unitSelect = document.getElementById('unitSelect');
        const buyUnitLabel4 = document.getElementById('buyUnitLabel4');

        function updateUnitLabels() {
            const selectedUnitName = unitSelect.options[unitSelect.selectedIndex]?.text || 'واحد';
            buyUnitLabel4.textContent = selectedUnitName;
        }

        // مقداردهی اولیه
        updateUnitLabels();

        // تغییر هنگام انتخاب یونیت
        unitSelect.addEventListener('change', updateUnitLabels);
    });
</script>
<script>
    document.addEventListener('DOMContentLoaded', () => {
        const suggestBtn = document.getElementById('suggestBtn');

        suggestBtn.addEventListener('click', () => {
            const itemId = document.getElementById('selectedItemId').value;
            const supplierId = "<?= $invoiceInfo['supplier_id']; ?>";

            if (!itemId) {
                showToast("لطفاً ابتدا کالا را انتخاب کنید.", "error");
                return;
            }

            suggestBtn.classList.add('loading');

            fetch("index.php?Page=showInvoiceItems&invoice_id=<?= $invoiceInfo['id']; ?>", {
                    method: "POST",
                    credentials: "include",
                    headers: {
                        "Content-Type": "application/x-www-form-urlencoded"
                    },
                    body: new URLSearchParams({
                        getSuggestedValues: 1,
                        item_id: itemId
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const d = data.data;
                        document.getElementById('quantity').value = d.quantity || '';
                        document.getElementById('unit_price').value = d.unit_price || '';
                        document.getElementById('price_for_quantity').value = d.price_for_quantity || '';
                        document.querySelector('[name="discount_type"]').value = d.discount_type || 'amount';
                        document.querySelector('[name="discount_value"]').value = d.discount_value || '';
                        document.querySelector('[name="tax_type"]').value = d.tax_type || 'amount';
                        document.querySelector('[name="tax_value"]').value = d.tax_value || '';
                        document.querySelector('[name="note"]').value = d.note || '';
                        document.querySelector('[name="conversion_buy_qty"]').value = d.conversion_buy_qty || '';
                        document.querySelector('[name="conversion_store_qty"]').value = d.conversion_store_qty || '';
                        document.getElementById('unitSelect').value = d.unit_id || '';

                        showToast(data.message, "success");
                    } else {
                        showToast(data.message, "warning");
                    }
                })
                .catch(() => {
                    showToast("خطا در دریافت مقادیر پیشنهادی.", "error");
                })
                .finally(() => {
                    suggestBtn.classList.remove('loading');
                });
        });
    });
</script>