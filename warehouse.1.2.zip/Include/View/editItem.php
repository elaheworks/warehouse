<?php include_once "./Include/View/header.php"; ?>

<div class="w-full max-w-2xl mx-auto p-6 bg-base-100 shadow-lg rounded-lg">
    <div class="flex justify-between items-center mb-6">
        <h2 class="text-xl font-bold text-primary">ویرایش کالا</h2>
        <a href="?Page=showItems" class="btn btn-outline btn-sm">بازگشت</a>
    </div>

    <?php if ($Item): ?>
        <form method="post" action="">
            <input type="hidden" name="itemForm" value="editItem">

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">

                <!-- نام محصول -->
                <div>
                    <label class="label">نام محصول</label>
                    <input type="text" name="product" class="input input-bordered w-full" value="<?= htmlspecialchars($Item['product']); ?>" required>
                </div>

                <!-- برند -->
                <div>
                    <label class="label">برند</label>
                    <input type="text" name="brand" class="input input-bordered w-full" value="<?= htmlspecialchars($Item['brand']); ?>">
                </div>

                <!-- تأمین‌کننده -->
                <div>
                    <label class="label">تأمین‌کننده</label>
                    <select id="edit_supplier_select" name="supplier_id" class="select select-bordered w-full" required>
                        <?php foreach ($suppliersList as $s): ?>
                            <option value="<?= $s['id']; ?>" <?= $s['id'] == $Item['supplier_id'] ? 'selected' : ''; ?>>
                                <?= htmlspecialchars($s['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- دسته‌بندی -->
                <div>
                    <label class="label">دسته‌بندی</label>
                    <select name="category_id" class="select select-bordered w-full" required>
                        <?php foreach ($categoriesList as $c): ?>
                            <option value="<?= $c['id']; ?>" <?= $c['id'] == $Item['category_id'] ? 'selected' : ''; ?>>
                                <?= htmlspecialchars($c['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- واحد -->
                <div>
                    <label class="label">واحد</label>
                    <select name="unit_id" class="select select-bordered w-full" required>
                        <?php foreach ($unitsList as $u): ?>
                            <option value="<?= $u['id']; ?>" <?= $u['id'] == $Item['unit_id'] ? 'selected' : ''; ?>>
                                <?= htmlspecialchars($u['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- قیمت واحد -->
                <div>
                    <label class="label">قیمت واحد (ریال)</label>
                    <input type="number" name="unit_price" class="input input-bordered w-full" value="<?= $Item['unit_price']; ?>" min="1" required>
                </div>

                <!-- مقدار -->
                <div>
                    <label class="label">مقدار</label>
                    <input type="number" name="quantity" class="input input-bordered w-full" value="<?= $Item['quantity']; ?>" min="0" required>
                </div>

                <!-- سطح هشدار -->
                <div>
                    <label class="label">سطح هشدار</label>
                    <input type="number" name="par_level" class="input input-bordered w-full" value="<?= $Item['par_level']; ?>" min="0">
                </div>

                <!-- محل نگهداری -->
                <div class="md:col-span-2">
                    <label class="label">محل نگهداری</label>
                    <input type="text" name="storage_location" class="input input-bordered w-full" value="<?= htmlspecialchars($Item['storage_location']); ?>">
                </div>

                <!-- وضعیت -->
                <div class="md:col-span-2">
                    <label class="label">وضعیت</label>
                    <select name="status" class="select select-bordered w-full">
                        <option value="0" <?= $Item['status'] == 0 ? 'selected' : ''; ?>>فعال</option>
                        <option value="1" <?= $Item['status'] == 1 ? 'selected' : ''; ?>>غیرفعال</option>
                    </select>
                </div>
            </div>

            <div class="flex justify-end mt-6 space-x-2">
                <button type="submit" class="btn btn-success">ذخیره تغییرات</button>
                <a href="?Page=showItems" class="btn">لغو</a>
            </div>
        </form>
    <?php else: ?>
        <div class="alert alert-error mt-4">آیتم مورد نظر یافت نشد.</div>
        <a href="?Page=showItems" class="btn btn-primary mt-4">بازگشت به لیست</a>
    <?php endif; ?>
</div>

<script>
$(function() {
    // TomSelect برای تأمین‌کننده
    new TomSelect("#edit_supplier_select", {
        create: false,
        sortField: { field: "text", direction: "asc" }
    });
});
</script>
