</div>
<footer class="footer footer-center bg-base-300 text-base-content p-4 mb-8 lg:mb-0">
  <aside>
    <p>Copyright © 2024 - All right reserved by shahrekhaghazi</p>
  </aside>
</footer>
<script src="assets/js/my.js"></script>

</body>

</html>