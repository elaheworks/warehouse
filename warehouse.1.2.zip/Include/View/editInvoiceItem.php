<?php include_once "./Include/View/header.php";
// echo '<pre>';
//        print_r($itemInfo);
//        die();
?>

<div class="mx-auto p-4 space-y-4">
    <h2 class="text-2xl font-bold flex items-center gap-2 text-primary">
        ویرایش آیتم فاکتور: <?= htmlspecialchars($invoiceInfo['invoice_number']); ?>
    </h2>
    <p>تأمین‌کننده: <strong><?= htmlspecialchars($itemInfo['supplier_name']); ?></strong></p>

    <form method="post" class="bg-base-200 p-6 rounded-xl shadow-lg w-full mx-auto grid grid-cols-1 md:grid-cols-6 gap-6">

        <input type="hidden" name="invoice_id" value="<?= $invoiceInfo['id']; ?>">
        <input type="hidden" name="edit_item_id" value="<?= $itemInfo['id']; ?>">

        <!-- انتخاب کالا (فقط نمایشی) -->
        <div class="md:col-span-3">
            <label class="label font-semibold">نام کالا</label>
            <input type="text" value="<?= htmlspecialchars($itemInfo['item_name']); ?>" readonly
                class="input input-bordered w-full bg-base-100 cursor-not-allowed focus:outline-none" />
        </div>

        <!-- مقدار خرید -->
        <div class="md:col-span-3">
            <label for="quantity" class="label font-semibold">مقدار خریداری شده (<?= htmlspecialchars($itemInfo['unit_name']); ?>)</label>
            <input type="number" id="quantity" name="quantity" min="0.01" step="0.01"
                value="<?= htmlspecialchars($itemInfo['quantity']); ?>" required
                class="input input-bordered w-full" />
        </div>

        <!-- قیمت واحد -->
        <div class="md:col-span-2">
            <label for="unit_price" class="label font-semibold">قیمت واحد (ریال)</label>
            <input type="number" id="unit_price" name="unit_price" min="0" step="0.01"
                value="<?= htmlspecialchars($itemInfo['unit_price']); ?>" required
                class="input input-bordered w-full" />
        </div>

        <!-- قیمت برای چه مقدار -->
        <div class="md:col-span-2">
            <label for="price_for_quantity" class="label font-semibold">قیمت برای چه مقدار (<?= htmlspecialchars($itemInfo['unit_name']); ?>)</label>
            <input type="number" id="price_for_quantity" name="price_for_quantity" min="0.01" step="0.01"
                value="<?= htmlspecialchars($itemInfo['price_for_quantity']); ?>"
                class="input input-bordered w-full" />
        </div>

        <!-- تاریخ انقضا -->
        <div class="md:col-span-2">
            <label for="expiration_date" class="label font-semibold">تاریخ انقضا (شمسی)</label>
            <input type="text" id="expirationDateInput" name="expiration_date"
                value="<?= htmlspecialchars($itemInfo['expiration_date']); ?>" required
                class="input input-bordered w-full" dir="ltr" />
        </div>

        <!-- تبدیل واحد -->
        <div class="md:col-span-6">
            <label class="label font-semibold mb-2">تبدیل واحد خرید به انبار (اختیاری)</label>
            <div class="md:flex gap-4">
                <div class="md:flex-1">
                    <label class="label text-sm text-gray-500">مقدار خریداری شده</label>
                    <input type="number" name="conversion_buy_qty" min="0.01" step="0.01"
                        value="<?= htmlspecialchars($itemInfo['conversion_buy_qty']); ?>"
                        class="input input-bordered w-full" />
                </div>
                <div class="md:flex-1">
                    <label class="label text-sm text-gray-500">مقدار معادل در انبار</label>
                    <input type="number" name="conversion_store_qty" min="0.01" step="0.01"
                        value="<?= htmlspecialchars($itemInfo['conversion_store_qty']); ?>"
                        class="input input-bordered w-full" />
                </div>
                <div class="md:flex-1">
                    <label for="unit_id" class="label text-sm text-gray-500">واحد ذخیره در انبار</label>
                    <select name="unit_id" id="unitSelect" class="select select-bordered w-full">
                        <?php foreach ($unitsList as $u): ?>
                            <option value="<?= $u['id']; ?>" <?= $u['id'] == $itemInfo['unit_id'] ? 'selected' : ''; ?>>
                                <?= htmlspecialchars($u['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
        </div>

        <!-- تخفیف -->
        <div class="md:col-span-2">
            <label class="label font-semibold">تخفیف</label>
            <div class="flex gap-2">
                <select name="discount_type" class="select select-bordered w-1/3">
                    <option value="amount" <?= $itemInfo['discount_type'] == 'amount' ? 'selected' : ''; ?>>ریال</option>
                    <option value="percent" <?= $itemInfo['discount_type'] == 'percent' ? 'selected' : ''; ?>>٪ درصد</option>
                </select>
                <input type="number" name="discount_value" step="0.01"
                    value="<?= htmlspecialchars($itemInfo['discount_value']); ?>"
                    class="input input-bordered w-2/3" />
            </div>
        </div>

        <!-- مالیات -->
        <div class="md:col-span-2">
            <label class="label font-semibold">مالیات</label>
            <div class="flex gap-2">
                <select name="tax_type" class="select select-bordered w-1/3">
                    <option value="amount" <?= $itemInfo['tax_type'] == 'amount' ? 'selected' : ''; ?>>ریال</option>
                    <option value="percent" <?= $itemInfo['tax_type'] == 'percent' ? 'selected' : ''; ?>>٪ درصد</option>
                </select>
                <input type="number" name="tax_value" step="0.01"
                    value="<?= htmlspecialchars($itemInfo['tax_value']); ?>"
                    class="input input-bordered w-2/3" />
            </div>
        </div>

        <!-- اشانتیون -->
        <div class="md:col-span-2 flex items-center gap-3">
            <input type="checkbox" name="is_gift" id="is_gift" class="toggle toggle-primary"
                <?= $itemInfo['is_gift'] ? 'checked' : ''; ?> />
            <label for="is_gift" class="font-semibold cursor-pointer select-none">اشانتیون</label>
        </div>

        <!-- یادداشت -->
        <div class="md:col-span-6">
            <label class="label font-semibold">یادداشت (اختیاری)</label>
            <textarea name="note" rows="3" class="textarea textarea-bordered w-full"><?= htmlspecialchars($itemInfo['note']); ?></textarea>
        </div>

        <!-- دکمه ذخیره -->
        <button type="submit" name="updateItem" value="1" class="btn btn-success md:col-span-6">
            ذخیره تغییرات
        </button>
    </form>
</div>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        $("#expirationDateInput").pDatepicker({
            format: 'YYYY/MM/DD',
            altField: '[name="expiration_date"]',
            altFormat: 'YYYY-MM-DD',
            observer: true,
            initialValue: true,
            autoClose: true
        });
    });
</script>