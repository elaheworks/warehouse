<?php include_once "./Include/View/header.php"; ?>
<div class="w-full mx-auto p-6 bg-base-100 shadow-lg rounded-lg">

    <div class="flex justify-between items-center mb-4">
        <h2 class="text-xl font-bold">📦 مدیریت کالاهای مادر</h2>
        <button class="btn btn-primary btn-sm" onclick="add_master_item_modal.showModal()">
            <i class="fa-solid fa-plus"></i> افزودن کالا
        </button>
    </div>

    <!-- فیلتر -->
    <details class="collapse collapse-arrow bg-base-200 mb-4">
        <summary class="collapse-title text-md font-medium">فیلترها</summary>
        <div class="collapse-content">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                    <label class="label">نام کالا</label>
                    <input type="text" class="column-filter input input-bordered input-sm w-full" data-column="product_name" placeholder="فیلتر نام کالا">
                </div>
                <div>
                    <label class="label">دسته‌بندی</label>
                    <input type="text" class="column-filter input input-bordered input-sm w-full" data-column="category" placeholder="فیلتر دسته‌بندی">
                </div>
                <div>
                    <label class="label">وضعیت</label>
                    <select class="column-filter select select-bordered select-sm w-full" data-column="status">
                        <option value="">همه</option>
                        <option value="1">فعال</option>
                        <option value="0">غیرفعال</option>
                    </select>
                </div>
            </div>
        </div>
    </details>

    <div class="overflow-auto max-h-[calc(100vh-300px)]">
        <table class="table w-full">
            <thead>
                <tr>
                    <th>#</th>
                    <th>نام کالا</th>
                    <th>دسته‌بندی</th>
                    <th>برند</th>
                    <th>واحد</th>
                    <th>سطح هشدار</th>
                    <th>حداقل/حداکثر</th>
                    <th>شرایط نگهداری</th>
                    <th>وضعیت</th>
                    <th></th>
                </tr>
            </thead>
            <?php if (!empty($masterItemsList)):
                $count = 0; ?>
                <tbody id="master-items-table-body">
                    <?php foreach ($masterItemsList as $item): $count++; ?>
                        <tr class="hover" data-status="<?= $item['status']; ?>">
                            <td><?= $count; ?></td>
                            <td><?= htmlspecialchars($item['product_name']); ?></td>
                            <td><?= htmlspecialchars(getCategoryName($item['category_id'], $categoriesList)); ?></td>
                            <td><?= htmlspecialchars($item['brand'] ?? '-'); ?></td>
                            <td><?= htmlspecialchars(getUnitName($item['default_unit_id'], $unitsList)); ?></td>
                            <td><?= $item['par_level'] ?? 0; ?></td>
                            <td><?= ($item['min_amount'] ?? 0) . ' / ' . ($item['max_amount'] ?? 0); ?></td>
                            <td><?= htmlspecialchars($item['storage_condition'] ?? '-'); ?></td>
                            <td>
                                <?php if ($item['status'] == 1): ?>
                                    <span class="badge badge-success">فعال</span>
                                <?php else: ?>
                                    <span class="badge badge-error">غیرفعال</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end space-x-1">
                                <a href="?editMasterItem=<?= $item['id']; ?>" class="btn btn-outline btn-primary btn-xs" title="ویرایش">
                                    <i class="fa-solid fa-edit"></i>
                                </a>
                                <form method="post" action="" onsubmit="return confirm('حذف این کالا؟');" class="inline">
                                    <input type="hidden" name="deleteMasterItem" value="<?= $item['id']; ?>">
                                    <button type="submit" class="btn btn-outline btn-error btn-xs" title="حذف">
                                        <i class="fa-solid fa-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            <?php else: ?>
                <tbody>
                    <tr>
                        <td colspan="10" class="text-center">⚠️ کالای مادری ثبت نشده است.</td>
                    </tr>
                </tbody>
            <?php endif; ?>
        </table>
    </div>
    <!-- Add Master Item Modal -->
    <dialog id="add_master_item_modal" class="modal">
        <div class="modal-box max-w-lg">
            <h3 class="font-bold text-lg mb-4">افزودن کالای مادر</h3>
            <form method="post" action="">
                <input type="hidden" name="addMasterItem" value="1">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">

                    <div>
                        <label class="label">نام کالا</label>
                        <input type="text" name="product_name" class="input input-bordered w-full" required>
                    </div>

                    <div>
                        <label class="label">برند</label>
                        <input type="text" name="brand" class="input input-bordered w-full">
                    </div>

                    <div>
                        <label class="label">دسته‌بندی</label>
                        <select name="category_id" class="select select-bordered w-full" required>
                            <option disabled selected>انتخاب دسته‌بندی</option>
                            <?php foreach ($categoriesList as $c): ?>
                                <option value="<?= $c['id']; ?>"><?= htmlspecialchars($c['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div>
                        <label class="label">واحد پیش‌فرض</label>
                        <select name="default_unit_id" class="select select-bordered w-full" required>
                            <option disabled selected>انتخاب واحد</option>
                            <?php foreach ($unitsList as $u): ?>
                                <option value="<?= $u['id']; ?>"><?= htmlspecialchars($u['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div>
                        <label class="label">سطح هشدار</label>
                        <input type="number" name="par_level" class="input input-bordered w-full" min="0">
                    </div>

                    <div>
                        <label class="label">حداقل مقدار</label>
                        <input type="number" name="min_amount" class="input input-bordered w-full" min="0">
                    </div>

                    <div>
                        <label class="label">حداکثر مقدار</label>
                        <input type="number" name="max_amount" class="input input-bordered w-full" min="0">
                    </div>

                    <div>
                        <label class="label">وضعیت</label>
                        <select name="status" class="select select-bordered w-full">
                            <option value="1">فعال</option>
                            <option value="0">غیرفعال</option>
                        </select>
                    </div>

                    <div class="md:col-span-2">
                        <label class="label">شرایط نگهداری</label>
                        <input type="text" name="storage_condition" class="input input-bordered w-full">
                    </div>
                </div>

                <!-- 🧩 Merge Switch -->
                <div class="mt-4">
                    <label class="label">🧩 ادغام موجودی در انبار</label>
                    <label class="toggle text-base-content">
                        <input type="checkbox" name="merge_inventory" value="1" />
                        <svg aria-label="disabled" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="4" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M18 6 6 18" />
                            <path d="m6 6 12 12" />
                        </svg>
                        <svg aria-label="enabled" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                            <g stroke-linejoin="round" stroke-linecap="round" stroke-width="4" fill="none" stroke="currentColor">
                                <path d="M20 6 9 17l-5-5"></path>
                            </g>
                        </svg>
                    </label>
                    <p class="text-xs text-gray-500 mt-2">با فعال‌سازی این گزینه، موجودی زیرمجموعه‌های این کالای مادر با موجودی تأمین‌کنندگان دیگر ادغام می‌شود.</p>
                </div>


                <div class="modal-action mt-4">
                    <button type="submit" class="btn btn-success">ثبت</button>
                    <button type="button" class="btn" onclick="add_master_item_modal.close()">لغو</button>
                </div>
            </form>
        </div>
    </dialog>


</div>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        const filters = document.querySelectorAll('.column-filter');
        const rows = document.querySelectorAll('#master-items-table-body tr');

        filters.forEach(filter => {
            filter.addEventListener('input', () => {
                const filterProduct = document.querySelector('[data-column="product_name"]').value.trim().toLowerCase();
                const filterCategory = document.querySelector('[data-column="category"]').value.trim().toLowerCase();
                const filterStatus = document.querySelector('[data-column="status"]').value;

                rows.forEach(row => {
                    const product = row.cells[1].textContent.trim().toLowerCase();
                    const category = row.cells[2].textContent.trim().toLowerCase();
                    const status = row.getAttribute('data-status');

                    let show = true;
                    if (filterProduct && !product.includes(filterProduct)) show = false;
                    if (filterCategory && !category.includes(filterCategory)) show = false;
                    if (filterStatus && filterStatus !== status) show = false;

                    row.style.display = show ? '' : 'none';
                });
            });
        });
    });
</script>

<?php
function getCategoryName($id, $list)
{
    foreach ($list as $c) if ($c['id'] == $id) return $c['name'];
    return "نامشخص";
}

function getUnitName($id, $list)
{
    foreach ($list as $u) if ($u['id'] == $id) return $u['name'];
    return "نامشخص";
}
?>