</div>
</div>
<div class="drawer-side lg:mt-2 z-[100]">
  <label for="my-drawer-2" class="drawer-overlay" aria-label="close sidebar"></label>
  <ul class="menu w-56 bg-base-100 rounded-box min-h-screen scrollbar-hide">

    <!-- داشبورد -->
    <li>
      <a href="?Page=dashboard" class="<?php echo ($page == 'dashboard') ? 'menu-active' : ''; ?>">
        <i class="fas fa-tachometer-alt h-5 w-5"></i>
        داشبورد
      </a>
    </li>

    <!-- تعاریف پایه -->
    <li>
      <h2 class="menu-title">تعاریف پایه</h2>
      <ul>
        <li><a href="?Page=showUsers" class="<?php echo ($page == 'showUsers') ? 'menu-active' : ''; ?>"><i class="fas fa-user h-5 w-5"></i> کاربران</a></li>
        <li><a href="?Page=showMasterItems" class="<?php echo ($page == 'showMasterItems') ? 'menu-active' : ''; ?>"><i class="fas fa-box h-5 w-5"></i>مجموعه‌ها</a></li>
        <li><a href="?Page=showItems" class="<?php echo ($page == 'showItems') ? 'menu-active' : ''; ?>"><i class="fas fa-box h-5 w-5"></i> کالاها</a></li>
        <li><a href="?Page=showCategories" class="<?php echo ($page == 'showCategories') ? 'menu-active' : ''; ?>"><i class="fas fa-tags h-5 w-5"></i> دسته‌بندی‌ها</a></li>
        <li><a href="?Page=showSuppliers" class="<?php echo ($page == 'showSuppliers') ? 'menu-active' : ''; ?>"><i class="fas fa-truck h-5 w-5"></i> تأمین‌کننده‌ها</a></li>
        <li><a href="?Page=showUnits" class="<?php echo ($page == 'showUnits') ? 'menu-active' : ''; ?>"><i class="fas fa-ruler h-5 w-5"></i> واحدها</a></li>
        <li><a href="?Page=showCustomers" class="<?php echo ($page == 'showCustomers') ? 'menu-active' : ''; ?>"><i class="fas fa-users h-5 w-5"></i> مشتریان</a></li>
      </ul>
    </li>

    <!-- عملیات انبار -->
    <li>
      <h2 class="menu-title">عملیات انبار</h2>
      <ul>
        <li><a href="?Page=showInventory" class="<?php echo ($page == 'showInventory') ? 'menu-active' : ''; ?>"><i class="fas fa-warehouse h-5 w-5"></i> موجودی انبار</a></li>
        <li><a href="?Page=showInvoices" class="<?php echo ($page == 'showInvoices') ? 'menu-active' : ''; ?>"><i class="fas fa-file-invoice h-5 w-5"></i> مدیریت فاکتورها</a></li>
        <li><a href="?Page=showRequests" class="<?php echo ($page == 'showRequests') ? 'menu-active' : ''; ?>"><i class="fas fa-share-square h-5 w-5"></i> درخواست انتقال از انبار</a></li>
        <li><a href="?Page=showPurchases" class="<?php echo ($page == 'showPurchases') ? 'menu-active' : ''; ?>"><i class="fas fa-shopping-bag h-5 w-5"></i> خرید از تأمین‌کننده</a></li>
        <li><a href="?Page=showTransactions" class="<?php echo ($page == 'showTransactions') ? 'menu-active' : ''; ?>"><i class="fas fa-exchange-alt h-5 w-5"></i> تراکنش‌ها</a></li>
      </ul>
    </li>
    


    <!-- گزارش‌ها -->
    <li>
      <h2 class="menu-title">گزارشات</h2>
      <ul>
        <li><a href="?Page=showLogs" class="<?php echo ($page == 'showLogs') ? 'menu-active' : ''; ?>"><i class="fas fa-info-circle h-5 w-5"></i> لاگ‌ها</a></li>
        <li><a href="?Page=showInventoryReport" class="<?php echo ($page == 'showInventoryReport') ? 'menu-active' : ''; ?>"><i class="fas fa-chart-bar h-5 w-5"></i> گزارش موجودی</a></li>
        <li><a href="?Page=showOrderReport" class="<?php echo ($page == 'showOrderReport') ? 'menu-active' : ''; ?>"><i class="fas fa-file-alt h-5 w-5"></i> گزارش درخواست‌ها</a></li>
      </ul>
    </li>

    <!-- خروج -->
    <li>
      <a href="?Page=logout" class="<?php echo ($page == 'logout') ? 'menu-active' : ''; ?>">
        <i class="fas fa-sign-out-alt h-5 w-5"></i> خروج
      </a>
    </li>
  </ul>
</div>
