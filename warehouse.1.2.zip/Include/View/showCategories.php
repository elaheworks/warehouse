<?php include_once "./Include/View/header.php"; ?>

<div class="w-full mx-auto p-6 bg-base-100 shadow-lg rounded-lg">
    <div class="flex justify-between items-center mb-4">
        <div></div>
        <button class="btn btn-primary" onclick="add_category_modal.showModal()">
            <i class="fa-solid fa-plus"></i> افزودن دسته‌بندی
        </button>
    </div>

    <!-- Minimal Filter Section -->
    <details class="collapse collapse-arrow bg-base-200 mb-4">
        <summary class="collapse-title text-md font-medium">فیلترها</summary>
        <div class="collapse-content">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="label">نام دسته‌بندی</label>
                    <input type="text" class="column-filter input input-bordered input-sm w-full" data-column="name" placeholder="فیلتر نام">
                </div>
                <div>
                    <label class="label">وضعیت</label>
                    <select class="column-filter select select-bordered select-sm w-full" data-column="status">
                        <option value="">همه</option>
                        <option value="1">فعال</option>
                        <option value="0">غیرفعال</option>
                    </select>
                </div>
            </div>
        </div>
    </details>

    <div class="overflow-auto h-screen">
        <table class="table w-full">
            <!-- Table Head -->
            <thead>
                <tr>
                    <th>#</th>
                    <th>نام دسته‌بندی</th>
                    <th>توضیحات</th>
                    <th>وضعیت</th>
                    <th>تاریخ ثبت</th>
                    <th>آخرین ویرایش</th>
                    <th></th>
                </tr>
            </thead>
            <!-- Table Body -->
            <?php if ($AllCategories != -1 && !empty($paginatedCategories)): ?>
                <tbody id="categories-table-body">
                    <?php foreach ($paginatedCategories as $Row => $category): ?>
                        <tr class="hover" data-status="<?php echo $category['status']; ?>">
                            <th><?php echo $offset + $Row + 1; ?></th>
                            <td><?php echo htmlspecialchars($category['name']); ?></td>
                            <td><?php echo htmlspecialchars($category['description']); ?></td>
                            <td>
                                <?php if ($category['status'] == 0): ?>
                                    <span class="badge badge-success">فعال</span>
                                <?php else: ?>
                                    <span class="badge badge-error">غیرفعال</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo $category['reg_date']; ?></td>
                            <td><?php echo $category['last_edit'] ?: '-'; ?></td>
                            <td class="text-end">
                                <button class="btn btn-outline btn-secondary btn-xs" onclick="detail_modal_<?php echo $category['id']; ?>.showModal()">
                                    <i class="fa-solid fa-info-circle"></i>
                                </button>
                                <a href="<?php echo $_SESSION['WebsiteUrl']; ?>?Page=editCategory&id=<?php echo $category['id']; ?>" class="btn btn-outline btn-primary btn-xs">
                                    <i class="fa-solid fa-edit"></i>
                                </a>
                                <button class="btn btn-outline btn-error btn-xs" onclick="delete_modal_<?php echo $category['id']; ?>.showModal()">
                                    <i class="fa-solid fa-trash"></i>
                                </button>
                            </td>
                        </tr>

                        <!-- Detail Modal -->
                        <dialog id="detail_modal_<?php echo $category['id']; ?>" class="modal">
                            <div class="modal-box">
                                <h3 class="text-lg font-bold">جزئیات دسته‌بندی</h3>
                                <div class="py-4">
                                    <p><strong>نام دسته‌بندی:</strong> <?php echo htmlspecialchars($category['name']); ?></p>
                                    <p><strong>توضیحات دسته‌بندی:</strong> <?php echo htmlspecialchars($category['description']); ?></p>
                                    <p><strong>وضعیت:</strong> <?php echo $category['status'] == 1 ? 'فعال' : 'غیرفعال'; ?></p>
                                    <p><strong>تاریخ ثبت:</strong> <?php echo $category['reg_date']; ?></p>
                                    <p><strong>آخرین ویرایش:</strong> <?php echo $category['last_edit'] ?: '-'; ?></p>
                                </div>
                                <div class="modal-action">
                                    <form method="dialog">
                                        <button class="btn">بستن</button>
                                    </form>
                                </div>
                            </div>
                        </dialog>

                        <!-- Delete Confirmation Modal -->
                        <dialog id="delete_modal_<?php echo $category['id']; ?>" class="modal">
                            <div class="modal-box">
                                <h3 class="text-lg font-bold">تأیید حذف</h3>
                                <p class="py-4">آیا مطمئن هستید که می‌خواهید دسته‌بندی "<?php echo htmlspecialchars($category['name']); ?>" را حذف کنید؟</p>
                                <div class="modal-action">
                                    <form method="post" action="">
                                        <input type="hidden" name="category_id" value="<?php echo $category['id']; ?>">
                                        <button class="btn btn-error" name="categoryForm" value="deleteCategory">حذف</button>
                                        <button class="btn" type="button" onclick="this.closest('dialog').close()">لغو</button>
                                    </form>
                                </div>
                            </div>
                        </dialog>
                    <?php endforeach; ?>
                </tbody>
            <?php else: ?>
                <tbody>
                    <tr>
                        <td colspan="6" class="text-center">دسته‌بندی برای نمایش وجود ندارد</td>
                    </tr>
                </tbody>
            <?php endif; ?>
        </table>

        <!-- Pagination Controls -->
        <?php if ($totalPages > 1): ?>
            <div class="flex justify-center mt-4">
                <div class="join">
                    <a href="<?php echo $_SESSION['WebsiteUrl']; ?>?Page=showCategories&P=<?php echo max(1, $P - 1); ?><?php echo $search ? '&search=' . urlencode($search) : ''; ?>" class="join-item btn btn-outline <?php if ($P == 1) echo 'btn-disabled'; ?>">
                        قبلی
                    </a>
                    <?php
                    $range = 2;
                    $start = max(1, $P - $range);
                    $end = min($totalPages, $P + $range);
                    if ($start > 1) {
                        echo '<a href="' . $_SESSION['WebsiteUrl'] . '?Page=showCategories&P=1' . ($search ? '&search=' . urlencode($search) : '') . '" class="join-item btn btn-outline">1</a>';
                        if ($start > 2) {
                            echo '<span class="join-item btn btn-disabled">...</span>';
                        }
                    }
                    for ($i = $start; $i <= $end; $i++) {
                        $active = $i == $P ? 'btn-active' : '';
                        echo '<a href="' . $_SESSION['WebsiteUrl'] . '?Page=showCategories&P=' . $i . ($search ? '&search=' . urlencode($search) : '') . '" class="join-item btn btn-outline ' . $active . '">' . $i . '</a>';
                    }
                    if ($end < $totalPages) {
                        if ($end < $totalPages - 1) {
                            echo '<span class="join-item btn btn-disabled">...</span>';
                        }
                        echo '<a href="' . $_SESSION['WebsiteUrl'] . '?Page=showCategories&P=' . $totalPages . ($search ? '&search=' . urlencode($search) : '') . '" class="join-item btn btn-outline">' . $totalPages . '</a>';
                    }
                    ?>
                    <a href="<?php echo $_SESSION['WebsiteUrl']; ?>?Page=showCategories&P=<?php echo min($totalPages, $P + 1); ?><?php echo $search ? '&search=' . urlencode($search) : ''; ?>" class="join-item btn btn-outline <?php if ($P == $totalPages) echo 'btn-disabled'; ?>">
                        بعدی
                    </a>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Add Category Modal -->
<dialog id="add_category_modal" class="modal">
    <div class="modal-box">
        <h3 class="text-lg font-bold">افزودن دسته‌بندی جدید</h3>
        <form method="POST" action="">
            <div class="py-4 space-y-4">
                <div>
                    <label class="label">نام دسته‌بندی</label>
                    <input type="text" name="name" class="input input-bordered w-full" placeholder="نام دسته‌بندی" required>
                </div>
                <div>
                    <label class="label">توضیحات</label>
                    <input type="text" name="description" class="input input-bordered w-full" placeholder="توضیحات">
                </div>
                <div>
                    <label class="label">وضعیت</label>
                    <select name="status" class="select select-bordered w-full" required>
                        <option value="0">فعال</option>
                        <option value="1">غیرفعال</option>
                    </select>
                </div>
            </div>
            <div class="modal-action">
                <button type="submit" name="categoryForm" value="addCategory" class="btn btn-primary">ذخیره</button>
                <button type="button" class="btn" onclick="add_category_modal.close()">لغو</button>
            </div>
        </form>
    </div>
</dialog>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const tableBody = document.getElementById('categories-table-body');
    const rows = Array.from(tableBody.getElementsByTagName('tr'));
    const filters = document.querySelectorAll('.column-filter');

    filters.forEach(filter => {
        filter.addEventListener('input', function() {
            const column = this.getAttribute('data-column');
            const filterValue = this.value.toLowerCase().trim();

            rows.forEach(row => {
                const cells = row.getElementsByTagName('td');
                let shouldShow = true;

                filters.forEach(f => {
                    const col = f.getAttribute('data-column');
                    const val = f.value.toLowerCase().trim();
                    let cellIndex;

                    switch(col) {
                        case 'name': cellIndex = 0; break;
                        case 'contact': cellIndex = 1; break;
                        case 'status': 
                            if (val && row.getAttribute('data-status') !== val) {
                                shouldShow = false;
                            }
                            return; // Skip cellIndex for status
                    }

                    if (val && cellIndex !== undefined) {
                        const cellText = cells[cellIndex].textContent.toLowerCase().trim();
                        if (cellText.indexOf(val) === -1) {
                            shouldShow = false;
                        }
                    }
                });

                row.style.display = shouldShow ? '' : 'none';
            });
        });
    });
});
</script>