<?php include_once "./Include/View/header.php"; ?>

<div class="max-w-3xl mx-auto p-6 bg-base-100 rounded-lg shadow-lg mt-10">
    <h2 class="text-3xl font-bold text-primary mb-6 flex items-center gap-2">
        <svg class="w-7 h-7 text-primary" fill="none" stroke="currentColor" stroke-width="2"
             viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path stroke-linecap="round" stroke-linejoin="round"
                  d="M5.121 17.804A13.937 13.937 0 0112 15c2.755 0 5.304.832 7.41 2.252M15 10a3 3 0 11-6 0 3 3 0 016 0z" />
        </svg>
        ویرایش پروفایل
    </h2>

    <form method="post" enctype="multipart/form-data" action="" class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <input type="hidden" name="profileForm" value="updateProfile">

        <!-- تصویر -->
        <div class="form-control col-span-full text-center">
            <?php if (!empty($user['pic'])): ?>
                <img src="<?= htmlspecialchars($user['pic']); ?>" class="w-24 h-24 rounded-full mx-auto mb-2 object-cover" alt="پروفایل">
            <?php else: ?>
                <div class="w-24 h-24 mx-auto rounded-full bg-base-200 flex items-center justify-center text-gray-400 text-4xl">
                    ?
                </div>
            <?php endif; ?>
            <input type="file" name="profile_pic" class="file-input file-input-bordered file-input-primary mt-2" accept="image/*">
        </div>

        <!-- نام -->
        <input type="text" name="name" class="input input-bordered input-primary w-full"
               placeholder="نام کامل" required value="<?= htmlspecialchars($user['name']); ?>">

        <!-- نام کاربری -->
        <input type="text" name="username" class="input input-bordered input-primary w-full"
               placeholder="نام کاربری" required value="<?= htmlspecialchars($user['username']); ?>">

        <!-- ایمیل -->
        <input type="email" name="email" class="input input-bordered input-primary w-full"
               placeholder="ایمیل" value="<?= htmlspecialchars($user['email']); ?>">

        <!-- موبایل -->
        <input type="text" name="phone" class="input input-bordered input-primary w-full"
               placeholder="موبایل" value="<?= htmlspecialchars($user['phone']); ?>">


        <!-- رمز جدید -->
        <input type="password" name="password" class="input input-bordered input-primary w-full"
               placeholder="رمز عبور جدید (در صورت نیاز به تغییر)">

        <!-- دکمه -->
        <div class="col-span-full">
            <button type="submit" class="btn btn-success w-full text-lg">ذخیره تغییرات</button>
        </div>
    </form>
</div>
