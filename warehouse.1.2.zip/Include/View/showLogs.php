<?php include_once "./Include/View/header.php"; ?>
<?php include_once "./Include/View/header.php"; ?>

<div class="w-full p-6 bg-base-100 rounded-lg shadow-lg">
    <h2 class="text-lg font-bold mb-4">لاگ فعالیت‌ها</h2>

    <div class="overflow-auto max-h-[75vh]">
        <table class="table w-full">
            <thead>
                <tr>
                    <th>زمان</th>
                    <th>کاربر</th>
                    <th>عملیات</th>
                    <th>جدول</th>
                    <th>آی پی</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($logs as $log): ?>
                    <tr>
                        <td><?= $log['created_at'] ?></td>
                        <td><?= getUserNameById($log['user_id']) ?></td>
                        <td><?= $log['action'] ?></td>
                        <td><?= $log['table_name'] ?></td>
                        <td><?= $log['ip_address'] ?></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (count($logs) === 0): ?>
                    <tr><td colspan="6" class="text-center">لاگی ثبت نشده است.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
