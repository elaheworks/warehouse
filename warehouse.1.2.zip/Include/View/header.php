<?php
if (isset($_COOKIE['theme'])) {
  $theme = $_COOKIE['theme'];
} else {
  setcookie('theme', 'nord', time() + (86400 * 30), '/');
  $theme = 'nord';
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl" data-theme="<?php echo htmlspecialchars($theme, ENT_QUOTES, 'UTF-8'); ?>">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
  <title>شهرکاغذی | <?php echo PageName($page); ?></title>
  <link rel="icon" type="image/x-icon" href="assets/imgs/favicon.ico">
  <link rel="apple-touch-icon" sizes="180x180" href="assets/imgs/apple-touch-icon.png">
  <link rel="icon" type="image/png" sizes="32x32" href="assets/imgs/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="16x16" href="assets/imgs/favicon-16x16.png">

  <link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css" rel="stylesheet" type="text/css" />
  <link href="assets/css/daisy.css" rel="stylesheet" type="text/css" />
  <link href="assets/css/themes.css" rel="stylesheet" type="text/css" />
  <script src="assets/js/daisy.js"></script>
  <link href="assets/fontawesome/css/all.css" rel="stylesheet">
  <link href="assets/css/my.css" rel="stylesheet" type="text/css" />
  <!-- jQuery (قبل از همه لود شده باشد) -->

  <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script>
  <!-- Persian Datepicker CSS (لوکال) -->
  <link rel="stylesheet" href="assets/persian-datepicker/persian-datepicker.min.css" />

  <!-- jQuery (لوکال یا CDN) -->

  <!-- Persian Date (لوکال) -->
  <script src="assets/persian-datepicker/persian-date.min.js"></script>

  <!-- Persian Datepicker (لوکال) -->
  <script src="assets/persian-datepicker/persian-datepicker.min.js"></script>
  <link rel="stylesheet" href="assets/tom-select/tom.css" />
  <script src="https://cdn.jsdelivr.net/npm/tom-select@2.3.1/dist/js/tom-select.complete.min.js"></script>

  <style>
    html {
      --theme: <?php echo htmlspecialchars($theme, ENT_QUOTES, 'UTF-8'); ?>;
    }
  </style>
</head>

<body class="bg-base-200">
  <div class="container p-2">
    <?php include_once "./Include/View/navbar.php"; ?>