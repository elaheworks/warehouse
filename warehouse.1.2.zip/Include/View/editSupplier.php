<?php include_once "./Include/View/header.php"; ?>

<div class="w-full max-w-3xl mx-auto p-6 bg-base-100 shadow-lg rounded-lg mt-8">
    <?php if (!$Supplier): ?>
        <div class="alert alert-error">
            تأمین‌کننده مورد نظر پیدا نشد.
        </div>
    <?php else: ?>
        <h2 class="text-2xl font-bold mb-6 flex items-center gap-2">
            <i class="fa-solid fa-user-pen text-primary"></i> ویرایش تأمین‌کننده
        </h2>

        <form method="POST">
            <input type="hidden" name="supplierForm" value="editSupplier">
            <input type="hidden" name="id" value="<?php echo $Supplier['id']; ?>">

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="label">نام تأمین‌کننده</label>
                    <input type="text" name="name" class="input input-bordered w-full" value="<?php echo htmlspecialchars($Supplier['name']); ?>" required>
                </div>
                <div>
                    <label class="label">تلفن ویزیتور</label>
                    <input type="text" name="visitor_phone" class="input input-bordered w-full" value="<?php echo htmlspecialchars($Supplier['visitor_phone']); ?>">
                </div>
                <div>
                    <label class="label">تلفن شرکت</label>
                    <input type="text" name="company_phone" class="input input-bordered w-full" value="<?php echo htmlspecialchars($Supplier['company_phone']); ?>">
                </div>
                <div>
                    <label class="label">تلفن مدیر پخش</label>
                    <input type="text" name="manager_phone" class="input input-bordered w-full" value="<?php echo htmlspecialchars($Supplier['manager_phone']); ?>">
                </div>
                <div class="md:col-span-2">
                    <label class="label">آدرس</label>
                    <input type="text" name="address" class="input input-bordered w-full" value="<?php echo htmlspecialchars($Supplier['address']); ?>">
                </div>
                <div class="md:col-span-2">
                    <label class="label">توضیحات</label>
                    <textarea name="description" class="textarea textarea-bordered w-full"><?php echo htmlspecialchars($Supplier['description']); ?></textarea>
                </div>
                <div class="md:col-span-2">
                    <label class="label">شماره حساب/شبا/کارت</label>
                    <input type="text" name="account_number" class="input input-bordered w-full" value="<?php echo htmlspecialchars($Supplier['account_number']); ?>">
                </div>
                <div class="md:col-span-2">
                    <label class="label">وضعیت</label>
                    <select name="status" class="select select-bordered w-full" required>
                        <option value="1" <?php echo $Supplier['status'] == 1 ? 'selected' : ''; ?>>فعال</option>
                        <option value="0" <?php echo $Supplier['status'] == 0 ? 'selected' : ''; ?>>غیرفعال</option>
                    </select>
                </div>
            </div>

            <div class="mt-6 flex gap-2">
                <button type="submit" class="btn btn-success">
                    <i class="fa-solid fa-save"></i> ذخیره تغییرات
                </button>
                <a href="?Page=suppliers" class="btn btn-neutral">
                    <i class="fa-solid fa-arrow-right"></i> بازگشت
                </a>
            </div>
        </form>
    <?php endif; ?>
</div>
