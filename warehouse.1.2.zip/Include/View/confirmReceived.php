<?php
// confirmReceived.php - to be implemented
