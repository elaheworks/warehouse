<?php include_once "./Include/View/header.php"; ?>

<div class="w-full mx-auto p-4 bg-base-100">
  <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
    <h2 class="text-2xl font-bold text-primary">📦 موجودی انبار</h2>
  </div>

  <!-- 🔍 جستجو + فیلترها -->
  <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-8">
    <input type="text" id="searchInput" placeholder="جستجوی نام کالا..." class="input input-bordered input-sm w-full" />

    <select id="categoryFilter" class="select select-bordered select-sm w-full">
      <option value="">دسته‌بندی (همه)</option>
      <?php foreach (array_keys($groupedInventory) as $category): ?>
        <option value="<?php echo htmlspecialchars($category); ?>"><?php echo htmlspecialchars($category); ?></option>
      <?php endforeach; ?>
    </select>

    <select id="supplierFilter" class="select select-bordered select-sm w-full">
      <option value="">تأمین‌کننده (همه)</option>
      <?php
      $allSuppliers = [];
      foreach ($groupedInventory as $items) {
        foreach ($items as $inv) {
          $allSuppliers[$inv['supplier_name']] = true;
        }
      }
      foreach (array_keys($allSuppliers) as $supplier):
      ?>
        <option value="<?php echo htmlspecialchars($supplier); ?>"><?php echo htmlspecialchars($supplier); ?></option>
      <?php endforeach; ?>
    </select>

    <div class="flex gap-3 items-center justify-start">
      <label class="label cursor-pointer gap-2 text-xs">
        <input type="checkbox" id="lowStockFilter" class="checkbox checkbox-sm" />
        <span class="label-text">فقط کالاهای زیر حد</span>
      </label>
      <label class="label cursor-pointer gap-2 text-xs">
        <input type="checkbox" id="expiringSoonFilter" class="checkbox checkbox-sm" />
        <span class="label-text">در حال انقضا</span>
      </label>
    </div>
  </div>

  <div id="inventoryWrapper">
    <?php if (!empty($groupedInventory)): ?>
      <?php foreach ($groupedInventory as $category => $items): ?>
        <div class="mb-8 inventory-category" data-category="<?php echo htmlspecialchars($category); ?>">
          <h3 class="text-lg font-semibold mb-3 border-b border-primary/50 pb-1 text-primary-content">
            🗂️ <?php echo htmlspecialchars($category); ?>
          </h3>
          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            <?php foreach ($items as $inv): ?>
              <?php
              $lowStock = $inv['quantity'] <= $inv['par_level'];
              list($y, $m, $d) = parseJalaliDate($inv['expiration_date']);
              list($gy, $gm, $gd) = jalaliToGregorian($y, $m, $d);
              $dateStr = sprintf('%04d-%02d-%02d', $gy, $gm, $gd);
              $expiringSoon = strtotime($dateStr) <= strtotime('+7 days');
              $statusColor = $lowStock ? 'border-error bg-error/5' : ($expiringSoon ? 'border-warning bg-warning/5' : 'border-base-200');
              // مدیریت خطا یا مقدار پیشفرض
              

              ?>
              <div class="card border <?php echo $statusColor; ?> shadow-md inventory-card transition-all"
                data-name="<?php echo htmlspecialchars($inv['item_name']); ?>"
                data-category="<?php echo htmlspecialchars($category); ?>"
                data-supplier="<?php echo htmlspecialchars($inv['supplier_name']); ?>"
                data-lowstock="<?php echo $lowStock ? '1' : '0'; ?>"
                data-expiring="<?php echo $expiringSoon ? '1' : '0'; ?>">
                <div class="card-body p-4 space-y-2 text-sm">
                  <div class="flex justify-between items-start">
                    <h4 class="font-bold text-base-content"><?php echo htmlspecialchars($inv['item_name']); ?></h4>
                    <span class="badge badge-outline badge-xs"><?php echo htmlspecialchars($inv['brand']); ?></span>
                  </div>

                  <div class="flex flex-wrap gap-1 text-xs">
                    <?php if ($lowStock): ?>
                      <span class="badge badge-error text-white">⚠️ کمبود</span>
                    <?php endif; ?>
                    <?php if ($expiringSoon): ?>
                      <span class="badge badge-warning text-white">⏰ انقضا نزدیک</span>
                    <?php endif; ?>
                  </div>

                  <ul class="space-y-0.5 text-gray-700">
                    <li>📏 مقدار: <strong><?php echo $inv['quantity'] . " " . $inv['unit_name']; ?></strong></li>
                    <li>💰 قیمت: <?php echo number_format($inv['unit_price']); ?> ریال</li>
                    <li>💵 ارزش: <?php echo number_format($inv['unit_price'] * $inv['quantity']); ?> ریال</li>
                    <li>🏢 تأمین‌کننده: <?php echo htmlspecialchars($inv['supplier_name']); ?></li>
                    <li>📅 انقضا: <b dir="ltr"><?php echo $inv['expiration_date']; ?></b></li>
                  </ul>

                  <?php if (!empty($inv['note'])): ?>
                    <p class="text-xs italic text-gray-500 border-t pt-1"><?php echo nl2br(htmlspecialchars($inv['note'])); ?></p>
                  <?php endif; ?>

                  <div class="card-actions mt-2 flex justify-between content-end">
                    <a href="?Page=editInventory&id=<?php echo $inv['id']; ?>" class="btn btn-xs btn-outline btn-primary gap-1">✏️ ویرایش</a>
                    <a href="?Page=showRequests&selectedItem=<?php echo $inv['item_id']; ?>" class="btn btn-xs btn-outline btn-warning gap-1">📤 برداشت</a>
                  </div>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        </div>
      <?php endforeach; ?>
    <?php else: ?>
      <div class="alert alert-info">هیچ آیتمی در موجودی ثبت نشده است.</div>
    <?php endif; ?>
  </div>
</div>

<script>
  function applyFilters() {
    const term = document.getElementById("searchInput").value.toLowerCase();
    const cat = document.getElementById("categoryFilter").value;
    const supplier = document.getElementById("supplierFilter").value;
    const lowStock = document.getElementById("lowStockFilter").checked;
    const expiring = document.getElementById("expiringSoonFilter").checked;

    document.querySelectorAll(".inventory-card").forEach(card => {
      const name = card.dataset.name.toLowerCase();
      const category = card.dataset.category;
      const cardSupplier = card.dataset.supplier;
      const isLowStock = card.dataset.lowstock === "1";
      const isExpiring = card.dataset.expiring === "1";

      const matchesSearch = !term || name.includes(term);
      const matchesCategory = !cat || cat === category;
      const matchesSupplier = !supplier || supplier === cardSupplier;
      const matchesLow = !lowStock || isLowStock;
      const matchesExp = !expiring || isExpiring;

      card.style.display = (matchesSearch && matchesCategory && matchesSupplier && matchesLow && matchesExp) ? "" : "none";
    });
  }

  document.querySelectorAll("#searchInput, #categoryFilter, #supplierFilter, #lowStockFilter, #expiringSoonFilter")
    .forEach(el => el.addEventListener("input", applyFilters));
</script>