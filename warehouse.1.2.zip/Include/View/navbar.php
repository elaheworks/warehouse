<div class="navbar bg-base-100 rounded-box hidden lg:flex">
    <div class="navbar-start">
        <div class="dropdown">
            <div tabindex="0" role="button" class="btn btn-ghost btn-circle">
                <i class="fa-solid fa-palette"></i>
            </div>
            <ul tabindex="0" class="menu menu-sm dropdown-content bg-base-100 rounded-box z-[101] mt-4 w-32 p-2 shadow">
                <li><input type="radio" name="theme-dropdown" class="theme-controller btn btn-sm btn-block btn-ghost justify-start" aria-label="nord" value="nord"/></li>
                <li><input type="radio" name="theme-dropdown" class="theme-controller btn btn-sm btn-block btn-ghost justify-start" aria-label="light" value="garden" /></li>
                <li><input type="radio" name="theme-dropdown" class="theme-controller btn btn-sm btn-block btn-ghost justify-start" aria-label="dark" value="dracula" /></li>
                <li><input type="radio" name="theme-dropdown" class="theme-controller btn btn-sm btn-block btn-ghost justify-start" aria-label="retro" value="retro" /></li>
                <li><input type="radio" name="theme-dropdown" class="theme-controller btn btn-sm btn-block btn-ghost justify-start" aria-label="cupcake" value="cupcake" /></li>
                <li><input type="radio" name="theme-dropdown" class="theme-controller btn btn-sm btn-block btn-ghost justify-start" aria-label="Valentine" value="valentine" /></li>
                <li><input type="radio" name="theme-dropdown" class="theme-controller btn btn-sm btn-block btn-ghost justify-start" aria-label="pastel" value="pastel" /></li>
                <li><input type="radio" name="theme-dropdown" class="theme-controller btn btn-sm btn-block btn-ghost justify-start" aria-label="forest" value="forest" /></li>
                <li><input type="radio" name="theme-dropdown" class="theme-controller btn btn-sm btn-block btn-ghost justify-start" aria-label="coffee" value="coffee" /></li>
                <li><input type="radio" name="theme-dropdown" class="theme-controller btn btn-sm btn-block btn-ghost justify-start" aria-label="sunset" value="sunset" /></li>
                <li><input type="radio" name="theme-dropdown" class="theme-controller btn btn-sm btn-block btn-ghost justify-start" aria-label="autumn" value="autumn" /></li>
                <li><input type="radio" name="theme-dropdown" class="theme-controller btn btn-sm btn-block btn-ghost justify-start" aria-label="dim" value="dim" /></li>
            </ul>
        </div>

    </div>
    <div class="navbar-center">
        <a href="<?php echo $_SESSION['WebsiteUrl']; ?>" class="btn btn-ghost text-xl">شهر کاغذی</a>

    </div>
    <div class="navbar-end">
        <!-- Notification Bell with Indicator -->
        <?php if (RoleMatches(['translator', 'admin'], $Role)): ?>
        <div class="avatar online">
            <a class="btn w-14 h-14 rounded-full" href="?Page=showMessages">
                <i class="fa-solid fa-bell"></i>
            </a>
        </div>
        <?php endif; ?>
        <div class="dropdown dropdown-end">
            <div tabindex="0" role="button" class="btn btn-link">
                <div class="avatar">
                    <div class="mask mask-squircle w-14">
                        <img src="<?php echo $_SESSION['UserInfoPNL']['pic']; ?>" />
                    </div>
                </div>
            </div>
            <ul tabindex="0" class="menu menu-sm dropdown-content bg-base-100 rounded-box z-[101] mt-3 w-32 p-2 shadow">
                <li><a href="?Page=editProfile">پروفایل</a></li>
                <li><a onclick="logout_modal.showModal()">خروج</a></li>
            </ul>
        </div>
    </div>
</div>
<dialog id="logout_modal" class="modal">
    <div class="modal-box">
        <h3 class="text-lg font-bold">هشدار</h3>
        <p class="py-4">مطمئنی می‌خوای از حسابت خارج شی؟</p>
        <div class="modal-action">
            <a role="button" class="btn btn-primary me-2" href="?Logout=1">آره</a>
            <form method="dialog">
                <button class="btn">نه</button>
            </form>
        </div>
    </div>
</dialog>

<!-- BUTTOM NAV -->

<div class="menu bg-base-100 menu-horizontal menu-xs w-full fixed bottom-0 left-0 right-0 justify-around lg:hidden z-50">
    <a>
        <div class="dropdown dropdown-top">
            <div tabindex="0">
                <i class="fa-solid fa-palette"></i>
            </div>
            <ul tabindex="0" class="menu menu-sm dropdown-content bg-base-100 rounded-box z-[110] mt-4 w-32 p-2 shadow">
                <li><input type="radio" name="theme-dropdown" class="theme-controller btn btn-sm btn-block btn-ghost justify-start" aria-label="nord" value="nord"/></li>
                <li><input type="radio" name="theme-dropdown" class="theme-controller btn btn-sm btn-block btn-ghost justify-start" aria-label="light" value="garden" /></li>
                <li><input type="radio" name="theme-dropdown" class="theme-controller btn btn-sm btn-block btn-ghost justify-start" aria-label="dark" value="dracula" /></li>
                <li><input type="radio" name="theme-dropdown" class="theme-controller btn btn-sm btn-block btn-ghost justify-start" aria-label="retro" value="retro" /></li>
                <li><input type="radio" name="theme-dropdown" class="theme-controller btn btn-sm btn-block btn-ghost justify-start" aria-label="cupcake" value="cupcake" /></li>
                <li><input type="radio" name="theme-dropdown" class="theme-controller btn btn-sm btn-block btn-ghost justify-start" aria-label="Valentine" value="valentine" /></li>
                <li><input type="radio" name="theme-dropdown" class="theme-controller btn btn-sm btn-block btn-ghost justify-start" aria-label="pastel" value="pastel" /></li>
                <li><input type="radio" name="theme-dropdown" class="theme-controller btn btn-sm btn-block btn-ghost justify-start" aria-label="forest" value="forest" /></li>
                <li><input type="radio" name="theme-dropdown" class="theme-controller btn btn-sm btn-block btn-ghost justify-start" aria-label="coffee" value="coffee" /></li>
                <li><input type="radio" name="theme-dropdown" class="theme-controller btn btn-sm btn-block btn-ghost justify-start" aria-label="sunset" value="sunset" /></li>
                <li><input type="radio" name="theme-dropdown" class="theme-controller btn btn-sm btn-block btn-ghost justify-start" aria-label="autumn" value="autumn" /></li>
                <li><input type="radio" name="theme-dropdown" class="theme-controller btn btn-sm btn-block btn-ghost justify-start" aria-label="dim" value="dim" /></li>
            </ul>
        </div>
    </a>
    <button class="active text-primary">
        <label for="my-drawer-2" class="swap swap-rotate drawer-button lg:hidden">
            <input type="checkbox" />
            <i class="swap-off fas fa-bars"></i>
            <i class="swap-on fas fa-times"></i>
        </label>
    </button>


    <button>
        <div class="dropdown dropdown-top dropdown-end">
            <div tabindex="0" role="button">
                <div class="avatar">
                    <div class="mask mask-squircle w-4">
                        <img src="<?php echo $_SESSION['UserInfoPNL']['pic']; ?>" />
                    </div>
                </div>
            </div>
            <ul tabindex="0" class="menu menu-sm dropdown-content bg-base-100 rounded-box z-[101] mt-3 w-32 p-2 shadow">
                <li><a href="?Page=editProfile">پروفایل</a></li>
                <li><a onclick="logout_modal.showModal()">خروج</a></li>
            </ul>
        </div>
    </button>
</div>
<!-- SIDENAV START -->
<div class="drawer lg:drawer-open">
    <input id="my-drawer-2" type="checkbox" class="drawer-toggle" />
    <div class="drawer-content flex flex-col">
        <!-- MAIN CONENT GOES HERE -->
        <div class="container p-4 min-h-screen">
            <!-- <div class="breadcrumbs text-sm bg-base-100 rounded-box p-5 mb-3 lg:hidden">
                <ul>
                    <li class="text-secondary"><a>Home</a></li>
                    <li class="text-secondary"><a>Documents</a></li>
                    <li>Add Document</li>
                </ul>
            </div> -->
            <?php echo $Alert; ?>