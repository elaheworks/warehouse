<?php
include_once "./Include/View/header.php";
include_once "./helpers/dashboardCard.php";

use CL\Items;
use CL\Transactions;

$ItemModel = new Items();
$TransactionModel = new Transactions();

function safeGet($array, $key, $default = '') {
    return htmlspecialchars($array[$key] ?? $default);
}

$lowStockCount = $ItemModel->Raw("SELECT COUNT(*) AS count FROM items WHERE quantity <= min_amount");
$lowStockCount = $lowStockCount !== -1 ? $lowStockCount[0]['count'] : 0;

$pendingOrdersCount = 3; // TODO: Replace with dynamic count if available

$inventoryValue = $ItemModel->Raw("SELECT SUM(unit_price * quantity) AS total FROM items");
$inventoryValue = $inventoryValue !== -1 ? $inventoryValue[0]['total'] : 0;

$recentTransactions = $TransactionModel->Raw("SELECT COUNT(*) AS count FROM transactions WHERE rec_date >= NOW() - INTERVAL 7 DAY");
$recentTransactions = $recentTransactions !== -1 ? $recentTransactions[0]['count'] : 0;

$userInfo = $_SESSION['UserInfoPNL'] ?? [];
$profilePic = safeGet($userInfo, 'pic', 'assets/imgs/avatar/default.jpg');
?>

<div class="w-full mx-auto p-6 bg-base-100">
  <!-- Profile Stats -->
  <div class="stats shadow mb-5 w-full stats-vertical md:stats-horizontal">
    <div class="stat">
      <div class="stat-figure text-secondary">
        <div class="avatar">
          <div class="w-16 rounded-full">
            <img src="<?= $profilePic ?>" alt="عکس کاربر" />
          </div>
        </div>
      </div>
      <div class="stat-title"><?= safeGet($userInfo, 'username') ?></div>
      <div class="stat-value"><?= safeGet($userInfo, 'name') ?></div>
      <div class="stat-desc text-secondary"><?= RoleName($Role) ?></div>
      <div class="stat-desc"><?= safeGet($userInfo, 'email') ?></div>
    </div>
    <div class="stat place-items-center">
      <div class="stat-title">آخرین ورود</div>
      <div class="stat-value text-secondary"><?= safeGet($userInfo, 'last_login', 'نامشخص') ?></div>
      <div class="stat-desc">
        <a href="?Page=logout" class="btn btn-sm btn-error mt-2">خروج</a>
      </div>
    </div>
  </div>

  <!-- Summary Cards -->
  <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
    <?php if (RoleMatches(['مدیر', 'انباردار'], $Role)) echo dashboardCard("fa-exclamation-circle", "error", "اقلام با موجودی کم", $lowStockCount, "?Page=showItems"); ?>
    <?php if (RoleMatches(['مدیر'], $Role)) echo dashboardCard("fa-shopping-cart", "warning", "سفارشات در انتظار", $pendingOrdersCount, "?Page=showOrders"); ?>
    <?php if (RoleMatches(['مدیر'], $Role)) echo dashboardCard("fa-warehouse", "secondary", "ارزش کل موجودی", number_format($inventoryValue) . ' ریال', "?Page=showInventory"); ?>
    <?php if (RoleMatches(['مدیر', 'انباردار'], $Role)) echo dashboardCard("fa-exchange-alt", "success", "تراکنش‌های اخیر", $recentTransactions, "?Page=showStockTransactions"); ?>
  </div>

  <!-- Charts -->
  <?php if (RoleMatches(['مدیر'], $Role)): ?>
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-4">
      <div class="card bg-base-100 shadow-xl">
        <div class="card-body">
          <h2 class="card-title">موجودی بر اساس دسته‌بندی</h2>
          <canvas id="inventoryChart"></canvas>
        </div>
      </div>
      <div class="card bg-base-100 shadow-xl">
        <div class="card-body">
          <h2 class="card-title">روند سفارشات</h2>
          <p class="text-center text-gray-500">در حال توسعه...</p>
        </div>
      </div>
    </div>
  <?php endif; ?>

  <!-- Quick Access Links -->
  <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
    <?php if (RoleMatches(['مدیر', 'انباردار'], $Role)): ?>
      <a href="?Page=showItems" class="card bg-base-100 p-2 hover:bg-base-300 border-2 border-primary">
        <div class="card-body items-center text-center">
          <h4 class="card-title"><i class="fa-solid fa-box"></i></h4>
          <p class="mt-4">مدیریت کالاها</p>
        </div>
      </a>
    <?php endif; ?>
    <?php if (RoleMatches(['مدیر'], $Role)): ?>
      <a href="?Page=showOrders" class="card bg-base-100 p-2 hover:bg-base-300 border-2 border-primary">
        <div class="card-body items-center text-center">
          <h4 class="card-title"><i class="fa-solid fa-shopping-cart"></i></h4>
          <p class="mt-4">مدیریت سفارشات</p>
        </div>
      </a>
      <a href="?Page=showUsers" class="card bg-base-100 p-2 hover:bg-base-300 border-2 border-primary">
        <div class="card-body items-center text-center">
          <h4 class="card-title"><i class="fa-solid fa-user"></i></h4>
          <p class="mt-4">مدیریت کاربران</p>
        </div>
      </a>
    <?php endif; ?>
    <a href="?Page=editProfile" class="card bg-base-100 p-2 hover:bg-base-300 border-2 border-primary">
      <div class="card-body items-center text-center">
        <h4 class="card-title"><i class="fa-regular fa-pen-to-square"></i></h4>
        <p class="mt-4">ویرایش اطلاعات</p>
      </div>
    </a>
  </div>
</div>

<?php if (RoleMatches(['مدیر'], $Role)): ?>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <script>
  document.addEventListener('DOMContentLoaded', () => {
    const ctx = document.getElementById('inventoryChart').getContext('2d');
    new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ['مواد ۳', 'مواد ۲', 'مواد غذایی'],
        datasets: [{
          label: 'موجودی',
          data: [50, 30, 20], // TODO: Replace with dynamic values
          backgroundColor: ['#4f46e5', '#10b981', '#ef4444']
        }]
      },
      options: {
        scales: { y: { beginAtZero: true } },
        plugins: { legend: { display: false } }
      }
    });
  });
  </script>
<?php endif; ?>
