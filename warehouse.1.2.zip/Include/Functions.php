<?php

namespace CL;

use PDO;
use PDOException;

class Functions
{
    protected $pdo;
    protected $TableName;

    public function __construct($configFile = 'Config1', $tableName = '')
    {
        $this->TableName = $tableName;
        $this->pdo = $this->connect($configFile);
    }

    protected function connect($configFile)
    {
        include "Configs/{$configFile}.php"; // expects $dsn, $username, $password

        try {
            $pdo = new PDO($dsn, $username, $password, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]);
            return $pdo;
        } catch (PDOException $e) {
            die("DB Connection failed: " . $e->getMessage());
        }
    }

    protected function buildConditions($where, $operator = 'AND', &$params = [])
    {
        $clauses = [];
        foreach ($where as $column => $value) {
            if (is_int($column)) {
                $clauses[] = $value;
            } elseif (stripos($column, '!=') !== false) {
                $col = trim(str_ireplace('!=', '', $column));
                $clauses[] = "$col != ?";
                $params[] = $value;
            } elseif (stripos($column, ' LIKE') !== false) {
                $col = trim(str_ireplace('LIKE', '', $column));
                $clauses[] = "$col LIKE ?";
                $params[] = $value;
            } elseif (stripos($column, ' BETWEEN') !== false) {
                $col = trim(str_ireplace('BETWEEN', '', $column));
                [$min, $max] = explode(' AND ', $value);
                $clauses[] = "$col BETWEEN ? AND ?";
                $params[] = $min;
                $params[] = $max;
            } else {
                $clauses[] = "$column = ?";
                $params[] = $value;
            }
        }
        return implode(" $operator ", $clauses);
    }

    public function Select($columns = "*", $where = [], $operator = 'AND', $order_by = "id DESC")
    {
        $params = [];
        $sql = "SELECT $columns FROM {$this->TableName}";

        if (!empty($where)) {
            $sql .= " WHERE " . $this->buildConditions($where, $operator, $params);
        }

        if (!empty($order_by)) {
            $sql .= " ORDER BY $order_by";
        }

        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        $results = $stmt->fetchAll();
        return $results ?: -1;
    }

    public function Insert(array $data)
    {
        if (empty($data)) return -1;

        $columns = implode(', ', array_keys($data));
        $placeholders = rtrim(str_repeat('?, ', count($data)), ', ');
        $sql = "INSERT INTO {$this->TableName} ($columns) VALUES ($placeholders)";
        $stmt = $this->pdo->prepare($sql);

        if ($stmt->execute(array_values($data))) {
            return $this->pdo->lastInsertId();
        }
        return -1;
    }

    public function Update(array $data, array $where, $operator = 'AND')
    {
        if (empty($data) || empty($where)) return -1;

        $params = [];
        $set = implode(', ', array_map(function ($key) {
            return "$key = ?";
        }, array_keys($data)));
        $params = array_values($data);

        $whereClause = $this->buildConditions($where, $operator, $params);
        $sql = "UPDATE {$this->TableName} SET $set WHERE $whereClause";
        $stmt = $this->pdo->prepare($sql);

        if ($stmt->execute($params)) {
            return $stmt->rowCount();
        }
        return -1;
    }

    public function Delete(array $where, $operator = 'AND')
    {
        if (empty($where)) return -1;

        $params = [];
        $whereClause = $this->buildConditions($where, $operator, $params);
        $sql = "DELETE FROM {$this->TableName} WHERE $whereClause";
        $stmt = $this->pdo->prepare($sql);

        if ($stmt->execute($params)) {
            return $stmt->rowCount();
        }
        return -1;
    }

    public function Raw($sql, $params = [])
    {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        $results = $stmt->fetchAll();
        return $results ?: -1;
    }

    public function SelectRow($fields = "*", $where = "1", $params = [], $extra = "")
    {
        $sql = "SELECT $fields FROM $this->TableName WHERE $where $extra";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }


    public function SelectJoin($columns = ["*"], $tables = [], $where = [], $order_by = "id DESC")
    {
        if (empty($tables)) return -1;
        $params = [];
        $columns_sql = is_array($columns) ? implode(", ", $columns) : $columns;

        $from_sql = "";
        foreach ($tables as $index => $table) {
            [$tableName, $onClause, $joinType] = array_pad($table, 3, '');
            $joinType = strtoupper($joinType);
            if ($index == 0) {
                $from_sql .= $tableName;
            } else {
                if (!in_array($joinType, ["LEFT", "RIGHT", "INNER", "FULL"])) {
                    $joinType = "INNER";
                }
                $from_sql .= " {$joinType} JOIN {$tableName} ON {$onClause}";
            }
        }

        $sql = "SELECT {$columns_sql} FROM {$from_sql}";

        if (!empty($where)) {
            $sql .= " WHERE " . $this->buildConditions($where, 'AND', $params);
        }

        if (!empty($order_by)) {
            $sql .= " ORDER BY {$order_by}";
        }

        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        $results = $stmt->fetchAll();
        return $results ?: -1;
    }

    public function Exist(array $where)
    {
        return $this->Select("id", $where) !== -1;
    }

    public function Info($id)
    {
        $result = $this->Select("*", ['id' => $id]);
        return $result !== -1 ? $result[0] : null;
    }
}

class LoggableFunctions extends Functions
{
    protected function logAction($action, $data)
    {
        $logModel = new Functions('Config2', 'logs');
        $logModel->Insert([
            'user_id' => $_SESSION['UserId'] ?? 0,
            'action' => $action,
            'table_name' => $this->TableName,
            'data' => json_encode($data, JSON_UNESCAPED_UNICODE),
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '',
            'created_at' => date('Y-m-d H:i:s')
        ]);
    }

    public function Insert(array $data)
    {
        $result = parent::Insert($data);
        if ($result != -1) {
            $this->logAction('insert', $data);
        }
        return $result;
    }

    public function Update(array $data, array $where, $operator = 'AND')
    {
        $result = parent::Update($data, $where, $operator);
        if ($result != -1) {
            $this->logAction('update', ['data' => $data, 'where' => $where]);
        }
        return $result;
    }

    public function Delete(array $where, $operator = 'AND')
    {
        $result = parent::Delete($where, $operator);
        if ($result != -1) {
            $this->logAction('delete', ['where' => $where]);
        }
        return $result;
    }
}
