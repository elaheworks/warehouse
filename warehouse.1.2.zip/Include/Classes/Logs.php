<?php
namespace CL;

use CL\Functions as ALL;

class Logs extends ALL
{
    public function __construct()
    {
        parent::__construct('Config2', 'logs');
    }

    /**
     * Log an action to the database.
     */
    public function record($user_id, $action, $table, $data = [], $ip = null)
    {
        return $this->Insert([
            'user_id' => $user_id,
            'action' => $action,
            'table_name' => $table,
            'data' => json_encode($data, JSON_UNESCAPED_UNICODE),
            'ip_address' => $ip ?? $_SERVER['REMOTE_ADDR'],
            'created_at' => date('Y-m-d H:i:s')
        ]);
    }
}
