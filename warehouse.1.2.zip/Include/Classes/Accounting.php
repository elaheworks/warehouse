<?php
namespace CL;

use CL\LoggableFunctions as ALL;

class Accounts extends ALL
{
    public function __construct()
    {
        parent::__construct('Config1', 'accounts');
    }

}


class Transactions extends ALL
{
    public function __construct()
    {
        parent::__construct('Config1', 'transactions');
    }

    public function addTransaction($data)
    {
        return $this->Insert($data);
    }

    public function updateTransaction($id, $data)
    {
        return $this->Update($data, ['id' => $id]);
    }

    public function deleteTransaction($id)
    {
        return $this->Update(['status' => -1], ['id' => $id]);
    }

    public function getById($id)
    {
        return $this->Info($id);
    }

    public function getAll()
{
    $sql = "
        SELECT 
            t.id,
            t.payment_method,
            t.tracking_code,
            t.reg_date,
            t.rec_date,
            t.mode,
            t.status,
            t.account_id,
            acc.name AS account_name,
            t.reg_id,
            regUser.name AS reg_name,
            regUser.role AS reg_role,
            t.rec_id,
            recUser.name AS rec_name,
            recUser.role AS rec_role
        FROM transactions t
        INNER JOIN accounts acc ON t.account_id = acc.id
        LEFT JOIN users regUser ON t.reg_id = regUser.id
        LEFT JOIN users recUser ON t.rec_id = recUser.id
        WHERE t.status != -1
        ORDER BY t.id DESC
    ";

    return $this->Raw($sql) ?: [];
}

}
