<?php
namespace CL;

class Purchases extends LoggableFunctions
{
    public function __construct()
    {
        parent::__construct('Config1', 'purchases');
    }

    // افزودن خرید به فاکتور
    public function addItemToInvoice($invoice_id, $item_id, $quantity, $unit_price, $unit_id, $expiration_date, $note = null)
    {
        return $this->Insert([
            'invoice_id' => $invoice_id,
            'item_id' => $item_id,
            'quantity' => $quantity,
            'unit_price' => $unit_price,
            'total_price' => $quantity * $unit_price,
            'unit_id' => $unit_id,
            'expiration_date' => $expiration_date,
            'note' => $note,
            'status' => 0
        ]);
    }

    // حذف خرید از فاکتور
    public function deleteItemFromInvoice($purchase_id)
    {
        return $this->Delete(['id' => $purchase_id]);
    }

    // ویرایش خرید داخل فاکتور (در صورت نیاز)
    public function updatePurchase($purchase_id, $data)
    {
        return $this->Update($data, ['id' => $purchase_id]);
    }

    
}
