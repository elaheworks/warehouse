<?php

namespace CL;

use CL\LoggableFunctions as ALL;

class Items extends ALL
{
    public function __construct()
    {
        parent::__construct('Config1', 'items');
    }

}

class MasterItems extends ALL
{
    public function __construct()
    {
        parent::__construct('Config1', 'master_items');
    }

    public function getSuppliersForMasterItem($masterItemId) {
    return $this->SelectJoin(
        ["suppliers.name", "SUM(items.quantity) AS total_quantity"],
        [
            ["items"],
            ["suppliers", "items.supplier_id = suppliers.id", "INNER"]
        ],
        ["items.master_item_id" => $masterItemId],
        "total_quantity DESC"
    );
}


}

class Units extends All
{
    public function __construct()
    {
        parent::__construct('Config1', 'units');
    }
}
class Categories extends All
{
    public function __construct()
    {
        parent::__construct('Config1', 'categories');
    }
}

class Suppliers extends ALL
{
    public function __construct()
    {
        parent::__construct('Config1', 'suppliers');
    }

    public function ajaxAddSupplier()
    {
    // سپس اعتبارسنجی سشن یا کاربر
    if (!isset($_SESSION['UserKaIdPNL'])) {
        echo json_encode(['success' => false, 'message' => 'لطفاً ابتدا وارد شوید.']);
        exit;
    }
        header('Content-Type: application/json');
        $input = json_decode(file_get_contents('php://input'), true);
        $name = trim($input['name'] ?? '');

        if ($name === '') {
            echo json_encode(['success' => false, 'message' => 'نام وارد نشده']);
            exit;
        }

        // آیا تأمین‌کننده قبلاً وجود دارد؟
        $existing = $this->Select('id', ['name' => $name]);
        if ($existing != -1) {
            echo json_encode([
                'success' => true,
                'id' => $existing['id'],
                'name' => $name,
                'exists' => true
            ]);
            exit;
        }

        // ایجاد جدید
        $id = $this->Insert(['name' => $name]);
        if ($id) {
            echo json_encode([
                'success' => true,
                'id' => $id,
                'name' => $name,
                'exists' => false
            ]);
        } else {
            echo json_encode(['success' => false, 'message' => 'خطا در ثبت']);
        }
    }
}


class Customers extends All
{
    public function __construct()
    {
        parent::__construct('Config1', 'customers');
    }
}
