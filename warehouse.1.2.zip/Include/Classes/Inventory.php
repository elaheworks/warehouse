<?php

namespace CL;

use CL\LoggableFunctions as ALL;

class Inventory extends All
{
    public function __construct()
    {
        parent::__construct('Config1', 'stocks');
    }

    public function getFullInventoryData()
    {
        $sql = "
            SELECT 
                i.id,
                i.item_id,
                items.product AS item_name,
                i.quantity,
                i.unit_price,
                i.unit_id,
                units.name AS unit_name,
                i.category_id,
                categories.name AS category_name,
                i.supplier_id,
                suppliers.name AS supplier_name,
                i.note,
                i.status,
                i.mode,
                i.expiration_date,
                items.par_level,
                items.brand AS brand
            FROM stocks i
            INNER JOIN items ON i.item_id = items.id
            INNER JOIN categories ON i.category_id = categories.id
            INNER JOIN units ON i.unit_id = units.id
            INNER JOIN suppliers ON i.supplier_id = suppliers.id
            WHERE i.status = 1
            ORDER BY categories.name, items.product
        ";

        $data = $this->Raw($sql);
        return $data !== -1 ? $data : [];
    }

    public function getGroupedInventory()
    {
        $fullData = $this->getFullInventoryData();
        $grouped = [];

        foreach ($fullData as $row) {
            $cat = $row['category_name'] ?? 'بدون دسته‌بندی';
            
            if (!isset($grouped[$cat])) {
                $grouped[$cat] = [];
            }
            $grouped[$cat][] = $row;
        }

        return $grouped;
    }
    public function increaseInventory($data)
    {
        // اعتبارسنجی مقادیر ورودی
        if (
            !isset($data['item_id'], $data['quantity'], $data['unit_price'], $data['unit_id'], $data['supplier_id'])
            || $data['quantity'] <= 0 || $data['unit_price'] < 0
        ) {
            return -1;
        }

        // بررسی آیا آیتم با این آیتم، تأمین‌کننده و واحد از قبل وجود دارد؟
        $existing = $this->Select("*", [
            'item_id' => $data['item_id'],
            'unit_id' => $data['unit_id'],
            'supplier_id' => $data['supplier_id'],
            'expiration_date' => $data['expiration_date'] ?? null,
        ]);

        if ($existing != -1) {
            // به‌روزرسانی مقدار موجودی و قیمت
            $current = $existing[0];
            $newQuantity = $current['quantity'] + $data['quantity'];
            $newPrice = $data['unit_price']; // یا میانگین وزنی اگر لازم باشد

            return $this->Update([
                'quantity' => $newQuantity,
                'unit_price' => $newPrice,
                'note' => $current['note'] . "\n" . ($data['note'] ?? ''),
            ], ['id' => $current['id']]);
        } else {
            // افزودن رکورد جدید
            return $this->Insert([
                'item_id' => $data['item_id'],
                'quantity' => $data['quantity'],
                'unit_price' => $data['unit_price'],
                'unit_id' => $data['unit_id'],
                'supplier_id' => $data['supplier_id'],
                'category_id' => $data['category_id'] ?? 0,
                'expiration_date' => $data['expiration_date'] ?? "2025-12-12",
                'note' => $data['note'] ?? '',

            ]);
        }
    }
}




class TransferRequests extends ALL
{
    public function __construct()
    {
        parent::__construct('Config1', 'transfer_requests');
    }

    /**
     * دریافت درخواست‌های انتقال با اطلاعات کامل آیتم، واحد، کاربر، و وضعیت.
     */
    public function getDetailedRequests()
    {
        $sql = "
            SELECT 
                r.id,
                r.from_location,
                r.to_location,
                r.quantity,
                items.unit_id AS unit_id,
                units.name AS unit_name,
                r.item_id,
                items.product AS item_name,
                r.status,
                r.requested_by,
                users1.name AS requested_by_name,
                r.requested_at,
                r.approved_by,
                users2.name AS approved_by_name,
                r.approved_at,
                r.completed_by,
                users3.name AS completed_by_name,
                r.completed_at,
                r.note,
                r.status_log
            FROM transfer_requests r
            LEFT JOIN items ON r.item_id = items.id
            LEFT JOIN units ON items.unit_id = units.id
            LEFT JOIN users users1 ON r.requested_by = users1.id
            LEFT JOIN users users2 ON r.approved_by = users2.id
            LEFT JOIN users users3 ON r.completed_by = users3.id
            ORDER BY r.requested_at DESC
        ";
        return $this->Raw($sql) ?: [];
    }

    /**
     * افزودن وضعیت جدید به لاگ وضعیت درخواست (status_log).
     */
    public function appendStatusLog($id, $status, $user_id)
    {
        $existing = $this->Info($id);
        if (!$existing || !isset($existing['status_log'])) return false;

        $log = json_decode($existing['status_log'], true) ?: [];
        $log[] = [
            'status' => $status,
            'user_id' => $user_id,
            'time' => date('Y-m-d H:i:s')
        ];

        return $this->Update([
            'status_log' => json_encode($log, JSON_UNESCAPED_UNICODE),
            'status' => $status
        ], ['id' => $id]);
    }

    public function getByUser($id){
        $sql = "SELECT 
                r.id,
                r.from_location,
                r.to_location,
                r.quantity,
                items.unit_id AS unit_id,
                units.name AS unit_name,
                r.item_id,
                items.product AS item_name,
                r.status,
                r.requested_by,
                users1.name AS requested_by_name,
                r.requested_at,
                r.approved_by,
                users2.name AS approved_by_name,
                r.approved_at,
                r.completed_by,
                users3.name AS completed_by_name,
                r.completed_at,
                r.note,
                r.status_log
            FROM transfer_requests r
            LEFT JOIN items ON r.item_id = items.id
            LEFT JOIN units ON items.unit_id = units.id
            LEFT JOIN users users1 ON r.requested_by = users1.id
            LEFT JOIN users users2 ON r.approved_by = users2.id
            LEFT JOIN users users3 ON r.completed_by = users3.id
            WHERE reg_id = ".$id."
            ORDER BY r.requested_at DESC
        ";
        return $this->Raw($sql) ?: [];
    }
}
