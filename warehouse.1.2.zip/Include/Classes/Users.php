<?php

namespace CL;

use CL\LoggableFunctions as ALL;

class Users extends ALL
{
    public function __construct()
    {
        parent::__construct('Config1', 'users');
    }

    public function Login($Username, $Password)
    {
        $hashedPassword = md5($Password);
        $User = $this->Select("*", [
            'username' => $Username,
            'password' => $hashedPassword
        ]);

        return ($User !== -1) ? $User[0] : -1;
    }

    public function generateResetToken()
    {
        return bin2hex(random_bytes(32));
    }

    public function canSendResetEmail($userId, $maxRequests = 3, $cooldownTime = 15)
    {
        $userData = $this->Select("reset_request_count, last_reset_request", ['id' => $userId]);

        if ($userData !== -1) {
            $resetRequestCount = $userData[0]['reset_request_count'];
            $lastResetRequest = $userData[0]['last_reset_request'];

            if ($lastResetRequest) {
                $lastRequestTime = strtotime($lastResetRequest);
                $currentTime = time();
                $minutesPassed = ($currentTime - $lastRequestTime) / 60;

                if ($minutesPassed < $cooldownTime) {
                    return false;
                }
            }

            if ($resetRequestCount >= $maxRequests) {
                return false;
            }

            return true;
        }

        return false;
    }

    public function incrementResetRequestCount($userId)
    {
        // Fetch current count manually to use raw math
        $userData = $this->Select("reset_request_count", ['id' => $userId]);

        if ($userData !== -1) {
            $newCount = $userData[0]['reset_request_count'] + 1;

            $this->Update([
                'reset_request_count' => $newCount,
                'last_reset_request' => date("Y-m-d H:i:s")
            ], ['id' => $userId]);
        }
    }

    public function sendPasswordResetLink($userId, $userEmail)
    {
        if ($this->canSendResetEmail($userId)) {
            $resetToken = $this->generateResetToken();

            $this->Update([
                'reset_token' => $resetToken,
                'reset_token_expiration' => date("Y-m-d H:i:s", strtotime('+1 hour'))
            ], ['id' => $userId]);

            $resetLink = $_SESSION['WebsiteUrl'] . "?RESET=" . urlencode($resetToken);

            if (sendEmail($userEmail, 'Password Reset Request', 'Click here to reset your password: ' . $resetLink)) {
                $this->incrementResetRequestCount($userId);
                $_SESSION['alert'] = Alert('success', 'لینکی که واسه عوض کردن رمز لازم داری به ایمیلت ارسال شد');
            } else {
                $_SESSION['alert'] = Alert('error', 'نتونستیم برات ایمیل بفرستیم به الاحه پیام بده');
            }
        } else {
            $_SESSION['alert'] = Alert('error', 'زیادی که نمی‌شه درخواست داد. برو بعدا بیا');
        }
    }

    public function Name($id)
    {
        $Name = $this->Select("name", ['id' => $id]);
        return ($Name !== -1) ? $Name[0]['name'] : "No Name";
    }
}

class Sessions extends ALL{
    public function __construct()
    {
        parent::__construct('Config1', 'sessions');
    }
    function generateSecureToken($length = 64) {
        return bin2hex(random_bytes($length / 2)); // Generates a random token of specified length
    }
}

class Logins extends ALL{
    public function __construct()
    {
        parent::__construct('Config1', 'logins');
    }

    // Function to check if the user has exceeded login attempts
    function checkLoginAttempts($username, $maxAttempts = 5, $cooldownPeriod = 30)
    {
        // Calculate the time window
        $currentTime = date('Y-m-d H:i:s');
        $startTime = date('Y-m-d H:i:s', strtotime("-$cooldownPeriod minutes"));

        // Fetch failed login attempts from the logs database
        $failedAttempts = $this->Select(
            "*",
            [
                'username' => $username,
                'status' => 'failure',
                'attempt_time BETWEEN' => $startTime . ' AND ' . $currentTime
            ]
        );

        // Check if the user has exceeded the maximum allowed attempts
        return $failedAttempts != -1 && count($failedAttempts) >= $maxAttempts;
    }

    // Function to record a failed login attempt in the logs database
    function recordFailedLoginAttempt($username)
    {
        $ipAddress = $_SERVER['REMOTE_ADDR'];
        // Insert the failed attempt into the logs database
        $this->Insert([
            'username' => $username,
            'status' => 'failure',
            'attempt_time' => date('Y-m-d H:i:s'), 
            'ip_address' => $ipAddress
        ]);
    }

    // Function to reset login attempts after a successful login
    function resetLoginAttempts($username)
    {

        // Clear the failed login attempts for the user from the logs database
        $this->Delete(['username' => $username, 'status' => 'failure']);
    }
}