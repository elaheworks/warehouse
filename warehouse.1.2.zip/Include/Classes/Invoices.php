<?php

namespace CL;

class Invoices extends LoggableFunctions
{
    public function __construct()
    {
        parent::__construct('Config1', 'invoices');
    }

    // ایجاد فاکتور جدید با جلوگیری از تکراری بودن شماره فاکتور
    public function createInvoice($data)
    {
        // بررسی تکراری نبودن شماره فاکتور
        $exists = $this->Select("*", ['invoice_number' => $data['invoice_number']]);
        if ($exists !== -1) {
            return -2; // فاکتور تکراری
        }

        return $this->Insert([
            'supplier_id' => $data['supplier_id'],
            'invoice_number' => $data['invoice_number'],
            'note' => $data['note'],
            'purchased_by' => $_SESSION['UserId'] ?? 0,
            'purchased_at' => $data['date'],
            'discount_type' => $data['discount_type'],
            'discount_value' => $data['discount_value'] ?? 0,
            'tax_type' => $data['tax_type'],
            'tax_value' => $data['tax_value'] ?? 0,
            'shipping_cost' => $data['shipping_cost'] ?? 0,
            'gift' => $data['gift'] ?? null,
            'status' => 0
        ]);
    }

    // تغییر وضعیت به تایید شده
    public function approveInvoice($invoice_id, $approved_by)
    {
        return $this->Update(
            [
                'status' => 1,
                'approved_by' => $approved_by,
                'approved_at' => date('Y-m-d H:i:s')
            ],
            ['id' => $invoice_id]
        );
    }

    // تغییر وضعیت به لغو
    public function cancelInvoice($invoice_id)
    {
        return $this->Update(
            [
                'status' => 3
            ],
            ['id' => $invoice_id]
        );
    }

    // تغییر مجموع قیمت فاکتور (حین افزودن آیتم)
    public function updateTotalPrice($invoice_id, $amount)
    {
        $sql = "UPDATE {$this->TableName} SET total_price = total_price + ? WHERE id = ?";
        $this->pdo->prepare($sql)->execute([$amount, $invoice_id]);
    }

    // حذف فاکتور (به همراه آیتم‌های آن)
    public function deleteInvoice($invoice_id)
    {
        $invoiceItems = new InvoiceItems();
        $invoiceItems->deleteAllItemsOfInvoice($invoice_id);
        return $this->Delete(['id' => $invoice_id]);
    }
}


class InvoiceItems extends LoggableFunctions
{
    protected $TableName = 'invoice_items';

    public function __construct($configFile = 'Config1')
    {
        parent::__construct($configFile, $this->TableName);
    }

    public function add($data)
    {
        $insertData = [
            "invoice_id"          => $data['invoice_id'],
            "item_id"             => $data['item_id'],
            "quantity"            => $data['quantity'],
            "unit_price"          => $data['unit_price'],
            "price_for_quantity"  => $data['price_for_quantity'] ?? null,
            "expiration_date"     => $data['expiration_date'],
            "unit_id"             => $data['unit_id'],
            "discount_type"       => $data['discount_type'] ?? null,
            "discount_value"      => $data['discount_value'] ?? null,
            "tax_type"            => $data['tax_type'] ?? null,
            "tax_value"           => $data['tax_value'] ?? null,
            "is_gift"             => isset($data['is_gift']) ? 1 : 0,
            "note"                => $data['note'] ?? null
        ];

        $res = $this->Insert($insertData);
        return $res;
    }

    public function edit($id, $data)
    {
        $updateData = [
            "quantity"           => $data['quantity'],
            "unit_price"         => $data['unit_price'],
            "price_for_quantity" => $data['price_for_quantity'] ?? null,
            "expiration_date"    => $data['expiration_date'],
            "discount_type"      => $data['discount_type'] ?? null,
            "discount_value"     => $data['discount_value'] ?? null,
            "tax_type"           => $data['tax_type'] ?? null,
            "tax_value"          => $data['tax_value'] ?? null,
            "is_gift"            => isset($data['is_gift']) ? 1 : 0,
            "note"               => $data['note'] ?? null
        ];

        $res = $this->Update($updateData, ["id" => $id]);
        return $res;
    }

    public function remove($id)
    {
        $res = $this->Delete(["id" => $id]);
        return $res;
    }
    public function deleteAllItemsOfInvoice($invoice_id)
    {
        return $this->Delete(['invoice_id' => $invoice_id]);
    }

    public function getInvoiceItems($invoice_id)
    {
        $result = $this->SelectJoin(
            [
                "invoice_items.*",
                "items.product AS item_name",
                "units.name AS buy_unit_name",
                "store_units.name AS store_unit_name"
            ],
            [
                ["invoice_items"],
                ["items", "invoice_items.item_id = items.id", "LEFT"],
                ["units", "invoice_items.unit_id = units.id", "LEFT"],
                ["units AS store_units", "invoice_items.store_unit_id = store_units.id", "LEFT"]
            ],
            ["invoice_items.invoice_id" => $invoice_id],
            "invoice_items.id ASC"
        );

        return $result === -1 ? [] : $result;
    }

    public function updateInventoryOnInvoiceApproval($invoice_id, $invoioce_number, $supplier_id)
    {
        $items = $this->Select("*", ['invoice_id' => $invoice_id]);
        if ($items === -1) return false;

        $inventory = new \CL\Inventory();
        $ItemsModel = new \CL\Items();

        foreach ($items as $item) {
            $exist = $inventory->Select("*", [
                'item_id' => $item['item_id'],
                'supplier_id' => $supplier_id,
                'expiration_date' => $item['expiration_date']
            ]);

            if ($exist !== -1) {
                // اگر موجود بود، موجودی افزایش یابد
                $existRow = $exist[0];

                $inventory->Update(
                    ['quantity' => $existRow['quantity'] + $item['quantity'], 'note' => $existRow['note'] . " / " . $existRow['note']],
                    ['id' => $existRow['id']]
                );
            } else {
                $cat = $ItemsModel->select('category_id', ['id' => $item['item_id']]);
                $cat = $cat[0]['category_id'] ?? 0; // اگر دسته‌بندی وجود نداشت، 0 قرار می‌دهیم
                // اگر موجود نبود، رکورد جدید بساز
                $inventory->Insert([
                    'item_id' => $item['item_id'],
                    'expiration_date' => $item['expiration_date'],
                    'quantity' => $item['quantity'],
                    'unit_price' => $item['unit_price'],
                    'unit_id' => $item['unit_id'],
                    'category_id' => $cat,
                    'supplier_id' => $supplier_id,
                    'note' => "شماره فاکتور: " . $invoioce_number,
                    'mode' => 1, // خرید
                    'status' => 1
                ]);
            }
        }

        return true;
    }
}
