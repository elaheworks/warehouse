<?php
use CL\Logs;
include_once('Include/jdf.php');
include_once('Functions.php');
include_once('Include/PHPMailer/Email.php');

//-------- CLASSES --------
include_once('Classes/Logs.php');
include_once('Classes/Users.php');
include_once('Classes/Items.php');
include_once('Classes/Inventory.php');
include_once('Classes/Purchase.php');
include_once('Classes/Invoices.php');
include_once('Classes/Accounting.php');

//------- !CLASSES --------
include_once('Classes.php');

//----- MAIN Functions ----
function PageName($pageName)
{
    $Name = [
        "dashboard" => "خونه",
        "showUsers" => "کاربران",
        "editUser" => "ویرایش کاربر",
        "showItems" => "کالاها",
        "editItem" => "ویرایش کالا",
        "showCategories" => "دسته‌بندی‌ها",
        "editCategory" => "ویرایش دسته‌بندی",
        "showSuppliers" => "تأمین‌کننده‌ها",
        "editSupplier" => "ویرایش تأمین‌کننده",
        "showUnits" => "واحدها",
        "editUnit" => "ویرایش واحد",
        "showStorageLocations" => "محل‌های ذخیره",
        "editStorageLocation" => "ویرایش محل ذخیره",
        "showCustomers" => "مشتریان",
        "editCustomer" => "ویرایش مشتری",
        "showInventory" => "انبار",
        "editInventory" => "ویرایش انبار",
        "showOrders" => "سفارشات",
        "editOrder" => "ویرایش سفارش",
        "showStockTransactions" => "تراکنش‌های انبار",
        "editStockTransaction" => "ویرایش تراکنش انبار",
        "showLogs" => "لاگ‌های سیستم",
        "showInventoryReport" => "گزارش موجودی",
        "showOrderReport" => "گزارش سفارشات",
        "logout" => "خروج"
    ];

    return isset($Name[$pageName]) ? $Name[$pageName] : $pageName;
}

function Alert($Type, $Message)
{
    if (!empty($Type)) {
        $alert = ' 
                <div role="alert" class="alert alert-' . $Type . ' shadow-lg mb-4 items-center">
                    <span>' . $Message . '</span>
                </div>
     ';
    } else {
        $alert = ' 
                <div role="alert" class="alert bg-base-100 shadow-lg mb-4 items-center">
                    <span>' . $Message . '</span>
                </div>
     ';
    }
    return $alert;
}


function RoleMatches(array $allowedRoles, string $userRole): bool {
    return in_array($userRole, $allowedRoles, true);
}

function RoleName($Role)
{
    
    return "role";
}

function truncate($text, $limit = 20)
{
    $words = explode(' ', $text);
    if (count($words) > $limit) {
        return implode(' ', array_slice($words, 0, $limit)) . '...';
    } else {
        return $text;
    }
}

function uploadImage($image, $folder)
{
    // Check if image file is uploaded and there are no errors
    if (isset($image) && $image['error'] == UPLOAD_ERR_OK) {
        // Your ImageKit Private API Key
        $private_key = "private_i1Ub3Ze7jC2JR0QGBdCWLhlHbEo=";  // Replace with your actual ImageKit private API key

        // Temporary file path and original file name
        $image_temp = $image['tmp_name'];
        $file_name = $image['name'];

        // Get MIME type using fileinfo
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime_type = finfo_file($finfo, $image_temp);
        finfo_close($finfo);

        // Create CURLFile object
        $file = new CURLFile($image_temp, $mime_type, $file_name);

        // ImageKit API endpoint
        $url = 'https://upload.imagekit.io/api/v1/files/upload';

        // Prepare the data for the API request
        $post_data = [
            'file' => $file,
            'fileName' => $file_name,
            'useUniqueFileName' => 'true', // Ensures unique filenames
            'folder' => '/Shahkar/'.$folder, // Organized storage
            'tags' => 'user-content,profile',
            'isPrivateFile' => 'false' // Set to true for restricted access
        ];

        // Initialize cURL session
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        // Set up Basic Authentication with ImageKit private key
        curl_setopt($ch, CURLOPT_USERPWD, $private_key . ":");

        // Execute cURL request and get the response
        $response = curl_exec($ch);
        $curl_error = curl_error($ch);
        curl_close($ch);

        // Check for cURL errors
        if ($curl_error) {
            $_SESSION['alert'] = Alert('error', "Upload failed: " . htmlspecialchars($curl_error));
            return -1;
        }

        // Decode the JSON response
        $response_data = json_decode($response, true);

        // Check if the upload was successful and return the URL
        if (isset($response_data['url'])) {
            return $response_data['url'];  // Return the uploaded image URL
        } else {
            // Handle API error
            $error_message = $response_data['message'] ?? 'Unknown error occurred';
            $_SESSION['alert'] = Alert('error', "Image upload failed: " . htmlspecialchars($error_message));
            return -1;
        }
    } else {
        $_SESSION['alert'] = Alert('error', "No image uploaded or upload error occurred");
        return -1;
    }
}

function getRandomTailwindColor()
{
    $colors = [
        'rose',
        'pink',
        'fuchsia',
        'purple',
        'violet',
        'indigo',
        'blue',
        'sky',
        'cyan',
        'teal',
        'emerald',
        'green',
        'lime',
        'yellow',
        'amber',
        'orange',
        'red',
        'gray'
    ];
    $randomColor = $colors[array_rand($colors)];
    return $randomColor;
}


function getUserNameById($id) {
    $Users = new \CL\Users();
    $result = $Users->Select("name", ['id' => $id]);
    return $result != -1 ? $result[0]['name'] : 'نامشخص';
}

function persianToEnglishNumbers($string) {
    $persianNumbers = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
    $englishNumbers = ['0','1','2','3','4','5','6','7','8','9'];
    return str_replace($persianNumbers, $englishNumbers, $string);
}

function parseJalaliDate($dateStr) {
    $dateStr = trim($dateStr);
    $dateStr = str_replace('/', '-', $dateStr); // اگر با / ذخیره شده
    $dateStr = persianToEnglishNumbers($dateStr); // اعداد فارسی به انگلیسی

    $parts = explode('-', $dateStr);
    if (count($parts) === 3) {
        return $parts;
    } else {
        return [1410, 12, 12]; // مقدار امن
    }
}

function jalaliToGregorian($jy, $jm, $jd) {
    $jy = (int)$jy - 979;
    $jm = (int)$jm - 1;
    $jd = (int)$jd - 1;

    $j_day_no = 365*$jy + (int)($jy/33)*8 + (int)((($jy%33)+3)/4);
    for ($i=0; $i < $jm; ++$i)
        $j_day_no += [31,31,31,31,31,31,30,30,30,30,30,29][$i];

    $j_day_no += $jd;

    $g_day_no = $j_day_no + 79;

    $gy = 1600 + 400 * (int)($g_day_no/146097);
    $g_day_no %= 146097;

    $leap = true;
    if ($g_day_no >= 36525) {
        $g_day_no--;
        $gy += 100*(int)($g_day_no/36524);
        $g_day_no %= 36524;

        if ($g_day_no >= 365) $g_day_no++;
        else $leap = false;
    }

    $gy += 4*(int)($g_day_no/1461);
    $g_day_no %= 1461;

    if ($g_day_no >= 366) {
        $leap = false;

        $g_day_no--;
        $gy += (int)($g_day_no/365);
        $g_day_no = $g_day_no % 365;
    }

    $gd = $g_day_no + 1;

    $sal_a = [0,31,($leap?29:28),31,30,31,30,31,31,30,31,30,31];
    for ($gm = 0; $gm < 13 && $gd > $sal_a[$gm]; $gm++)
        $gd -= $sal_a[$gm];

    return [$gy, $gm, $gd];
}

