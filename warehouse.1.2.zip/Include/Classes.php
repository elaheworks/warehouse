<?php

use CL\Logs;
$Logs = new Logs();

use CL\Users;
$Users = new Users();

use CL\Sessions;
$Sessions = new Sessions();

use CL\Logins;
$Logins = new Logins();

use CL\Items;
$Items = new Items();

use CL\MasterItems;
$MasterItems = new MasterItems();

use CL\Categories;
$Categories = new Categories();

use CL\Suppliers;
$Suppliers = new Suppliers();

use CL\Customers;
$Customers = new Customers();

use CL\Units;
$Units = new Units();

use CL\Inventory;
$Inventory = new Inventory();

use CL\Purchases;
$Purchases = new Purchases();

use CL\Invoices;
$Invoices = new Invoices();

use CL\InvoiceItems;
$InvoiceItems = new InvoiceItems();

use CL\TransferRequests;
$Requests = new TransferRequests();

use CL\Transactions;
$Transactions = new Transactions();

use CL\Accounts;
$Accounts = new Accounts();


?>
