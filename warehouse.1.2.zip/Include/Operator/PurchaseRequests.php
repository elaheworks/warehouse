<?php


// گرفتن لیست تأمین‌کنندگان
$suppliersList = $Suppliers->Select("*", [], "name ASC");
if ($suppliersList == -1) $suppliersList = [];

// گرفتن لیست کالاها با جزئیات واحد و تأمین‌کننده
$invoicesList = $Invoices->SelectJoin(
    ["invoices.*", "suppliers.name AS supplier_name"],
    [
        ["invoices"],
        ["suppliers", "invoices.supplier_id = suppliers.id", "LEFT"]
    ],
    [], // اگر نیاز به شرط داشتید اضافه کنید
    "invoices.id DESC"
);
if ($invoicesList == -1) $invoicesList = [];

if (isset($_POST['createInvoice'])) {
    $invoice_id = $Invoices->createInvoice($_POST['supplier_id'], $_POST['invoice_number'], $_POST['note']);
    // Redirect به صفحه مدیریت آیتم‌ها
}

if (isset($_POST['addItem'])) {
    $Purchases->addItemToInvoice($_POST['invoice_id'], $_POST['item_id'], $_POST['quantity'], $_POST['unit_price'], $_POST['unit_id'], $_POST['expiration_date'], $_POST['note']);
    $Invoices->updateTotalPrice($_POST['invoice_id'], $_POST['quantity'] * $_POST['unit_price']);
}

if (isset($_POST['approveInvoice'])) {
    $Invoices->approveInvoice($_POST['invoice_id'], $_SESSION['UserId']);
    $Purchases->updateInventoryOnInvoiceApproval($_POST['invoice_id'], $_POST['supplier_id']);
}


?>
