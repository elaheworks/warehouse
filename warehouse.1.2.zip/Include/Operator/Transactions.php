<?php

// ثبت تراکنش
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['transactionForm'])) {
    $formType = $_POST['transactionForm'];

    if ($formType === 'addTransaction') {
        $data = [
            'payment_method' => $_POST['payment_method'],
            'account_id' => $_POST['account'],
            'tracking_code' => $_POST['tracking_code'],
            'rec_date' => $_POST['rec_date'],
            'reg_id' => $_SESSION['UserKaIdPNL'],
            'rec_id' => $_POST['rec_id'],
            'status' => 1,
        ];
        $Transactions->addTransaction($data);
    }

    if ($formType === 'deleteTransaction' && isset($_POST['transactionid'])) {
        $Transactions->deleteTransaction($_POST['transactionid']);
    }
}

$transactionsList = $Transactions->getAll();
$avtiveUsers  = $Users->Select('*', ['status' => 0]);
$avtiveAccs  = $Accounts->Select('*', ['status' => 1]);
