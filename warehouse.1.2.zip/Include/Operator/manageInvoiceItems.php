<?php

if (!isset($_GET['Item']) || !is_numeric($_GET['Item'])) {
    $_SESSION['alert'] = Alert('error', 'آیتم نامعتبر است.');
    header("Location: ?Page=ShowInvoices");
    exit;
}

$item_id = (int)$_GET['Item'];

// گرفتن اطلاعات آیتم فاکتور
$itemInfo = $InvoiceItems->SelectJoin(
    [
        "invoice_items.*",
        "items.product AS item_name",
        "units.name AS unit_name",
        "invoices.invoice_number",
        "invoices.supplier_id",
        "suppliers.name AS supplier_name"
    ],
    [
        ["invoice_items"],
        ["items", "invoice_items.item_id = items.id"],
        ["units", "invoice_items.unit_id = units.id"],
        ["invoices", "invoice_items.invoice_id = invoices.id"],
        ["suppliers", "invoices.supplier_id = suppliers.id"]
    ],
    ["invoice_items.id" => $item_id]
);

if ($itemInfo == -1) {
    $_SESSION['alert'] = Alert('error', 'آیتم یافت نشد.');
    header("Location: ?Page=ShowInvoices");
    exit;
}

$itemInfo = $itemInfo[0];

$invoiceInfo = $Invoices->Info($itemInfo['invoice_id']);
$unitsList = $Units->Select("id, name", ['status' => 1]);

// بروزرسانی آیتم
if (isset($_POST['updateItem'])) {
    $quantity = $_POST['quantity'];
    $unit_price = $_POST['unit_price'];
    $price_for_quantity = $_POST['price_for_quantity'] ?: null;

    $expiration_date = $_POST['expiration_date'] ?? null;

    $conversion_buy_qty = $_POST['conversion_buy_qty'] ?: null;
    $conversion_store_qty = $_POST['conversion_store_qty'] ?: null;
    $unit_id = $_POST['unit_id'] ?: $itemInfo['unit_id'];

    $discount_type = $_POST['discount_type'] ?? 'amount';
    $discount_value = $_POST['discount_value'] ?: null;
    $tax_type = $_POST['tax_type'] ?? 'amount';
    $tax_value = $_POST['tax_value'] ?: null;
    $is_gift = isset($_POST['is_gift']) ? 1 : 0;
    $note = $_POST['note'] ?? null;

    $updateData = [
        "quantity" => $quantity,
        "unit_price" => $unit_price,
        "price_for_quantity" => $price_for_quantity,
        "expiration_date" => $expiration_date,
        "conversion_buy_qty" => $conversion_buy_qty,
        "conversion_store_qty" => $conversion_store_qty,
        "unit_id" => $unit_id,
        "discount_type" => $discount_type,
        "discount_value" => $discount_value,
        "tax_type" => $tax_type,
        "tax_value" => $tax_value,
        "is_gift" => $is_gift,
        "note" => $note
    ];

    $update = $InvoiceItems->Update($updateData, ["id" => $item_id]);

    if ($update != -1) {
        $_SESSION['alert'] = Alert('success', 'آیتم با موفقیت بروزرسانی شد.');
        header("Location: ?Page=editInvoiceItem&Item={$item_id}");
        exit;
    } else {
        $_SESSION['alert'] = Alert('error', 'خطا در بروزرسانی یا بدون تغییر.');
        header("Location: ?Page=editInvoiceItem&Item={$item_id}");
        exit;
    }
}

