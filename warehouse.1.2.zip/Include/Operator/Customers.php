<?php

// Assuming $Customers is a database model with Select, Insert, Update, Delete methods
$AllCustomers = $Customers->Select("*", [], "id DESC");


// Handle case when no customers are found
if ($AllCustomers == -1) {
    $AllCustomers = [];
}

// Pagination settings
$itemsPerPage = 10;
$P = isset($_GET['P']) && is_numeric($_GET['P']) && $_GET['P'] > 0 ? (int)$_GET['P'] : 1;
$offset = ($P - 1) * $itemsPerPage;
$totalItems = count($AllCustomers);
$totalPages = ceil($totalItems / $itemsPerPage);

// Slice the array for the current page
$paginatedCustomers = array_slice($AllCustomers, $offset, $itemsPerPage);

// Fetch single customer if ID is provided
$Customer = null;
if (isset($_GET['id']) && is_numeric($_GET['id']) && $_GET['id'] > 0) {
    $Customer = $Customers->Select("*", ["id" => (int)$_GET['id']]);
    if ($Customer == -1) {
        $_SESSION['alert'] = Alert("error", "مشتری یافت نشد.");
        $Customer = null;
    }
}

// Handle form submissions
if (isset($_POST['customerForm']) && !empty($_POST['customerForm'])) {
    // Define required fields
    $requiredFields = ['name', 'phone'];
    $isValid = true;

    // Check for missing or empty required fields
    foreach ($requiredFields as $field) {
        if (!isset($_POST[$field]) || empty(trim($_POST[$field]))) {
            $isValid = false;
            $_SESSION['alert'] = Alert("error", "فیلدهای نام و شماره تلفن باید پر شوند.");
            break;
        }
    }

    if ($isValid) {
        // Sanitize and prepare data
        $data = [
            "name" => htmlspecialchars(trim($_POST['name'])),
            "phone" => htmlspecialchars(trim($_POST['phone'])),
            "address" => !empty(trim($_POST['address'])) ? htmlspecialchars(trim($_POST['address'])) : null,
            "telegram_id" => !empty(trim($_POST['telegram_id'])) ? htmlspecialchars(trim($_POST['telegram_id'])) : null,
            "status" => isset($_POST['status']) ? (int)$_POST['status'] : 0
            // reg_date is managed by the database
        ];

        if ($_POST['customerForm'] == "addCustomer") {
            // Check for duplicate phone number
            if ($Customers->Select("*", ["phone" => $data['phone']]) != -1) {
                $_SESSION['alert'] = Alert("error", "مشتری با این شماره تلفن قبلا ثبت شده است.");
            } else {
                $res = $Customers->Insert($data);
                if ($res != -1) {
                    $_SESSION['alert'] = Alert("success", "مشتری با موفقیت اضافه شد.");
                } else {
                    $_SESSION['alert'] = Alert("error", "خطا در افزودن مشتری.");
                }
            }
        } elseif ($_POST['customerForm'] == "editCustomer" && isset($_GET['id']) && is_numeric($_GET['id'])) {
            $res = $Customers->Update($data, ["id" => (int)$_GET['id']]);
            if ($res != -1) {
                $_SESSION['alert'] = Alert("success", "مشتری با موفقیت ویرایش شد.");
            } else {
                $_SESSION['alert'] = Alert("error", "خطا در ویرایش مشتری.");
            }
        } elseif ($_POST['customerForm'] == "deleteCustomer" && isset($_POST['customerid']) && is_numeric($_POST['customerid'])) {
            $res = $Customers->Delete(["id" => (int)$_POST['customerid']]);
            if ($res != -1) {
                $_SESSION['alert'] = Alert("success", "مشتری با موفقیت حذف شد.");
            } else {
                $_SESSION['alert'] = Alert("error", "خطا در حذف مشتری.");
            }
        }
    }

    // Redirect to avoid form resubmission
    header("Location: ?Page=showCustomers&P=$P");
    exit;
}


?>