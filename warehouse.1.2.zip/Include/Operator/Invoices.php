<?php

// گرفتن لیست تأمین‌کنندگان
$suppliersList = $Suppliers->Select("*", [], "name ASC");
if ($suppliersList == -1) $suppliersList = [];

// گرفتن لیست فاکتورها با نام تأمین‌کننده
$invoicesList = $Invoices->SelectJoin(
    ["invoices.*", "suppliers.name AS supplier_name"],
    [
        ["invoices"],
        ["suppliers", "invoices.supplier_id = suppliers.id", "LEFT"]
    ],
    [], // اگر نیاز به شرط دارید اضافه کنید
    "invoices.id DESC"
);
if ($invoicesList == -1) {
    $invoicesList = [];
} else {
    foreach ($invoicesList as &$invoice) {
        // محاسبه مجموع قیمت فاکتور بر اساس آیتم‌ها
        $invoiceItems = $InvoiceItems->getInvoiceItems($invoice['id']);
        if ($invoiceItems !== -1) {
            $total = 0;

            foreach ($invoiceItems as $item) {
                // محاسبه اولیه قیمت آیتم
                if (!empty($item['price_for_quantity']) && $item['quantity'] > 0) {
                    $item_total = ($item['unit_price'] / $item['price_for_quantity']) * $item['quantity'];
                } else {
                    $item_total = $item['quantity'] * $item['unit_price'];
                }

                // تخفیف آیتم
                if ($item['discount_type'] === 'percent') {
                    $item_total -= ($item_total * $item['discount_value'] / 100);
                } elseif ($item['discount_type'] === 'amount') {
                    $item_total -= $item['discount_value'];
                }

                // مالیات آیتم
                if ($item['tax_type'] === 'percent') {
                    $item_total += ($item_total * $item['tax_value'] / 100);
                } elseif ($item['tax_type'] === 'amount') {
                    $item_total += $item['tax_value'];
                }

                // اگر آیتم هدیه باشد، قیمت آیتم صفر می‌شود
                if ($item['is_gift']) {
                    $item_total = 0;
                }

                $total += max($item_total, 0);
            }

            // تخفیف فاکتور
            if ($invoice['discount_type'] === 'percent') {
                $total -= ($total * $invoice['discount_value'] / 100);
            } elseif ($invoice['discount_type'] === 'amount') {
                $total -= $invoice['discount_value'];
            }

            // مالیات فاکتور
            if ($invoice['tax_type'] === 'percent') {
                $total += ($total * $invoice['tax_value'] / 100);
            } elseif ($invoice['tax_type'] === 'amount') {
                $total += $invoice['tax_value'];
            }

            // افزودن هزینه حمل
            $total += $invoice['shipping_cost'];

            // ذخیره مجموع نهایی با تضمین عدم منفی شدن
            $invoice['total_price'] = max($total, 0);
        } else {
            $invoice['total_price'] = 0; // در صورت خطا
        }
    }
}

// گرفتن لیست کالاها برای انتخاب در مدال
$itemsList = $Items->SelectJoin(
    ["items.*", "units.name AS unit_name", "units.id AS unit_id", "categories.name AS category_name"],
    [
        ["items"],
        ["units", "items.unit_id = units.id", "LEFT"],
        ["categories", "items.category_id = categories.id", "LEFT"]
    ],
    [],
    "items.product ASC"
);
if ($itemsList == -1) $itemsList = [];

// ✅ ایجاد فاکتور جدید
if (isset($_POST['createInvoice'])) {

    $note = trim($_POST['note']);
    $date = trim($_POST['date']);
    $invoiceData = [
        'supplier_id' => intval($_POST['supplier_id']),
        'invoice_number' => trim($_POST['invoice_number']),
        'note' => trim($_POST['note']),
        'date' => trim($_POST['date']),
        'discount_type' => $_POST['discount_type'] ?? 'amount',
        'discount_value' => floatval($_POST['discount_value'] ?? 0),
        'tax_type' => $_POST['tax_type'] ?? 'amount',
        'tax_value' => floatval($_POST['tax_value'] ?? 0),
        'shipping_cost' => floatval($_POST['shipping_cost'] ?? 0),
        'gift' => trim($_POST['gift']) ?: null
    ];
    // بررسی تکراری نبودن شماره فاکتور
    $invoice_number = trim($_POST['invoice_number']);
    $exists = $Invoices->Select("id", ["invoice_number" => $invoice_number]);
    if ($exists !== -1) {
        $_SESSION['error'] = "شماره فاکتور تکراری است. لطفاً شماره دیگری وارد کنید.";
        header("Location: ?Page=showInvoices");
        exit;
    }


    // ایجاد فاکتور
    $invoice_id = $Invoices->createInvoice($invoiceData);

    if ($invoice_id != -1) {
        $_SESSION['success'] = "فاکتور با موفقیت ایجاد شد.";
        header("Location: ?Page=showInvoiceItems&invoice_id={$invoice_id}");
        exit;
    } else {
        $_SESSION['error'] = "خطا در ایجاد فاکتور.";
    }
}


// ✅ افزودن آیتم به فاکتور
if (isset($_POST['addItem'])) {
    $invoice_id = intval($_POST['invoice_id']);
    $item_id = intval($_POST['item_id']);
    $quantity = floatval($_POST['quantity']);
    $unit_price = floatval($_POST['unit_price']);
    $unit_id = intval($_POST['unit_id']);
    $expiration_date = trim($_POST['expiration_date']);
    $note = trim($_POST['note']);

    $result = $Purchases->addItemToInvoice($invoice_id, $item_id, $quantity, $unit_price, $unit_id, $expiration_date, $note);

    if ($result != -1) {
        $Invoices->updateTotalPrice($invoice_id, $quantity * $unit_price);
        $_SESSION['success'] = "آیتم با موفقیت به فاکتور اضافه شد.";
    } else {
        $_SESSION['error'] = "خطا در افزودن آیتم به فاکتور.";
    }

    header("Location: ?Page=showInvoiceItems&invoice_id={$invoice_id}");
    exit;
}

// ✅ تأیید فاکتور
if (isset($_POST['approveInvoice'])) {
    $invoice_id = intval($_POST['invoice_id']);
    $invoice_info = $Invoices->Info($invoice_id);
    if (!$invoice_info) {
        $_SESSION['error'] = "فاکتور یافت نشد.";
        header("Location: ?Page=showInvoices");
        exit;
    }

    $supplier_id = $invoice_info['supplier_id'];
    $user_id = $_SESSION['UserId'] ?? 0;

    $approved = $Invoices->approveInvoice($invoice_id, $user_id);

    if ($approved != -1) {
        $InvoiceItems = new \CL\InvoiceItems();
        $updated = $InvoiceItems->updateInventoryOnInvoiceApproval($invoice_id, $invoice_info['invoice_number'], $supplier_id);

        if ($updated) {
            $_SESSION['success'] = "فاکتور با موفقیت تأیید و کالاها به انبار اضافه شدند.";
        } else {
            $_SESSION['error'] = "خطا در ثبت کالاها در موجودی انبار.";
        }
    } else {
        $_SESSION['error'] = "خطا در تأیید فاکتور.";
    }

    header("Location: ?Page=showInvoices");
    exit;
}

// ✅ حذف آیتم از فاکتور
if (isset($_POST['deleteInvoiceItem'])) {
    $item_id = intval($_POST['item_id']);
    $invoice_id = intval($_POST['invoice_id']);

    $result = $Purchases->deleteItemFromInvoice($item_id);

    if ($result != -1) {
        $_SESSION['success'] = "آیتم از فاکتور حذف شد.";
    } else {
        $_SESSION['error'] = "خطا در حذف آیتم از فاکتور.";
    }

    header("Location: ?Page=showInvoiceItems&invoice_id={$invoice_id}");
    exit;
}

// ✅ حذف فاکتور
if (isset($_POST['deleteInvoice'])) {
    $invoice_id = intval($_POST['invoice_id']);

    $result = $Invoices->deleteInvoice($invoice_id);

    if ($result != -1) {
        $_SESSION['success'] = "فاکتور حذف شد.";
    } else {
        $_SESSION['error'] = "خطا در حذف فاکتور.";
    }

    header("Location: ?Page=showInvoices");
    exit;
}
