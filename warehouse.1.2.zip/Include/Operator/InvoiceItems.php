<?php
if (!isset($_GET['invoice_id']) || !is_numeric($_GET['invoice_id'])) {
    $_SESSION['alert'] = Alert('error', 'شناسه فاکتور مشخص نشده است.');
    header("Location: ?Page=showInvoices");
    exit;
}

$invoice_id = (int) $_GET['invoice_id'];

// گرفتن اطلاعات فاکتور با تامین‌کننده
$invoiceInfo = $Invoices->SelectJoin(
    ["invoices.*", "suppliers.name AS supplier_name"],
    [["invoices"], ["suppliers", "invoices.supplier_id = suppliers.id", "LEFT"]],
    ['invoices.id' => $invoice_id]
);


if ($invoiceInfo === -1 || empty($invoiceInfo)) {
    $_SESSION['alert'] = Alert('error', 'فاکتور یافت نشد.');
    header("Location: ?Page=showInvoices");
    exit;
}
$invoiceInfo = $invoiceInfo[0];

// گرفتن لیست واحدها
$unitsList = $Units->Select("*", [], "id ASC");
if ($unitsList == -1) $unitsList = [];

// گرفتن لیست کالاها برای انتخاب در مدال
$itemsList = $Items->SelectJoin(
    ["items.*", "units.name AS unit_name", "units.id AS unit_id", "suppliers.name AS supplier_name"],
    [
        ["items"],
        ["units", "items.unit_id = units.id", "LEFT"],
        ["suppliers", "items.supplier_id = suppliers.id", "LEFT"]
    ],
    [],
    "items.product ASC"
);
if ($itemsList == -1) $itemsList = [];

if (isset($_POST['getSuggestedValues']) && isset($_POST['item_id'])) {
    $item_id = (int) $_POST['item_id'];

    // دریافت آخرین خرید از همان تامین‌کننده (اختیاری اگر خواستی محدود کنی)
    $lastPurchase = $InvoiceItems->SelectRow(
        "quantity, unit_price, price_for_quantity, discount_type, discount_value, tax_type, tax_value, note,
        conversion_buy_qty, conversion_store_qty, unit_id",
        "item_id = ?",
        [$item_id],
        "ORDER BY id DESC LIMIT 1"
    );

    if ($lastPurchase) {
        header('Content-Type: application/json; charset=utf-8');

        echo json_encode([
            'success' => true,
            'data' => $lastPurchase,
            'message' => "مقادیر پیشنهادی بارگذاری شد."
        ]);
        exit;
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'هیچ سابقه‌ای برای این کالا از این تأمین‌کننده یافت نشد.'
        ]);
        exit;
    }
}




// افزودن آیتم
if (isset($_POST['addItem'])) {
    $requiredFields = ['item_id', 'quantity', 'unit_price', 'expiration_date', 'unit_id'];
    $valid = true;
    foreach ($requiredFields as $field) {
        if (empty($_POST[$field])) {
            $valid = false;
            break;
        }
    }

    if ($valid) {
        $data = [
            "invoice_id" => $invoice_id,
            "item_id" => $_POST['item_id'],
            "quantity" => $_POST['quantity'],
            "unit_price" => $_POST['unit_price'],
            "expiration_date" => $_POST['expiration_date'],
            "unit_id" => $_POST['unit_id'],
            "store_unit_id" => $_POST['store_unit_id'],
            "price_for_quantity" => $_POST['price_for_quantity'] ?? 0,
            "note" => $_POST['note'] ?? null,
            "conversion_buy_qty" => $_POST['conversion_buy_qty'] ?? null,
            "conversion_store_qty" => $_POST['conversion_store_qty'] ?? null,
            "discount_type" => $_POST['discount_type'] ?? 'amount',
            "discount_value" => $_POST['discount_value'] ?? 0,
            "tax_type" => $_POST['tax_type'] ?? 'amount',
            "tax_value" => $_POST['tax_value'] ?? 0,
            "is_gift" => isset($_POST['is_gift']) ? 1 : 0
        ];
        $res = $InvoiceItems->Insert($data);

        $_SESSION['alert'] = $res != -1
            ? Alert('success', 'آیتم با موفقیت به فاکتور اضافه شد.')
            : Alert('error', 'خطا در افزودن آیتم.');
    } else {
        $_SESSION['alert'] = Alert('error', 'لطفاً تمام فیلدهای الزامی را پر کنید.');
    }

    header("Location: ?Page=showInvoiceItems&invoice_id={$invoice_id}");
    exit;
}

// گرفتن آیتم‌های فاکتور با join واحد ذخیره در انبار
$invoiceItems = $InvoiceItems->SelectJoin(
    [
        "invoice_items.*",
        "items.product AS item_name",
        "units.name AS unit_name",
        "store_units.name AS store_unit_name"
    ],
    [
        ["invoice_items"],
        ["items", "invoice_items.item_id = items.id", "LEFT"],
        ["units", "invoice_items.unit_id = units.id", "LEFT"],
        ["units AS store_units", "invoice_items.store_unit_id = store_units.id", "LEFT"]
    ],
    ['invoice_items.invoice_id' => $invoice_id],
    "invoice_items.id ASC"
);
$invoiceItems = $invoiceItems !== -1 ? $invoiceItems : [];

// محاسبه مجموع کل فاکتور با تخفیف، مالیات و اشانتیون
$invoiceTotal = 0;
foreach ($invoiceItems as $item) {
    $total = $item['quantity'] * $item['unit_price'];

    if ($item['price_for_quantity'] > 0 && $item['quantity'] > 0) {
        $total = ($item['unit_price'] / $item['price_for_quantity']) * $item['quantity'];
    }

    if ($item['discount_type'] === 'percent') {
        $total -= ($total * $item['discount_value'] / 100);
    } elseif ($item['discount_type'] === 'amount') {
        $total -= $item['discount_value'];
    }

    if ($item['tax_type'] === 'percent') {
        $total += ($total * $item['tax_value'] / 100);
    } elseif ($item['tax_type'] === 'amount') {
        $total += $item['tax_value'];
    }

    if ($item['is_gift']) {
        $total = 0;
    }

    $invoiceTotal += max($total, 0);
}
?>
