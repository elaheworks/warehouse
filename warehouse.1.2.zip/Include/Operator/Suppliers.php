<?php
$AllSuppliers = $Suppliers->Select("*", [], "id DESC");
if ($AllSuppliers == -1) {
    $AllSuppliers = [];
}

// Pagination
$itemsPerPage = 10;
$P = isset($_GET['P']) && is_numeric($_GET['P']) ? (int)$_GET['P'] : 1;
$offset = ($P - 1) * $itemsPerPage;
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Search filter
$filteredSuppliers = $AllSuppliers;
if ($search !== '') {
    $filteredSuppliers = array_filter($AllSuppliers, function ($supplier) use ($search) {
        return stripos($supplier['name'], $search) !== false;
    });
}

// Pagination calculation
$totalItems = count($filteredSuppliers);
$totalPages = ceil($totalItems / $itemsPerPage);
$paginatedSuppliers = array_slice($filteredSuppliers, $offset, $itemsPerPage);

// Single supplier fetch for edit page
if (isset($_GET['id']) && $_GET['id'] != "") {
    $Supplier = $Suppliers->Select("*", ["id" => $_GET['id']]);
    if ($Supplier != -1 && isset($Supplier[0])) {
        $Supplier = $Supplier[0];
    } else {
        $Supplier = null;
    }
} else {
    $Supplier = null;
}

// Handle form submissions
if (isset($_POST['supplierForm']) && $_POST['supplierForm'] != "") {
    if ($_POST['supplierForm'] == "addSupplier") {
        $name = trim($_POST['name']);
        $visitor_phone = trim($_POST['visitor_phone']);
        $company_phone = trim($_POST['company_phone']);
        $manager_phone = trim($_POST['manager_phone']);
        $address = trim($_POST['address']);
        $description = trim($_POST['description']);
        $account_number = trim($_POST['account_number']);
        $status = isset($_POST['status']) ? $_POST['status'] : 1;

        if ($Suppliers->Select("*", ["name" => $name]) != -1) {
            $_SESSION['alert'] = Alert("error", "تأمین‌کننده با این نام قبلاً ثبت شده است.");
        } else {
            $res = $Suppliers->Insert([
                "name" => $name,
                "visitor_phone" => $visitor_phone,
                "company_phone" => $company_phone,
                "manager_phone" => $manager_phone,
                "address" => $address,
                "description" => $description,
                "account_number" => $account_number,
                "status" => $status
            ]);

            if ($res != -1) {
                $_SESSION['alert'] = Alert("success", "تأمین‌کننده با موفقیت اضافه شد.");
            } else {
                $_SESSION['alert'] = Alert("error", "خطا در افزودن تأمین‌کننده.");
            }
        }

        header("Location: " . $_SESSION['WebsiteUrl'] . "?Page=showSuppliers");
        exit;
    }

    if ($_POST['supplierForm'] == "editSupplier") {
        $id = isset($_POST['id']) ? $_POST['id'] : 0;
        $name = trim($_POST['name']);
        $visitor_phone = trim($_POST['visitor_phone']);
        $company_phone = trim($_POST['company_phone']);
        $manager_phone = trim($_POST['manager_phone']);
        $address = trim($_POST['address']);
        $description = trim($_POST['description']);
        $account_number = trim($_POST['account_number']);
        $status = isset($_POST['status']) ? $_POST['status'] : 1;

        $res = $Suppliers->Update([
            "name" => $name,
            "visitor_phone" => $visitor_phone,
            "company_phone" => $company_phone,
            "manager_phone" => $manager_phone,
            "address" => $address,
            "description" => $description,
            "account_number" => $account_number,
            "status" => $status,
            "last_edit" => date("Y-m-d H:i:s")
        ], ["id" => $id]);

        if ($res != -1) {
            $_SESSION['alert'] = Alert("success", "تأمین‌کننده با موفقیت ویرایش شد.");
        } else {
            $_SESSION['alert'] = Alert("error", "خطا در ویرایش تأمین‌کننده.");
        }

        header("Location: " . $_SESSION['WebsiteUrl'] . "?Page=showSuppliers");
        exit;
    }

    if ($_POST['supplierForm'] == "deleteSupplier") {
        $id = $_POST['supplier_id'];
        $res = $Suppliers->Delete(["id" => $id]);

        if ($res != -1) {
            $_SESSION['alert'] = Alert("success", "تأمین‌کننده با موفقیت حذف شد.");
        } else {
            $_SESSION['alert'] = Alert("error", "خطا در حذف تأمین‌کننده.");
        }

        header("Location: " . $_SESSION['WebsiteUrl'] . "?Page=showSuppliers");
        exit;
    }
}
?>
