<?php

$allUsers  = $Users->Select();
if ($allUsers == -1) {
    $_SESSION['alert'] = Alert('error', "خطا در دریافت کاربران");
    header("location: index.php");
    exit;
}

if(isset($_GET['user']) && $_GET['user'] != '') {
    $userid = $_GET['user'];
    $User = $Users->Select("*", ["id" => $userid]);
    if ($User == -1) {
        $_SESSION['alert'] = Alert('error', "کاربر مورد نظر یافت نشد");
        header("location: index.php?Page=showUsers");
        exit;
    }
    $User = $User[0];
} else {
    $userid = -1;
    $User = [];
}
// Handle form submission for adding, updating, or deleting users
if (isset($_POST['userForm']) && $_POST['userForm'] != '') {
    if ($_POST['userForm'] == 'addUser') {
        // ADD USER
        $image = "https://ik.imagekit.io/shahkardrama/Shahkar/Profiles/10_tCUqWjYIx.jpg?updatedAt=1741309985659";
        if (isset($_FILES['picture']) && $_FILES['picture']['error'] === UPLOAD_ERR_OK) {
            $image = uploadImage($_FILES['picture'], "Profiles");
        }
        $name = $_POST['name'];
        $username = $_POST['username'];
        $password = md5($_POST['password']);
        $email = $_POST['email'];
        $telegram = $_POST['telegram'];
        $phone = $_POST['phone'];
        $role = $_POST['role'];
        $status = $_POST['status'];

        if ($image != -1) {
            $values = [
                'name' => $name,
                'username' => $username,
                'password' => $password,
                'email' => $email,
                'tel_id' => $telegram,
                'phone' => $phone,
                'role' => $role,
                'status' => $status,
                'pic' => $image
            ];
        } else {
            $values = [
                'name' => $name,
                'username' => $username,
                'password' => $password,
                'email' => $email,
                'phone' => $phone,
                'role' => $role,
                'status' => $status
            ];
        }
        if ($Users->Insert($values)) {
            $_SESSION['alert'] = Alert('success', "کاربر جدید اضافه شد");
        } else {
            $_SESSION['alert'] = Alert('error', "خطا در افزودن کاربر");
        }
    } elseif ($_POST['userForm'] == 'deleteUser') {
        // DELETE USER
        $userid = $_POST['userid'];
        if ($Users->Delete(['id' => $userid])) {
            $_SESSION['alert'] = Alert('success', "کاربر حذف شد");
        } else {
            $_SESSION['alert'] = Alert('error', "خطا در حذف کاربر");
        }
    } elseif ($_POST['userForm'] == 'updateUser') {
        // UPDATE USER
        $userid = $_POST['userid'];
        $image = -1;
        if (isset($_FILES['picture']) && $_FILES['picture']['error'] === UPLOAD_ERR_OK) {
            $image = uploadImage($_FILES['picture'], "Profiles");
        }
        $name = $_POST['name'];
        $username = $_POST['username'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $role = $_POST['role'];
        $status = $_POST['status'];

        if ($image != -1) {
            $values = [
                'name' => $name,
                'username' => $username,
                'email' => $email,
                'phone' => $phone,
                'role' => $role,
                'status' => $status,
                'pic' => $image
            ];
        } else {
            $values = [
                'name' => $name,
                'username' => $username,
                'email' => $email,
                'phone' => $phone,
                'role' => $role,
                'status' => $status
            ];
        }
        if ($Users->Update($values, ['id' => $userid])) {
            $_SESSION['alert'] = Alert('success', "کاربر ویرایش شد");
        } else {
            $_SESSION['alert'] = Alert('error', "خطا در ویرایش کاربر");
        }
    }
    header("location: index.php?Page=showUsers");
    exit;
}
