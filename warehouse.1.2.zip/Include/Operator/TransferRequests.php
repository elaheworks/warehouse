<?php

// دریافت همه درخواست‌ها
$AllRequests = $Requests->getDetailedRequests();
if ($AllRequests === -1 || $AllRequests === false) {
    $AllRequests = [];
}

// دریافت لیست کالاها با نام و واحد
$itemsList = $Items->Raw("
    SELECT 
        items.id, 
        items.product, 
        units.name AS unit_name,
        items.unit_id
    FROM items
    INNER JOIN units ON items.unit_id = units.id
    WHERE items.status = 1
    ORDER BY items.product ASC
");
if ($itemsList == -1) $itemsList = [];

// صفحه‌بندی
$itemsPerPage = 10;
$P = isset($_GET['P']) && is_numeric($_GET['P']) && $_GET['P'] > 0 ? (int)$_GET['P'] : 1;
$offset = ($P - 1) * $itemsPerPage;
$totalItems = count($AllRequests);
$totalPages = ceil($totalItems / $itemsPerPage);
$paginatedRequests = array_slice($AllRequests, $offset, $itemsPerPage);

// گرفتن اطلاعات یک درخواست خاص (نمایش یا ویرایش)
$Request = null;
if (isset($_GET['id']) && is_numeric($_GET['id']) && $_GET['id'] > 0) {
    $Request = $Requests->Info((int)$_GET['id']);
    if ($Request === null) {
        $_SESSION['alert'] = Alert("error", "درخواست مورد نظر یافت نشد.");
    }
}

// مدیریت فرم‌ها
if (isset($_POST['transferForm']) && !empty($_POST['transferForm'])) {

    // افزودن درخواست جدید
    if ($_POST['transferForm'] == "addRequest") {
        $itemId = (int)$_POST['item_id'];
        $itemData = $Items->Info($itemId);

        if (!$itemData) {
            $_SESSION['alert'] = Alert("error", "کالای انتخاب‌شده نامعتبر است.");
            header("Location: ?Page=showRequests");
            exit;
        }

        $data = [
            'from_location' => trim($_POST['from_location']),
            'to_location' => trim($_POST['to_location']),
            'item_id' => $itemId,
            'quantity' => (int)$_POST['quantity'],
            'requested_by' => (int)$_SESSION['UserKaIdPNL'],
            'requested_at' => date('Y-m-d H:i:s'),
            'status' => 0,
            'note' => $_POST['note'] ?? '',
            'status_log' => json_encode([[
                'status' => 0,
                'user_id' => (int)$_SESSION['UserKaIdPNL'],
                'time' => date('Y-m-d H:i:s')
            ]], JSON_UNESCAPED_UNICODE),
        ];

        $res = $Requests->Insert($data);
        $_SESSION['alert'] = $res != -1 
            ? Alert("success", "درخواست با موفقیت ثبت شد.")
            : Alert("error", "خطا در ثبت درخواست.");
        header("Location: ?Page=showRequests");
        exit;
    }

    // تأیید یا رد درخواست
    if ($_POST['transferForm'] === 'approveRequest') {
    $requestId = (int)$_POST['requestid'];
    $newStatus = 1; // تأیید شده

    // گرفتن اطلاعات درخواست
    $requestInfo = $Requests->Info($requestId);
    if ($requestInfo === null) {
        $_SESSION['alert'] = Alert("error", "درخواست مورد نظر یافت نشد.");
        header("Location: ?Page=showRequests&P=$P");
        exit;
    }

    // کم کردن موجودی از انبار
    $itemId = $requestInfo['item_id'];
    $transferQuantity = (int)$requestInfo['quantity'];

    // موجودی فعلی آیتم
    $inventoryItem = $Inventory->Select("*", ["item_id" => $itemId]);
    if ($inventoryItem == -1 || count($inventoryItem) === 0) {
        $_SESSION['alert'] = Alert("error", "موجودی آیتم در انبار یافت نشد.");
        header("Location: ?Page=showRequests&P=$P");
        exit;
    }

    $currentQuantity = (int)$inventoryItem[0]['quantity'];
    $newQuantity = $currentQuantity - $transferQuantity;

    if ($newQuantity < 0) {
        $_SESSION['alert'] = Alert("error", "موجودی انبار کافی نیست.");
        header("Location: ?Page=showRequests&P=$P");
        exit;
    }

    // بروزرسانی موجودی
    $updateRes = $Inventory->Update(['quantity' => $newQuantity], ['id' => $inventoryItem[0]['id']]);

    if ($updateRes == -1) {
        $_SESSION['alert'] = Alert("error", "خطا در بروزرسانی موجودی انبار.");
        header("Location: ?Page=showRequests&P=$P");
        exit;
    }

    // لاگ‌گذاری و ثبت تأیید درخواست
    $res = $Requests->appendStatusLog($requestId, $newStatus, $_SESSION['UserKaIdPNL']);

    if ($res != -1) {
        $Requests->Update([
            'approved_by' => (int)$_SESSION['UserKaIdPNL'],
            'approved_at' => date('Y-m-d H:i:s'),
            'status' => $newStatus
        ], ['id' => $requestId]);

        $_SESSION['alert'] = Alert("success", "درخواست با موفقیت تأیید و موجودی انبار بروزرسانی شد.");
    } else {
        $_SESSION['alert'] = Alert("error", "خطا در تغییر وضعیت درخواست.");
    }

    header("Location: ?Page=showRequests&P=$P");
    exit;
}


    // حذف درخواست
    if ($_POST['transferForm'] === 'deleteRequest' && isset($_POST['requestid'])) {
        $res = $Requests->Delete(['id' => (int)$_POST['requestid']]);
        $_SESSION['alert'] = $res != -1 
            ? Alert("success", "درخواست با موفقیت حذف شد.") 
            : Alert("error", "خطا در حذف درخواست.");
        header("Location: ?Page=showRequests&P=$P");
        exit;
    }
}
