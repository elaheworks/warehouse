<?php


$logs = $Logs->Select("*", [], "ORDER BY id DESC LIMIT 100");
if ($logs === -1) {
    $logs = [];
}
