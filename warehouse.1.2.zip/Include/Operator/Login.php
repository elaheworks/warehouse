<?php
if (!isset($_SESSION['UserKaIdPNL']) || $_SESSION['UserKaIdPNL'] == "") {

    if (isset($_COOKIE['UserKaIdPNL_cookie'])) {
        $cookieToken = $_COOKIE['UserKaIdPNL_cookie'];

        $currentDate = date('Y-m-d H:i:s');
        $maxFutureDate = date('Y-m-d H:i:s', strtotime('+30 days'));

        $userSessions = $Sessions->Select(
            "*",
            ["token" => $cookieToken, "expires_at BETWEEN" => "$currentDate AND $maxFutureDate"]
        );

        if ($userSessions != -1) {
            $userid = $userSessions[0]['user_id'];
            $User = $Users->Select("*", ["id" => $userid])[0];

            $_SESSION['UserKaIdPNL'] = $User['id'];
            $_SESSION['UserInfoPNL']['name'] = $User['name'];
            $_SESSION['UserInfoPNL']['username'] = $User['username'];
            $_SESSION['UserInfoPNL']['phone'] = $User['phone'];
            $_SESSION['UserInfoPNL']['role'] = $User['role'];
            $_SESSION['UserInfoPNL']['pic'] = $User['pic'];
            $_SESSION['UserInfoPNL']['reg'] = $User['reg_date'];

            // Extend session expiration
            $newExpiry = date('Y-m-d H:i:s', strtotime('+30 days'));
            $Sessions->Update(['expires_at' => $newExpiry], ['token' => $cookieToken]);
        }

        header("Location: index.php");
        exit();
    }

    // LOGIN FORM
    elseif (isset($_POST['LoginForm']) && $_POST['LoginForm'] === "Login") {
        if (!empty($_POST['username']) && !empty($_POST['password'])) {
            $username = $_POST['username'];
            $pass = $_POST['password'];

            $User = $Users->Login($username, $pass);

            if ($User != -1) {
                $_SESSION['UserKaIdPNL'] = $User['id'];
                $_SESSION['UserInfoPNL']['name'] = $User['name'];
                $_SESSION['UserInfoPNL']['username'] = $User['username'];
                $_SESSION['UserInfoPNL']['phone'] = $User['phone'];
                $_SESSION['UserInfoPNL']['role'] = $User['role'];
                $_SESSION['UserInfoPNL']['pic'] = $User['pic'];
                $_SESSION['UserInfoPNL']['reg'] = $User['reg_date'];


                if (isset($_POST['remember_me'])) {
                    $token = $Sessions->generateSecureToken();
                    $expiry = date('Y-m-d H:i:s', strtotime('+30 days'));

                    $Sessions->Insert([
                        'user_id' => $User['id'],
                        'token' => $token,
                        'expires_at' => $expiry
                    ]);

                    setcookie('UserKaIdPNL_cookie', $token, time() + (30 * 24 * 60 * 60), '/', '', true, true);
                } else {
                    if (isset($_COOKIE['UserKaIdPNL_cookie'])) {
                        setcookie('UserKaIdPNL_cookie', '', time() - 3600, '/', '', true, true);
                    }
                }

                $_SESSION['alert'] = Alert('success', 'خوش اومدی!');
            } else {
                $Logins->recordFailedLoginAttempt($username);
                $_SESSION['alert'] = Alert('error', 'نام کاربری یا رمز عبور رو اشتباه وارد کردی');
            }
        }

        header("Location: index.php");
        exit();
    }
}
