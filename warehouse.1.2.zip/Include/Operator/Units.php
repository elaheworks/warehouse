<?php

// دریافت همه واحدها
$allUnits = $Units->Select();
if ($allUnits == -1) {
    $allUnits == [];
}

// دریافت واحد خاص برای ویرایش
$unitId = $_GET['unit'] ?? -1;
$Unit = [];
if ($unitId != -1) {
    $result = $Units->Info($unitId);
    if (!$result) {
        $_SESSION['alert'] = Alert('error', "واحد مورد نظر یافت نشد");
        header("location: index.php?Page=showUnits");
        exit;
    }
    $Unit = $result;
}

// ثبت یا ویرایش یا حذف
if (isset($_POST['unitForm'])) {
    if ($_POST['unitForm'] === 'addUnit') {
        $name = $_POST['name'];
        $desc = $_POST['description'];
        $mode = $_POST['mode'];
        $status = $_POST['status'];

        $inserted = $Units->Insert([
            'name' => $name,
            'description' => $desc,
            'status' => $status
        ]);

        $_SESSION['alert'] = $inserted != -1
            ? Alert('success', "واحد جدید اضافه شد")
            : Alert('error', "خطا در افزودن واحد");

    } elseif ($_POST['unitForm'] === 'editUnit') {
        $id = $_POST['unit'];
        $updated = $Units->Update([
            'name' => $_POST['name'],
            'description' => $_POST['description'],
            'status' => $_POST['status']
        ], ['id' => $id]);

        $_SESSION['alert'] = $updated != -1
            ? Alert('success', "واحد ویرایش شد")
            : Alert('error', "خطا در ویرایش واحد");

    } elseif ($_POST['unitForm'] === 'deleteUnit') {
        $id = $_POST['id'];
        $deleted = $Units->Delete(['id' => $id]);

        $_SESSION['alert'] = $deleted != -1
            ? Alert('success', "واحد حذف شد")
            : Alert('error', "خطا در حذف واحد");
    }

    header("location: index.php?Page=showUnits");
    exit;
}
