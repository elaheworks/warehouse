<?php

$groupedInventory = $Inventory->getGroupedInventory();

if ($groupedInventory === -1) {
    $groupedInventory = [];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['inventoryForm'])) {
        $formType = $_POST['inventoryForm'];

        if ($formType === 'editInventory' && isset($_POST['id']) && is_numeric($_POST['id'])) {
            $id = (int)$_POST['id'];

            $data = [
                'quantity' => isset($_POST['quantity']) ? (int)$_POST['quantity'] : 0,
                'unit_price' => isset($_POST['unit_price']) ? (int)$_POST['unit_price'] : 0,
                'note' => isset($_POST['note']) ? trim($_POST['note']) : '',
                'expiration_date' => isset($_POST['expiration_date']) ? $_POST['expiration_date'] : null,
                // سایر فیلدهای قابل ویرایش را اضافه کن
            ];

            // آپدیت
            $res = $Inventory->Update($data, ['id' => $id]);

            if ($res !== -1) {
                $_SESSION['alert'] = Alert("success", "موجودی با موفقیت ویرایش شد.");
            } else {
                $_SESSION['alert'] = Alert("error", "خطا در ویرایش موجودی.");
            }

            header("Location: ?Page=showInventory");
            exit;
        }

        // برای حذف و افزودن هم همین‌طور می‌تونی بنویسی
    }
}

