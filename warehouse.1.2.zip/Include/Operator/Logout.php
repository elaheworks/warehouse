<?php
if (isset($_GET['Logout']) && $_GET['Logout'] == 1) {
    // Unset session variables
    unset($_SESSION['UserKaIdPNL'], $_SESSION['UserInfoPNL']);

    // Delete the 'UserKaIdPNL_cookie' by setting its expiration time in the past
    if (isset($_COOKIE['UserKaIdPNL_cookie'])) {
        setcookie('UserKaIdPNL_cookie', '', time() - 3600, '/'); // Expire the cookie
        unset($_COOKIE['UserKaIdPNL_cookie']); // Unset the cookie from the $_COOKIE superglobal
    }

    // Destroy the session
    $redirectUrl = $_SESSION['WebsiteUrl'];
    session_destroy();
    session_start();
    $_SESSION['alert'] = $Alert;

    // Redirect to the specified URL or a default location
    header("Location: " . $redirectUrl);
    exit();
}
?>
