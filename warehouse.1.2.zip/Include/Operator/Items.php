<?php

// Assuming $Items is a database model with Select, Insert, Update, Delete methods
$AllItems = $Items->Raw("
    SELECT items.*, 
        suppliers.name AS supplier_name,
        categories.name AS category_name,
        units.name AS unit_name,
        reg_user.name AS reg_name,
        rec_user.name AS rec_name,
        lastlog_user.name AS lastlog_name
    FROM items
    LEFT JOIN suppliers ON items.supplier_id = suppliers.id
    LEFT JOIN categories ON items.category_id = categories.id
    LEFT JOIN units ON items.unit_id = units.id
    LEFT JOIN users AS reg_user ON items.reg_id = reg_user.id
    LEFT JOIN users AS rec_user ON items.rec_id = rec_user.id
    LEFT JOIN users AS lastlog_user ON items.last_log = lastlog_user.id
    WHERE items.status != -1
    ORDER BY items.id DESC
");


// Handle case when no items are found
if ($AllItems == -1) {
    $AllItems = [];
}

// Pagination settings
$itemsPerPage = 10;
$P = isset($_GET['P']) && is_numeric($_GET['P']) && $_GET['P'] > 0 ? (int)$_GET['P'] : 1;
$offset = ($P - 1) * $itemsPerPage;
$totalItems = count($AllItems);
$totalPages = ceil($totalItems / $itemsPerPage);

// Slice the array for the current page
$paginatedItems = array_slice($AllItems, $offset, $itemsPerPage);

// Fetch single item if ID is provided
$Item = null;
if (isset($_GET['item']) && is_numeric($_GET['item']) && $_GET['item'] > 0) {
    $Item = $Items->Select("*", ["id" => (int)$_GET['item']]);
    if ($Item == -1) {
        $_SESSION['alert'] = Alert("error", "کالا یافت نشد.");
        $Item = null;
    }else{
        $Item = $Item['0'];
    }
}

// گرفتن لیست دسته‌بندی‌ها
$categoriesList = $Categories->Select("*", [], "id ASC");
if ($categoriesList == -1) $categoriesList = [];

// گرفتن لیست تأمین‌کننده‌ها
$suppliersList = $Suppliers->Select("*", [], "id ASC");
if ($suppliersList == -1) $suppliersList = [];

// گرفتن لیست واحدها
$unitsList = $Units->Select("*", [], "id ASC");
if ($unitsList == -1) $unitsList = [];

$masterItemsList = $MasterItems -> Select("*", ['status' => 1]);
// Handle form submissions
if (isset($_POST['itemForm']) && !empty($_POST['itemForm'])) {

    if ($_POST['itemForm'] == "addItem") {
        // Check for duplicate product and brand
        // Define all required fields based on DB schema
        $requiredFields = [
            'product',
            'supplier_id',
            'unit_price',
            'quantity',
        ];
        $isValid = true;

        // Check for missing or empty fields
        foreach ($requiredFields as $field) {
            if (!isset($_POST[$field]) || empty(trim($_POST[$field]))) {
                $isValid = false;
                $_SESSION['alert'] = Alert("error", "همه فیلدها باید پر شوند.");
                break;
            }
        }

        if ($isValid) {
            // Sanitize and prepare data
            $data = [
                "product" => htmlspecialchars(trim($_POST['product'])),
                "brand" => htmlspecialchars(trim($_POST['brand'])),
                "unit_price" => (int)$_POST['unit_price'],
                "quantity" => (int)$_POST['quantity'],
                "category_id" => (int)$_POST['category_id'],
                "supplier_id" => (int)$_POST['supplier_id'],
                "par_level" => (int)$_POST['par_level'],
                "unit_id" => (int)$_POST['unit_id'],
                "storage_location" => htmlspecialchars(trim($_POST['storage_location'])),
                "reg_id" => (int)$_SESSION['UserKaIdPNL'],
                "status" => (int)$_POST['status'],
            ];
            if ($Items->Select("*", ["product" => $data['product'], "brand" => $data['brand'], "supplier_id" => $data['supplier_id']]) != -1) {
                $_SESSION['alert'] = Alert("error", "کالا با این نام و برند قبلا ثبت شده است.");
            } else {
                $res = $Items->Insert($data);
                if ($res != -1) {
                    $_SESSION['alert'] = Alert("success", "کالا با موفقیت اضافه شد.");
                } else {
                    $_SESSION['alert'] = Alert("error", "خطا در افزودن کالا.");
                }
            }
        }
    } elseif ($_POST['itemForm'] == "editItem" && isset($_GET['item']) && is_numeric($_GET['item'])) {
        $data = [
                "product" => htmlspecialchars(trim($_POST['product'])),
                "brand" => htmlspecialchars(trim($_POST['brand'])),
                "unit_price" => (int)$_POST['unit_price'],
                "quantity" => (int)$_POST['quantity'],
                "category_id" => (int)$_POST['category_id'],
                "supplier_id" => (int)$_POST['supplier_id'],
                "par_level" => (int)$_POST['par_level'],
                "unit_id" => (int)$_POST['unit_id'],
                "storage_location" => htmlspecialchars(trim($_POST['storage_location'])),
                "reg_id" => (int)$_SESSION['UserKaIdPNL'],
                "status" => (int)$_POST['status'],
            ];
        $data['last_edit'] = date('Y-m-d H:i:s'); // Update last_edit manually
        $res = $Items->Update($data, ["id" => (int)$_GET['item']]);
        if ($res != -1) {
            $_SESSION['alert'] = Alert("success", "کالا با موفقیت ویرایش شد.");
        } else {
            $_SESSION['alert'] = Alert("error", "خطا در ویرایش کالا.");
        }
    } elseif ($_POST['itemForm'] == "deleteItem" && isset($_POST['itemid']) && is_numeric($_POST['itemid'])) {
        $res = $Items->Delete(["id" => (int)$_POST['itemid']]);
        if ($res != -1) {
            $_SESSION['alert'] = Alert("success", "کالا با موفقیت حذف شد.");
        } else {
            $_SESSION['alert'] = Alert("error", "خطا در حذف کالا.");
        }
    }


    // Redirect to avoid form resubmission
    header("Location: ?Page=showItems&P=$P");
    exit;
}
