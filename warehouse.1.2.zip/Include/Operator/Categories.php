<?php 
$AllCategories = $Categories->Select("*", [], "id DESC");
// Pagination settings
if($AllCategories == -1) {
    $AllCategories = [];
}

// Pagination settings
$itemsPerPage = 10;
$P = isset($_GET['P']) && is_numeric($_GET['P']) ? (int)$_GET['P'] : 1;
$offset = ($P - 1) * $itemsPerPage;
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Filter categories based on search
$filteredCategories = $AllCategories;
if ($search) {
    $filteredCategories = array_filter($AllCategories, function($category) use ($search) {
        return stripos($category['name'], $search) !== false;
    });
}


// Calculate pagination
$totalItems = count($filteredCategories);
$totalPages = ceil($totalItems / $itemsPerPage);
$paginatedCategories = array_slice($filteredCategories, $offset, $itemsPerPage);

if (isset($_GET['id']) && $_GET['id'] != "") {
    $Category = $Categories->Select("*", [
        "id" => $_GET['id']
    ]);
    if ($Category != -1){
        $Category = $Category['0'];
    }else{
        $Category = null;
    }
} else {
    $Category = null;
}
if (isset($_POST['categoryForm']) && $_POST['categoryForm'] != "") {
    if ($_POST['categoryForm'] == "addCategory") {
        if ($Categories->Select("*", [
            "name" => $_POST['name']
        ]) != -1) {
            $_SESSION['alert'] = Alert("error", "دسته بندی با این نام قبلا ثبت شده است.");
        } else {
            $res = $Categories->Insert([
                "name" => $_POST['name'],
                "description" => $_POST['description'],
                "status" => $_POST['status']
            ]);
            if ($res != -1) {
                $_SESSION['alert'] = Alert("success", "دسته بندی با موفقیت اضافه شد.");
            } else {
                $_SESSION['alert'] = Alert("error", "خطا در افزودن دسته بندی.");
            }
        }
    } elseif ($_POST['categoryForm'] == "editCategory") {
        $res = $Categories->Update([
            "name" => $_POST['name'],
            "description" => $_POST['description'],
            "status" => $_POST['status']
        ], [
            "id" => $_GET['id']
        ]);
        if ($res != -1) {
            $_SESSION['alert'] = Alert("success", "دسته بندی با موفقیت ویرایش شد.");
        } else {
            $_SESSION['alert'] = Alert("error", "خطا در ویرایش دسته بندی.");
        }
    }
elseif ($_POST['categoryForm'] == "deleteCategory") {
        $res = $Categories->Delete([
            "id" => $_POST['category_id']
        ]);
        if ($res != -1) {
            $_SESSION['alert'] = Alert("success", "دسته بندی با موفقیت حذف شد.");
        } else {
            $_SESSION['alert'] = Alert("error", "خطا در حذف دسته بندی.");
        }
    }
    header("Location: " . $_SESSION['WebsiteUrl'] . "?Page=showCategories");
}
