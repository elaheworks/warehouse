<?php

// دریافت اطلاعات کاربر فعلی از session
$UserID = $_SESSION['UserKaIdPNL'] ?? null;

// دریافت اطلاعات کامل کاربر
$user = $Users->Info($UserID);
if ($user == -1) {
    $_SESSION['alert'] = Alert('error', 'کاربر یافت نشد.');
    header("Location: index.php");
    exit;
}

// بررسی ارسال فرم
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['profileForm']) && $_POST['profileForm'] === 'updateProfile') {
    $name = trim($_POST['name']);
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $password = $_POST['password'] ?? null;

    $updateData = [
        'name' => $name,
        'username' => $username,
        'email' => $email,
        'phone' => $phone,
    ];

    // اگر رمز عبور وارد شده و جدید است
    if (!empty($password)) {
        $updateData['password'] = md5($password);
    }

    // ذخیره تصویر در صورت آپلود
    if (!empty($_FILES['profile_pic']['tmp_name'])) {
        $file = $_FILES['profile_pic'];
        $Res = uploadImage($file, "kaghazi");
        if($Res != -1){
            $updateData['pic'] = $Res;
        }
    }

    // ذخیره در دیتابیس
    $res = $Users->Update( $updateData, ['id' => $UserID]);

    if ($res != -1) {
        $_SESSION['alert'] = Alert('success', 'پروفایل با موفقیت به‌روزرسانی شد. دوباره وارد شوید.');
        header("Location: index.php?Logout=1");
        exit;
    } else {
        $_SESSION['alert'] = Alert('error', 'خطا در به‌روزرسانی اطلاعات.');
        header("Location: index.php?Page=editProfile");
        exit;
    }
}
