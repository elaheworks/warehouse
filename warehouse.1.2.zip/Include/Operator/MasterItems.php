<?php

$categoriesList = $Categories->Select();
$unitsList = $Units->Select();
$masterItemsList = $MasterItems->Select("*", ['status' => 1], "", "id DESC");


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['addMasterItem'])) {
        $data = [
            'product_name' => $_POST['product_name'],
            'category_id' => $_POST['category_id'],
            'default_unit_id' => $_POST['default_unit_id'],
            'brand' => $_POST['brand'] ?? '',
            'par_level' => $_POST['par_level'] ?? 0,
            'min_amount' => $_POST['min_amount'] ?? 0,
            'max_amount' => $_POST['max_amount'] ?? 0,
            'storage_condition' => $_POST['storage_condition'] ?? '',
            'reg_id' => $_SESSION['UserId'] ?? 0,
            'reg_date' => date('Y-m-d H:i:s')
        ];
        $MasterItems->Insert($data);
        $_SESSION['alert'] = Alert('success', '✅ کالای مادر با موفقیت ثبت شد.');
        header("Location: ?Page=showMasterItems");
        exit;
    }
    if (isset($_POST['deleteMasterItem'])) {
        $id = (int) $_POST['deleteMasterItem'];
        $MasterItems->Delete(['id' => $id]);
        $_SESSION['alert'] = Alert('success', '✅ کالای مادر با موفقیت حذف شد.');
        header("Location: ?Page=showMasterItems");
        exit;
    }
}
