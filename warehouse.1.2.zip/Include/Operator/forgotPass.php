<?php
if (isset($_POST['ForgotPasswordForm'])) {
    if ($_POST['ForgotPasswordForm'] == "Reset" && isset($_POST['email'])) {
        $email = $_POST['email'];
        $User = $Users->Select("*", ['email' => $email]);
        if ($User != -1) {
            $User = $User['0'];
            $Users->sendPasswordResetLink($User['id'], $email);
        } else {
            $_SESSION['alert'] = Alert('error', 'همچین ایمیلی نداشتیم!');
        }
    } elseif ($_POST['ForgotPasswordForm'] == "NEW" && isset($_POST['password']) && $_POST['password'] != '') {
        $newPassword = $_POST['password'];
        $confirmPassword = $_POST['confirm_password'];
        $token = $_GET['RESET'];

        // Validate passwords
        if ($newPassword !== $confirmPassword) {
            $_SESSION['alert'] = Alert('error', 'شهر کاغذی! رمزهایی که وارد کردی یکی نیست');
        } else {
            $user = $Users->select("id", ['reset_token' => $token]);
            if ($user == -1) {
                $_SESSION['alert'] = Alert('error', 'اشتباه اومدی');
                header('Location: ' . $_SESSION['WebsiteUrl']);
                exit();
            }
            $userId = $user[0]['id'];

            // Hash the new password
            $hashedPassword = md5($newPassword);

            // Update the password and reset the token
            $Users->update([
                'password' => $hashedPassword,
                'reset_token' => null,
                'reset_token_expiration' => null
            ], ['id' => $userId]);

            $_SESSION['alert'] = Alert('success', 'رمزت با موفقیت عوض شد');
        }
    }
    header('Location: '.$_SESSION['WebsiteUrl']);
    exit();
    
} elseif (isset($_GET['RESET'])) {
    $token = $_GET['RESET'];

    // Validate token
    $user = $Users->select("id, reset_token_expiration", ['reset_token' => $token]);

    if ($user == -1) {
        $_SESSION['alert'] = Alert('error', 'اشتباه اومدی');
        header('Location: ' . $_SESSION['WebsiteUrl']);
        exit();
    }

    $userId = $user[0]['id'];
    $tokenExpiration = $user[0]['reset_token_expiration'];

    // Check if the token has expired
    if (strtotime($tokenExpiration) < time()) {
        $_SESSION['alert'] = Alert('error', 'لینک منقضی شده');
        header('Location: ' . $_SESSION['WebsiteUrl']);
        exit();
    }

    // Handle form submission
    if (isset($_POST['ForgotPasswordForm']) && $_POST['ForgotPasswordForm'] == "Reset") {
        $newPassword = $_POST['password'];
        $confirmPassword = $_POST['confirm_password'];

        // Validate passwords
        if ($newPassword !== $confirmPassword) {
            $_SESSION['alert'] = Alert('error', 'Passwords do not match.');
        } else {
            // Hash the new password
            $hashedPassword = md5($newPassword);

            // Update the password and reset the token
            $Users->update([
                'password' => $hashedPassword,
                'reset_token' => null,
                'reset_token_expiration' => null
            ], ['id' => $userId]);

            $_SESSION['alert'] = Alert('success', 'Password has been reset successfully.');
            header('Location: login.php');
            exit();
        }
    }
}
