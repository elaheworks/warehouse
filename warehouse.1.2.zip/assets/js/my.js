document.addEventListener('DOMContentLoaded', () => {
  const themeToggleButtons = document.querySelectorAll('.theme-controller');
  const html = document.documentElement;

  // Read theme from cookie
  const cookies = document.cookie.split('; ');
  const themeCookie = cookies.find(row => row.startsWith('theme='));
  let theme = themeCookie ? themeCookie.split('=')[1] : 'nord';

  // Set the initial theme
  html.setAttribute('data-theme', theme);

  // Set the correct radio button based on the current theme
  const themeRadioButton = document.querySelector(`input[value="${theme}"]`);
  if (themeRadioButton) {
    themeRadioButton.checked = true;
  }

  // Change theme on radio button change
  themeToggleButtons.forEach(button => {
    button.addEventListener('change', () => {
      const newTheme = button.value;
      document.cookie = `theme=${newTheme}; path=/; max-age=${30 * 24 * 60 * 60}`; // Set cookie for 30 days
      html.setAttribute('data-theme', newTheme);
    });
  });
});

function showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    const toast = document.createElement('div');

    let typeClass = 'alert-info';
    if (type === 'success') typeClass = 'alert-success';
    else if (type === 'error') typeClass = 'alert-error';
    else if (type === 'warning') typeClass = 'alert-warning';

    toast.className = `alert ${typeClass} shadow-lg`;
    toast.innerHTML = `<span>${message}</span>`;
    container.appendChild(toast);

    setTimeout(() => { toast.remove(); }, 4000);
}
