<?php 

$_SESSION['WebsiteUrl'] = 'http://localhost/warehouse';
$_SESSION['MainWebsiteUrl'] = 'http://localhost/ShahkarDramaWeb';
// $_SESSION['WebsiteUrl'] = 'http://shahrekaghazi.com/warehouse/';
// $_SESSION['MainWebsiteUrl'] = 'http://shahrekaghazi.com/';

?>