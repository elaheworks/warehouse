<?php
function dashboardCard($icon, $color, $title, $value, $link = '#')
{
    return <<<HTML
    <a href="$link" class="card bg-base-100 shadow-xl hover:bg-base-200 transition duration-200">
        <div class="card-body">
            <div class="flex items-center">
                <i class="fa-solid $icon text-$color text-2xl me-2"></i>
                <h2 class="card-title">$title</h2>
            </div>
            <p class="text-3xl font-bold">$value</p>
        </div>
    </a>
    HTML;
}
